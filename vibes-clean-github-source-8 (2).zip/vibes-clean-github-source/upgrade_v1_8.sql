-- Vibes 1.8 social feature upgrade. Run once in Supabase SQL Editor.

create table if not exists public.content_reactions (
  user_id uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('post','story','message','comment')),
  target_id text not null,
  emoji text not null check (emoji in ('👍','❤️','😂','😮','😢','😡','🔥','👏')),
  created_at timestamptz not null default now(),
  primary key (user_id,target_type,target_id)
);
alter table public.content_reactions enable row level security;
create policy "reactions readable" on public.content_reactions for select to authenticated using (true);
create policy "reactions own insert" on public.content_reactions for insert to authenticated with check ((select auth.uid())=user_id);
create policy "reactions own update" on public.content_reactions for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "reactions own delete" on public.content_reactions for delete to authenticated using ((select auth.uid())=user_id);
grant select,insert,update,delete on public.content_reactions to authenticated;
revoke all on public.content_reactions from anon;

create table if not exists public.restrictions (
  owner_id uuid not null references public.profiles(id) on delete cascade,
  restricted_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(owner_id,restricted_id), check(owner_id<>restricted_id)
);
alter table public.restrictions enable row level security;
create policy "restrictions owner read" on public.restrictions for select to authenticated using ((select auth.uid())=owner_id);
create policy "restrictions owner insert" on public.restrictions for insert to authenticated with check ((select auth.uid())=owner_id);
create policy "restrictions owner delete" on public.restrictions for delete to authenticated using ((select auth.uid())=owner_id);
grant select,insert,delete on public.restrictions to authenticated;
revoke all on public.restrictions from anon;
alter table public.reports add column if not exists category text not null default 'other' check(category in ('spam','harassment','hate','nudity','violence','fraud','impersonation','other'));
alter table public.reports add column if not exists target_user_id uuid references public.profiles(id) on delete set null;
alter table public.reports add column if not exists resolution text;

alter table public.comments add column if not exists parent_comment_id uuid references public.comments(id) on delete cascade;
alter table public.content_reactions drop constraint if exists content_reactions_target_type_check;
alter table public.content_reactions add constraint content_reactions_target_type_check check (target_type in ('post','story','message','comment'));

alter table public.posts add column if not exists filter_name text not null default 'natural'
check (filter_name in ('natural','bright','warm','cool','vivid','mono','soft'));

alter table public.profiles add column if not exists first_name text not null default '' check (char_length(first_name) <= 50);
alter table public.profiles add column if not exists middle_name text not null default '' check (char_length(middle_name) <= 50);
alter table public.profiles add column if not exists last_name text not null default '' check (char_length(last_name) <= 50);
alter table public.profiles add column if not exists age smallint check (age between 13 and 120);
alter table public.profiles add column if not exists gender text check (gender in ('male','female','other','prefer_not_to_say'));
alter table public.profiles add column if not exists preferred_language text not null default 'en' check (char_length(preferred_language) between 2 and 10);
alter table public.profiles add column if not exists is_private boolean not null default false;
alter table public.profiles add column if not exists allow_messages text not null default 'everyone' check (allow_messages in ('everyone','following','none'));
alter table public.profiles add column if not exists autoplay_videos boolean not null default true;
alter table public.profiles add column if not exists data_saver boolean not null default false;
alter table public.profiles add column if not exists theme text not null default 'dark' check (theme in ('dark','light','system'));

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,display_name,first_name,middle_name,last_name,age,gender,username)
  values(new.id,coalesce(new.raw_user_meta_data->>'name',split_part(new.email,'@',1)),
    coalesce(new.raw_user_meta_data->>'first_name',''),coalesce(new.raw_user_meta_data->>'middle_name',''),coalesce(new.raw_user_meta_data->>'last_name',''),
    nullif(new.raw_user_meta_data->>'age','')::smallint,nullif(new.raw_user_meta_data->>'gender',''),
    lower(regexp_replace(coalesce(new.raw_user_meta_data->>'name',split_part(new.email,'@',1)),'[^a-zA-Z0-9]+','','g')) || substr(new.id::text,1,6))
  on conflict(id) do nothing;
  return new;
end;$$;

create table if not exists public.saved_posts (
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, post_id)
);

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  media_url text,
  media_type text not null default 'text' check (media_type = 'text' or media_type like 'image/%' or media_type like 'video/%'),
  body text not null default '' check (char_length(body) <= 500),
  background text not null default 'violet' check (background in ('violet','sunset','ocean','forest','midnight')),
  filter_name text not null default 'natural' check (filter_name in ('natural','bright','warm','cool','vivid','mono','soft')),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours')
);

alter table public.stories add column if not exists filter_name text not null default 'natural'
check (filter_name in ('natural','bright','warm','cool','vivid','mono','soft'));
alter table public.stories alter column media_url drop not null;
alter table public.stories add column if not exists body text not null default '' check (char_length(body) <= 500);
alter table public.stories add column if not exists background text not null default 'violet' check (background in ('violet','sunset','ocean','forest','midnight'));
alter table public.stories drop constraint if exists stories_media_type_check;
alter table public.stories add constraint stories_media_type_check check (media_type = 'text' or media_type like 'image/%' or media_type like 'video/%');

alter table public.saved_posts enable row level security;
alter table public.stories enable row level security;

create policy "saved posts owner read" on public.saved_posts for select to authenticated
using ((select auth.uid()) = user_id);
create policy "saved posts owner insert" on public.saved_posts for insert to authenticated
with check ((select auth.uid()) = user_id);
create policy "saved posts owner delete" on public.saved_posts for delete to authenticated
using ((select auth.uid()) = user_id);

create policy "active stories readable" on public.stories for select to authenticated
using (expires_at > now());
create policy "story owner insert" on public.stories for insert to authenticated
with check ((select auth.uid()) = user_id);
create policy "story owner delete" on public.stories for delete to authenticated
using ((select auth.uid()) = user_id);

grant select, insert, delete on public.saved_posts to authenticated;
grant select, insert, delete on public.stories to authenticated;
revoke all on public.saved_posts, public.stories from anon;

update storage.buckets
set file_size_limit = null,
    allowed_mime_types = array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime']
where id = 'post-media';
