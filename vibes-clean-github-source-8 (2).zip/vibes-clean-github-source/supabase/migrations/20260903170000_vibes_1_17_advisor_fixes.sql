-- Advisor follow-up: cover the remaining foreign key and keep elevated RPC code
-- outside the exposed API schema.

create index if not exists restrictions_restricted_id_idx
  on public.restrictions(restricted_id);

create or replace function private.start_direct_conversation_impl(other_user uuid)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  requester uuid := (select auth.uid());
  recipient_policy text;
  conversation_key text;
  result_id uuid;
begin
  if requester is null then raise exception 'authentication_required' using errcode='42501'; end if;
  if not private.is_account_active(requester) then raise exception 'account_restricted' using errcode='42501'; end if;
  if other_user is null or other_user=requester then raise exception 'invalid_recipient' using errcode='22023'; end if;
  if not private.is_account_active(other_user) then raise exception 'recipient_not_available' using errcode='42501'; end if;
  select p.allow_messages into recipient_policy from public.profiles p where p.id=other_user;
  if recipient_policy is null then raise exception 'recipient_not_found' using errcode='22023'; end if;
  if exists(select 1 from public.blocks b where (b.blocker_id=requester and b.blocked_id=other_user) or (b.blocker_id=other_user and b.blocked_id=requester))
    then raise exception 'messaging_not_allowed' using errcode='42501'; end if;
  if recipient_policy='none' then raise exception 'messaging_not_allowed' using errcode='42501'; end if;
  if recipient_policy='following' and not exists(select 1 from public.follows f where f.follower_id=other_user and f.following_id=requester)
    then raise exception 'messaging_not_allowed' using errcode='42501'; end if;
  conversation_key:=least(requester::text,other_user::text)||':'||greatest(requester::text,other_user::text);
  insert into public.conversations(created_by,direct_key) values(requester,conversation_key)
    on conflict(direct_key) where direct_key is not null do update set direct_key=excluded.direct_key returning id into result_id;
  insert into public.conversation_members(conversation_id,user_id) values(result_id,requester),(result_id,other_user) on conflict do nothing;
  return result_id;
end;$$;
revoke all on function private.start_direct_conversation_impl(uuid) from public,anon;
grant execute on function private.start_direct_conversation_impl(uuid) to authenticated;

create or replace function public.start_direct_conversation(other_user uuid)
returns uuid
language sql
security invoker
set search_path=public,private
as $$ select private.start_direct_conversation_impl(other_user); $$;
revoke execute on function public.start_direct_conversation(uuid) from public,anon;
grant execute on function public.start_direct_conversation(uuid) to authenticated;
