-- Safe future rollout controls. Values are data/config only, never executable code.

alter table public.profiles
  add column if not exists update_channel text not null default 'stable'
    check (update_channel in ('stable','early_access')),
  add column if not exists product_updates boolean not null default true;

grant update (update_channel,product_updates) on public.profiles to authenticated;

create table if not exists public.app_releases (
  id uuid primary key default gen_random_uuid(),
  version_name text not null check (char_length(version_name) between 1 and 30),
  version_code integer not null check (version_code>0),
  channel text not null default 'stable' check (channel in ('stable','early_access')),
  summary text not null default '' check (char_length(summary)<=1000),
  is_mandatory boolean not null default false,
  is_enabled boolean not null default true,
  published_at timestamptz not null default now(),
  unique(version_code,channel)
);

create table if not exists public.app_feature_flags (
  key text primary key check (key ~ '^[a-z0-9_]{3,60}$'),
  enabled boolean not null default false,
  rollout_percent smallint not null default 0 check (rollout_percent between 0 and 100),
  min_version_code integer not null default 1 check (min_version_code>0),
  description text not null default '' check (char_length(description)<=300),
  updated_at timestamptz not null default now()
);

alter table public.app_releases enable row level security;
alter table public.app_feature_flags enable row level security;
create policy "release authenticated read" on public.app_releases
  for select to authenticated using (is_enabled);
create policy "feature flags authenticated read" on public.app_feature_flags
  for select to authenticated using (true);
revoke all on public.app_releases,public.app_feature_flags from anon,authenticated;
grant select on public.app_releases,public.app_feature_flags to authenticated;

insert into public.app_releases(version_name,version_code,channel,summary,is_mandatory,is_enabled)
values('1.17.0',19,'stable','Comfort UI, official social imports, private chat, Ideas Lab, authenticity review and secure Premium foundation.',false,true)
on conflict(version_code,channel) do update
set summary=excluded.summary,is_enabled=true;

insert into public.app_feature_flags(key,enabled,rollout_percent,min_version_code,description)
values
  ('ideas_lab',true,100,19,'Community feature proposals and voting'),
  ('premium_foundation',true,100,19,'Premium status UI without client-side entitlement writes')
on conflict(key) do update
set enabled=excluded.enabled,rollout_percent=excluded.rollout_percent,min_version_code=excluded.min_version_code,description=excluded.description,updated_at=now();

create or replace function private.sync_premium_profile()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  update public.profiles
  set premium_status=new.status,premium_until=new.current_period_end
  where id=new.user_id;
  return new;
end;$$;
revoke all on function private.sync_premium_profile() from public,anon,authenticated;
drop trigger if exists on_premium_entitlement_changed on public.premium_entitlements;
create trigger on_premium_entitlement_changed
after insert or update on public.premium_entitlements
for each row execute function private.sync_premium_profile();

do $$ begin
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
    and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='app_releases')
  then alter publication supabase_realtime add table public.app_releases; end if;
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
    and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='app_feature_flags')
  then alter publication supabase_realtime add table public.app_feature_flags; end if;
end $$;
