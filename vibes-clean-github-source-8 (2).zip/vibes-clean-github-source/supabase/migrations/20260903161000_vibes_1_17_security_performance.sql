-- Vibes 1.17 follow-up: advisor-driven ACL, group-call RLS and policy performance.

create index if not exists conversations_created_by_idx on public.conversations(created_by);
create index if not exists feature_requests_user_id_idx on public.feature_requests(user_id);

revoke execute on function public.start_direct_conversation(uuid) from public, anon;
grant execute on function public.start_direct_conversation(uuid) to authenticated;

create or replace function private.notify_new_message()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  insert into public.notifications(user_id,actor_id,type,body)
  select cm.user_id,new.sender_id,'message',left(new.body,160)
  from public.conversation_members cm
  where cm.conversation_id=new.conversation_id and cm.user_id<>new.sender_id;
  return new;
end;$$;
revoke all on function private.notify_new_message() from public,anon,authenticated;
drop trigger if exists on_message_created_notify on public.messages;
create trigger on_message_created_notify after insert on public.messages
  for each row execute function private.notify_new_message();
drop function if exists public.notify_new_message();

create or replace function private.is_group_call_member(target_room uuid,candidate_user uuid)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1 from public.group_call_members m
    where m.room_id=target_room and m.user_id=candidate_user
  );
$$;
revoke all on function private.is_group_call_member(uuid,uuid) from public,anon;
grant execute on function private.is_group_call_member(uuid,uuid) to authenticated;

alter policy "profile owner insert" on public.profiles with check ((select auth.uid())=id);
alter policy "profile owner update" on public.profiles using ((select auth.uid())=id) with check ((select auth.uid())=id);
alter policy "posts own insert" on public.posts with check ((select auth.uid())=user_id);
alter policy "posts own update" on public.posts using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
alter policy "posts own delete" on public.posts using ((select auth.uid())=user_id);
alter policy "likes own insert" on public.likes with check ((select auth.uid())=user_id);
alter policy "likes own delete" on public.likes using ((select auth.uid())=user_id);
alter policy "comments own insert" on public.comments with check ((select auth.uid())=user_id);
alter policy "comments own delete" on public.comments using ((select auth.uid())=user_id);
alter policy "follows own insert" on public.follows with check ((select auth.uid())=follower_id);
alter policy "follows own delete" on public.follows using ((select auth.uid())=follower_id);
alter policy "blocks own read" on public.blocks using ((select auth.uid())=blocker_id);
alter policy "blocks own insert" on public.blocks with check ((select auth.uid())=blocker_id);
alter policy "blocks own delete" on public.blocks using ((select auth.uid())=blocker_id);
alter policy "reports own insert" on public.reports with check ((select auth.uid())=reporter_id);
alter policy "reports own read" on public.reports using ((select auth.uid())=reporter_id);
alter policy "notification owner read" on public.notifications using ((select auth.uid())=user_id);
alter policy "notification owner update" on public.notifications using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);

alter policy "call participants read" on public.calls
  using ((select auth.uid())=caller_id or (select auth.uid())=callee_id);
alter policy "caller creates call" on public.calls
  with check ((select auth.uid())=caller_id);
alter policy "participants delete call" on public.calls
  using ((select auth.uid())=caller_id or (select auth.uid())=callee_id);
alter policy "participants update call" on public.calls
  using ((select auth.uid())=caller_id or (select auth.uid())=callee_id)
  with check ((select auth.uid())=caller_id or (select auth.uid())=callee_id);
alter policy "call candidates delete" on public.call_ice_candidates
  using ((select auth.uid())=user_id);
alter policy "call candidates insert" on public.call_ice_candidates
  with check ((select auth.uid())=user_id and exists(
    select 1 from public.calls c where c.id=call_id
      and (c.caller_id=(select auth.uid()) or c.callee_id=(select auth.uid()))
  ));
alter policy "call candidates read" on public.call_ice_candidates
  using (exists(
    select 1 from public.calls c where c.id=call_id
      and (c.caller_id=(select auth.uid()) or c.callee_id=(select auth.uid()))
  ));

alter policy "group calls creator insert" on public.group_calls
  with check (creator_id=(select auth.uid()));
alter policy "group calls creator update" on public.group_calls
  using (creator_id=(select auth.uid())) with check (creator_id=(select auth.uid()));
alter policy "group calls member read" on public.group_calls
  using (creator_id=(select auth.uid()) or (select private.is_group_call_member(id,(select auth.uid()))));
alter policy "group members creator insert" on public.group_call_members
  with check (
    exists(select 1 from public.group_calls g where g.id=room_id and g.creator_id=(select auth.uid()))
    or user_id=(select auth.uid())
  );
alter policy "group members member read" on public.group_call_members
  using ((select private.is_group_call_member(room_id,(select auth.uid()))));
alter policy "group members self update" on public.group_call_members
  using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));
alter policy "group signals member insert" on public.group_call_signals
  with check (from_user=(select auth.uid()) and (select private.is_group_call_member(room_id,(select auth.uid()))));
alter policy "group signals member read" on public.group_call_signals
  using (to_user=(select auth.uid()) and (select private.is_group_call_member(room_id,(select auth.uid()))));

alter policy "push token owner read" on public.push_tokens using ((select auth.uid())=user_id);
alter policy "push token owner insert" on public.push_tokens with check ((select auth.uid())=user_id);
alter policy "push token owner update" on public.push_tokens using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
alter policy "push token owner delete" on public.push_tokens using ((select auth.uid())=user_id);

alter policy "post media authenticated upload" on storage.objects
  with check (bucket_id='post-media' and (storage.foldername(name))[1]=(select auth.uid())::text);
alter policy "post media owner delete" on storage.objects
  using (bucket_id='post-media' and (storage.foldername(name))[1]=(select auth.uid())::text);
