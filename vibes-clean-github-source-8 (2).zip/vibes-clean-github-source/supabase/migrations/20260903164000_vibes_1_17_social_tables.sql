-- Restore optional social tables used by reactions, stories, saves and restrictions.

create table if not exists public.content_reactions (
  user_id uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('post','story','message','comment')),
  target_id text not null,
  emoji text not null check (emoji in ('👍','❤️','😂','😮','😢','😡','🔥','👏')),
  created_at timestamptz not null default now(),
  primary key (user_id,target_type,target_id)
);

create table if not exists public.restrictions (
  owner_id uuid not null references public.profiles(id) on delete cascade,
  restricted_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(owner_id,restricted_id),
  check (owner_id <> restricted_id)
);

create table if not exists public.saved_posts (
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id,post_id)
);
create index if not exists saved_posts_post_idx on public.saved_posts(post_id);

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  media_url text,
  media_type text not null default 'image',
  body text not null default '' check (char_length(body) <= 500),
  background text not null default 'violet'
    check (background in ('violet','sunset','ocean','forest','midnight')),
  filter_name text not null default 'natural'
    check (filter_name in ('natural','bright','warm','cool','vivid','mono','soft')),
  expires_at timestamptz not null default (now()+interval '24 hours'),
  created_at timestamptz not null default now(),
  check (media_url is not null or char_length(body)>0)
);
create index if not exists stories_active_idx on public.stories(expires_at desc);
create index if not exists stories_user_idx on public.stories(user_id);

alter table public.content_reactions enable row level security;
alter table public.restrictions enable row level security;
alter table public.saved_posts enable row level security;
alter table public.stories enable row level security;

create policy "reactions readable" on public.content_reactions for select to authenticated using (true);
create policy "reactions own insert" on public.content_reactions for insert to authenticated with check ((select auth.uid())=user_id);
create policy "reactions own update" on public.content_reactions for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "reactions own delete" on public.content_reactions for delete to authenticated using ((select auth.uid())=user_id);

create policy "restrictions owner read" on public.restrictions for select to authenticated using ((select auth.uid())=owner_id);
create policy "restrictions owner insert" on public.restrictions for insert to authenticated with check ((select auth.uid())=owner_id);
create policy "restrictions owner delete" on public.restrictions for delete to authenticated using ((select auth.uid())=owner_id);

create policy "saved posts owner read" on public.saved_posts for select to authenticated using ((select auth.uid())=user_id);
create policy "saved posts owner insert" on public.saved_posts for insert to authenticated with check ((select auth.uid())=user_id);
create policy "saved posts owner delete" on public.saved_posts for delete to authenticated using ((select auth.uid())=user_id);

create policy "stories readable" on public.stories for select to authenticated using (expires_at>now());
create policy "stories own insert" on public.stories for insert to authenticated with check ((select auth.uid())=user_id);
create policy "stories own delete" on public.stories for delete to authenticated using ((select auth.uid())=user_id);

revoke all on public.content_reactions,public.restrictions,public.saved_posts,public.stories from anon;
grant select,insert,update,delete on public.content_reactions to authenticated;
grant select,insert,delete on public.restrictions,public.saved_posts,public.stories to authenticated;

do $$ begin
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
    and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='stories')
  then alter publication supabase_realtime add table public.stories; end if;
end $$;
