-- Vibes 1.17 account authenticity: moderator-controlled restrictions and appeals.
-- No automated face recognition is performed by this schema.

alter table public.profiles
  add column if not exists account_status text not null default 'active'
    check (account_status in ('active','under_review','disabled')),
  add column if not exists verification_status text not null default 'unverified'
    check (verification_status in ('unverified','pending','verified','rejected')),
  add column if not exists premium_status text not null default 'none'
    check (premium_status in ('none','trial','active','past_due','cancelled','expired')),
  add column if not exists premium_until timestamptz,
  add column if not exists show_premium_badge boolean not null default true;

-- Owners can edit profile presentation/preferences, never trust or moderation fields.
revoke update on public.profiles from authenticated;
grant update (
  display_name,username,bio,avatar_url,first_name,middle_name,last_name,age,gender,
  preferred_language,is_private,allow_messages,autoplay_videos,data_saver,theme,
  cover_url,nickname,current_city,hometown,work,education,relationship_status,website
  ,show_premium_badge
) on public.profiles to authenticated;

create or replace function private.is_account_active(candidate_user uuid)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1 from public.profiles p
    where p.id=candidate_user and p.account_status='active'
  );
$$;
revoke all on function private.is_account_active(uuid) from public,anon;
grant execute on function private.is_account_active(uuid) to authenticated;

create table if not exists public.verification_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null default 'account_review'
    check (reason in ('account_review','impersonation_dispute','verified_badge')),
  note text not null default '' check (char_length(note) <= 500),
  status text not null default 'pending'
    check (status in ('pending','approved','rejected','cancelled')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);
create unique index if not exists verification_requests_one_pending_idx
  on public.verification_requests(user_id) where status='pending';
create index if not exists verification_requests_user_created_idx
  on public.verification_requests(user_id,created_at desc);
alter table public.verification_requests enable row level security;
create policy "verification request owner read" on public.verification_requests
  for select to authenticated using ((select auth.uid())=user_id);
create policy "verification request owner create" on public.verification_requests
  for insert to authenticated with check ((select auth.uid())=user_id and status='pending');
create policy "verification request owner cancel" on public.verification_requests
  for delete to authenticated using ((select auth.uid())=user_id and status='pending');
revoke all on public.verification_requests from anon;
grant select,insert,delete on public.verification_requests to authenticated;

-- Payment providers write entitlements only through a trusted server webhook.
-- Clients may read their own record but can never grant themselves Premium.
create table if not exists public.premium_entitlements (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  status text not null default 'none'
    check (status in ('none','trial','active','past_due','cancelled','expired')),
  provider text not null default 'unconfigured'
    check (provider in ('unconfigured','google_play','stripe','manual')),
  product_id text not null default '',
  provider_reference text not null default '',
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.premium_entitlements enable row level security;
create policy "premium owner read" on public.premium_entitlements
  for select to authenticated using ((select auth.uid())=user_id);
revoke all on public.premium_entitlements from anon,authenticated;
grant select on public.premium_entitlements to authenticated;

-- A moderator can set under_review/disabled using a trusted backend. These
-- restrictive policies immediately block data access with the existing JWT.
create policy "active account only" on public.posts as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.likes as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.comments as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.content_reactions as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.follows as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.blocks as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.restrictions as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.reports as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.conversations as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.conversation_members as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.messages as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.calls as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.call_ice_candidates as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.group_calls as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.group_call_members as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.group_call_signals as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.push_tokens as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.saved_posts as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.stories as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.notifications as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.external_posts as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.feature_requests as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.feature_request_votes as restrictive for all to authenticated
  using ((select private.is_account_active((select auth.uid()))))
  with check ((select private.is_account_active((select auth.uid()))));
create policy "active account only" on public.premium_entitlements as restrictive for select to authenticated
  using ((select private.is_account_active((select auth.uid()))));

alter policy "post media authenticated upload" on storage.objects
  with check (
    bucket_id='post-media'
    and (storage.foldername(name))[1]=(select auth.uid())::text
    and (select private.is_account_active((select auth.uid())))
  );
alter policy "post media owner delete" on storage.objects
  using (
    bucket_id='post-media'
    and (storage.foldername(name))[1]=(select auth.uid())::text
    and (select private.is_account_active((select auth.uid())))
  );

create or replace function public.start_direct_conversation(other_user uuid)
returns uuid
language plpgsql
security definer
set search_path=public
as $$
declare
  requester uuid := (select auth.uid());
  recipient_policy text;
  conversation_key text;
  result_id uuid;
begin
  if requester is null then raise exception 'authentication_required' using errcode='42501'; end if;
  if not private.is_account_active(requester) then raise exception 'account_restricted' using errcode='42501'; end if;
  if other_user is null or other_user=requester then raise exception 'invalid_recipient' using errcode='22023'; end if;
  if not private.is_account_active(other_user) then raise exception 'recipient_not_available' using errcode='42501'; end if;
  select p.allow_messages into recipient_policy from public.profiles p where p.id=other_user;
  if recipient_policy is null then raise exception 'recipient_not_found' using errcode='22023'; end if;
  if exists(select 1 from public.blocks b where (b.blocker_id=requester and b.blocked_id=other_user) or (b.blocker_id=other_user and b.blocked_id=requester))
    then raise exception 'messaging_not_allowed' using errcode='42501'; end if;
  if recipient_policy='none' then raise exception 'messaging_not_allowed' using errcode='42501'; end if;
  if recipient_policy='following' and not exists(select 1 from public.follows f where f.follower_id=other_user and f.following_id=requester)
    then raise exception 'messaging_not_allowed' using errcode='42501'; end if;
  conversation_key:=least(requester::text,other_user::text)||':'||greatest(requester::text,other_user::text);
  insert into public.conversations(created_by,direct_key) values(requester,conversation_key)
    on conflict(direct_key) where direct_key is not null do update set direct_key=excluded.direct_key returning id into result_id;
  insert into public.conversation_members(conversation_id,user_id) values(result_id,requester),(result_id,other_user) on conflict do nothing;
  return result_id;
end;$$;
revoke execute on function public.start_direct_conversation(uuid) from public,anon;
grant execute on function public.start_direct_conversation(uuid) to authenticated;

do $$ begin
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
    and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='profiles')
  then alter publication supabase_realtime add table public.profiles; end if;
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
    and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='verification_requests')
  then alter publication supabase_realtime add table public.verification_requests; end if;
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
    and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='premium_entitlements')
  then alter publication supabase_realtime add table public.premium_entitlements; end if;
end $$;
