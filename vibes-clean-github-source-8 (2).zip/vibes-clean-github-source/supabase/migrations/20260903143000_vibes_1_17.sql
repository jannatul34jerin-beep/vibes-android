-- Vibes 1.17: secure direct messages and complete external-post media types.

alter table public.conversations
  add column if not exists created_by uuid references public.profiles(id) on delete set null,
  add column if not exists direct_key text;

create unique index if not exists conversations_direct_key_idx
  on public.conversations(direct_key) where direct_key is not null;

alter table public.external_posts drop constraint if exists external_posts_media_type_check;
alter table public.external_posts add constraint external_posts_media_type_check
  check (media_type in ('text','image','video','carousel','link'));
alter table public.external_posts add column if not exists source_id text not null default '';
create index if not exists external_posts_source_idx on public.external_posts(platform,source_id,published_at desc);

alter table public.profiles
  add column if not exists cover_url text,
  add column if not exists nickname text check (char_length(nickname) <= 50),
  add column if not exists current_city text check (char_length(current_city) <= 100),
  add column if not exists hometown text check (char_length(hometown) <= 100),
  add column if not exists work text check (char_length(work) <= 120),
  add column if not exists education text check (char_length(education) <= 120),
  add column if not exists relationship_status text check (relationship_status in ('','single','in_a_relationship','engaged','married','complicated','prefer_not_to_say')),
  add column if not exists website text check (char_length(website) <= 300);

create schema if not exists private;

create or replace function private.is_conversation_member(target_conversation uuid, candidate_user uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.conversation_members cm
    where cm.conversation_id = target_conversation
      and cm.user_id = candidate_user
  );
$$;

revoke all on function private.is_conversation_member(uuid,uuid) from public;
grant usage on schema private to authenticated;
grant execute on function private.is_conversation_member(uuid,uuid) to authenticated;

create or replace function private.can_send_conversation_message(target_conversation uuid, candidate_user uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select private.is_conversation_member(target_conversation, candidate_user)
    and not exists (
      select 1
      from public.conversation_members other_member
      join public.blocks b
        on (b.blocker_id = candidate_user and b.blocked_id = other_member.user_id)
        or (b.blocked_id = candidate_user and b.blocker_id = other_member.user_id)
      where other_member.conversation_id = target_conversation
        and other_member.user_id <> candidate_user
    );
$$;

revoke all on function private.can_send_conversation_message(uuid,uuid) from public;
grant execute on function private.can_send_conversation_message(uuid,uuid) to authenticated;

create or replace function public.start_direct_conversation(other_user uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  requester uuid := (select auth.uid());
  recipient_policy text;
  conversation_key text;
  result_id uuid;
begin
  if requester is null then
    raise exception 'authentication_required' using errcode = '42501';
  end if;
  if other_user is null or other_user = requester then
    raise exception 'invalid_recipient' using errcode = '22023';
  end if;

  select p.allow_messages into recipient_policy
  from public.profiles p where p.id = other_user;
  if recipient_policy is null then
    raise exception 'recipient_not_found' using errcode = '22023';
  end if;

  if exists (
    select 1 from public.blocks b
    where (b.blocker_id = requester and b.blocked_id = other_user)
       or (b.blocker_id = other_user and b.blocked_id = requester)
  ) then
    raise exception 'messaging_not_allowed' using errcode = '42501';
  end if;

  if recipient_policy = 'none' then
    raise exception 'messaging_not_allowed' using errcode = '42501';
  end if;
  if recipient_policy = 'following' and not exists (
    select 1 from public.follows f
    where f.follower_id = other_user and f.following_id = requester
  ) then
    raise exception 'messaging_not_allowed' using errcode = '42501';
  end if;

  conversation_key := least(requester::text, other_user::text) || ':' || greatest(requester::text, other_user::text);
  insert into public.conversations(created_by,direct_key)
  values(requester,conversation_key)
  on conflict (direct_key) where direct_key is not null
  do update set direct_key = excluded.direct_key
  returning id into result_id;

  insert into public.conversation_members(conversation_id,user_id)
  values(result_id,requester),(result_id,other_user)
  on conflict do nothing;

  return result_id;
end;
$$;

revoke all on function public.start_direct_conversation(uuid) from public;
grant execute on function public.start_direct_conversation(uuid) to authenticated;

drop policy if exists "conversation member read" on public.conversations;
drop policy if exists "member rows read" on public.conversation_members;
drop policy if exists "message member read" on public.messages;
drop policy if exists "message member insert" on public.messages;
drop policy if exists "message sender delete" on public.messages;

create policy "conversation member read" on public.conversations
  for select to authenticated
  using ((select private.is_conversation_member(id,(select auth.uid()))));

create policy "member rows read" on public.conversation_members
  for select to authenticated
  using ((select private.is_conversation_member(conversation_id,(select auth.uid()))));

create policy "message member read" on public.messages
  for select to authenticated
  using ((select private.is_conversation_member(conversation_id,(select auth.uid()))));

create policy "message member insert" on public.messages
  for insert to authenticated
  with check (
    (select auth.uid()) = sender_id
    and (select private.can_send_conversation_message(conversation_id,(select auth.uid())))
  );

create policy "message sender delete" on public.messages
  for delete to authenticated
  using ((select auth.uid()) = sender_id);

revoke insert, update, delete on public.conversations, public.conversation_members from authenticated;
grant select on public.conversations, public.conversation_members to authenticated;
grant select, insert, delete on public.messages to authenticated;

create or replace function public.notify_new_message()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.notifications(user_id,actor_id,type,body)
  select cm.user_id,new.sender_id,'message',left(new.body,160)
  from public.conversation_members cm
  where cm.conversation_id=new.conversation_id and cm.user_id<>new.sender_id;
  return new;
end;$$;
revoke all on function public.notify_new_message() from public;
drop trigger if exists on_message_created_notify on public.messages;
create trigger on_message_created_notify after insert on public.messages
  for each row execute function public.notify_new_message();

-- Ideas Lab: privacy-preserving product feedback and community voting.
create table if not exists public.feature_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 3 and 100),
  description text not null default '' check (char_length(description) <= 1000),
  status text not null default 'submitted' check (status in ('submitted','reviewing','planned','building','released','declined')),
  created_at timestamptz not null default now()
);
create table if not exists public.feature_request_votes (
  request_id uuid not null references public.feature_requests(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(request_id,user_id)
);
create index if not exists feature_requests_status_created_idx on public.feature_requests(status,created_at desc);
create index if not exists feature_request_votes_user_idx on public.feature_request_votes(user_id);
alter table public.feature_requests enable row level security;
alter table public.feature_request_votes enable row level security;

drop policy if exists "feature requests read" on public.feature_requests;
drop policy if exists "feature requests create" on public.feature_requests;
drop policy if exists "feature requests owner delete" on public.feature_requests;
drop policy if exists "feature votes read" on public.feature_request_votes;
drop policy if exists "feature votes create" on public.feature_request_votes;
drop policy if exists "feature votes owner delete" on public.feature_request_votes;
create policy "feature requests read" on public.feature_requests for select to authenticated using (true);
create policy "feature requests create" on public.feature_requests for insert to authenticated
  with check ((select auth.uid()) = user_id and status = 'submitted');
create policy "feature requests owner delete" on public.feature_requests for delete to authenticated
  using ((select auth.uid()) = user_id and status = 'submitted');
create policy "feature votes read" on public.feature_request_votes for select to authenticated using (true);
create policy "feature votes create" on public.feature_request_votes for insert to authenticated
  with check ((select auth.uid()) = user_id);
create policy "feature votes owner delete" on public.feature_request_votes for delete to authenticated
  using ((select auth.uid()) = user_id);

revoke all on public.feature_requests,public.feature_request_votes from anon;
grant select,insert,delete on public.feature_requests,public.feature_request_votes to authenticated;

do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (
       select 1 from pg_publication_tables
       where pubname = 'supabase_realtime'
         and schemaname = 'public'
         and tablename = 'messages'
     ) then
    alter publication supabase_realtime add table public.messages;
  end if;
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (
       select 1 from pg_publication_tables
       where pubname = 'supabase_realtime'
         and schemaname = 'public'
         and tablename = 'external_posts'
     ) then
    alter publication supabase_realtime add table public.external_posts;
  end if;
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (
       select 1 from pg_publication_tables
       where pubname = 'supabase_realtime'
         and schemaname = 'public'
         and tablename = 'feature_requests'
     ) then
    alter publication supabase_realtime add table public.feature_requests;
  end if;
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (
       select 1 from pg_publication_tables
       where pubname = 'supabase_realtime'
         and schemaname = 'public'
         and tablename = 'feature_request_votes'
     ) then
    alter publication supabase_realtime add table public.feature_request_votes;
  end if;
end $$;
