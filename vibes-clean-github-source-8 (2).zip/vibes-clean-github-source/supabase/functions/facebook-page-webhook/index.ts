import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { syncFacebookPage } from "./facebook-sync.ts";

const json=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});
const plain=(body:string,status=200)=>new Response(body,{status,headers:{"content-type":"text/plain; charset=utf-8","cache-control":"no-store"}});
const hex=(bytes:ArrayBuffer)=>Array.from(new Uint8Array(bytes)).map(n=>n.toString(16).padStart(2,"0")).join("");
function safeEqual(a:string,b:string){if(a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0}
async function validSignature(raw:ArrayBuffer,signature:string,secret:string){if(!signature.startsWith("sha256="))return false;const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);const expected=hex(await crypto.subtle.sign("HMAC",key,raw));return safeEqual(expected,signature.slice(7).toLowerCase())}

Deno.serve(async(req:Request)=>{
  const url=new URL(req.url);
  if(req.method==="GET"){
    const expected=Deno.env.get("FACEBOOK_WEBHOOK_VERIFY_TOKEN")||"",mode=url.searchParams.get("hub.mode")||"",token=url.searchParams.get("hub.verify_token")||"",challenge=url.searchParams.get("hub.challenge")||"";
    return mode==="subscribe"&&expected&&safeEqual(token,expected)?plain(challenge):plain("verification_failed",403);
  }
  if(req.method!=="POST")return json({error:"method_not_allowed"},405);
  const appSecret=Deno.env.get("FACEBOOK_APP_SECRET")||"";if(!appSecret)return json({error:"server_not_configured"},500);
  const raw=await req.arrayBuffer();if(!(await validSignature(raw,req.headers.get("x-hub-signature-256")||"",appSecret)))return json({error:"invalid_signature"},401);
  let payload:any;try{payload=JSON.parse(new TextDecoder().decode(raw))}catch{return json({error:"invalid_json"},400)}
  if(payload?.object!=="page")return json({received:true,ignored:"unsupported_object"});
  const pageIds=[...new Set((Array.isArray(payload.entry)?payload.entry:[]).map((entry:any)=>String(entry?.id||"")).filter(Boolean))] as string[];
  try{let imported=0;for(const pageId of pageIds)imported+=Number((await syncFacebookPage(pageId)).imported||0);return json({received:true,imported})}
  catch(error){console.error("Facebook webhook sync failed",error instanceof Error?error.message:"unknown");return json({error:"webhook_sync_failed"},500)}
});
