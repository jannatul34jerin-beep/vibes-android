import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { syncFacebookPages } from "./facebook-sync.ts";

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "access-control-allow-origin": "*",
    "access-control-allow-headers": "authorization, x-client-info, apikey, content-type",
  },
});

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return json({ ok: true });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const keys = JSON.parse(Deno.env.get("SUPABASE_PUBLISHABLE_KEYS") || "{}");
  const publishableKey = keys.default || Deno.env.get("SUPABASE_ANON_KEY");
  const authorization = req.headers.get("authorization") || "";
  if (!supabaseUrl || !publishableKey) return json({ error: "server_not_configured" }, 500);
  if (!authorization.toLowerCase().startsWith("bearer ")) return json({ error: "authentication_required" }, 401);

  const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, { headers: { authorization, apikey: publishableKey } });
  if (!userResponse.ok) return json({ error: "authentication_required" }, 401);
  const user = await userResponse.json().catch(() => ({}));
  if (!user?.id) return json({ error: "authentication_required" }, 401);

  try {
    return json(await syncFacebookPages());
  } catch (error) {
    const name = error instanceof Error ? error.message : "unknown";
    if (name === "facebook_not_configured") return json({ error: "server_not_configured", missing: ["FACEBOOK_PAGES_JSON"] }, 500);
    console.error("Facebook sync failed", name);
    return json({ error: "facebook_sync_failed" }, 502);
  }
});
