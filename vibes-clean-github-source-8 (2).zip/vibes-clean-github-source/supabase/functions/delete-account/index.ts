import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const json=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store","access-control-allow-origin":"*","access-control-allow-headers":"authorization, x-client-info, apikey, content-type"}});
const envObject=(name:string)=>{try{return JSON.parse(Deno.env.get(name)||"{}")}catch{return {}}};

Deno.serve(async(req:Request)=>{
  if(req.method==="OPTIONS")return json({ok:true});
  if(req.method!=="POST")return json({error:"method_not_allowed"},405);
  const supabaseUrl=Deno.env.get("SUPABASE_URL")||"";
  const publishableKeys=envObject("SUPABASE_PUBLISHABLE_KEYS");
  const secretKeys=envObject("SUPABASE_SECRET_KEYS");
  const publishableKey=publishableKeys.default||Deno.env.get("SUPABASE_ANON_KEY")||"";
  const adminKey=secretKeys.default||Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")||"";
  const authorization=req.headers.get("authorization")||"";
  if(!authorization.toLowerCase().startsWith("bearer "))return json({error:"authentication_required"},401);
  if(!supabaseUrl||!publishableKey)return json({error:"server_not_configured"},500);
  let body:any={};try{body=await req.json()}catch{return json({error:"invalid_json"},400)}
  if(body?.confirmation!=="DELETE")return json({error:"confirmation_required"},400);

  const userResponse=await fetch(`${supabaseUrl}/auth/v1/user`,{headers:{authorization,apikey:publishableKey}});
  if(!userResponse.ok)return json({error:"authentication_required"},401);
  const user=await userResponse.json().catch(()=>({}));if(!user?.id)return json({error:"authentication_required"},401);
  if(!adminKey)return json({error:"server_not_configured"},500);
  const adminHeaders={authorization:`Bearer ${adminKey}`,apikey:adminKey,"content-type":"application/json"};

  try{
    const prefixes:string[]=[];let offset=0;
    while(offset<10000){
      const listResponse=await fetch(`${supabaseUrl}/storage/v1/object/list/post-media`,{method:"POST",headers:adminHeaders,body:JSON.stringify({prefix:`${user.id}/`,limit:1000,offset,sortBy:{column:"name",order:"asc"}})});
      if(!listResponse.ok)throw new Error("storage_list_failed");
      const files=await listResponse.json();if(!Array.isArray(files)||!files.length)break;
      for(const file of files)if(file?.name)prefixes.push(`${user.id}/${file.name}`);
      if(files.length<1000)break;offset+=files.length;
    }
    if(prefixes.length){
      const removeResponse=await fetch(`${supabaseUrl}/storage/v1/object/post-media`,{method:"DELETE",headers:adminHeaders,body:JSON.stringify({prefixes})});
      if(!removeResponse.ok)throw new Error("storage_delete_failed");
    }
    const deleteResponse=await fetch(`${supabaseUrl}/auth/v1/admin/users/${encodeURIComponent(user.id)}`,{method:"DELETE",headers:adminHeaders});
    if(!deleteResponse.ok)throw new Error("auth_delete_failed");
    return json({deleted:true});
  }catch(error){
    console.error("Account deletion failed",error instanceof Error?error.message:"unknown");
    return json({error:"account_delete_failed"},500);
  }
});
