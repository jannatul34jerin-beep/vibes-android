const CACHE='vibes-v117-secure-screen';
const ASSETS=['./','./index.html','./styles.css','./performance.css','./registration.css','./i18n.css','./settings.css','./reactions.css','./comments.css','./status.css','./auth-blue.css','./safety.css','./social-import.css','./comfort.css','./config.js','./app.js','./manifest.json','./privacy.html','./terms.html'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r}).catch(()=>caches.match(e.request)))})
