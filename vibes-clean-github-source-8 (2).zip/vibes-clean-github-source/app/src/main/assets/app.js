const cfg=window.VIBES_CONFIG||{};
const cloudReady=!!(window.supabase&&cfg.supabaseUrl&&cfg.supabaseAnonKey&&!cfg.supabaseUrl.startsWith('YOUR_')&&!cfg.supabaseAnonKey.startsWith('YOUR_'));
const sb=cloudReady?window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseAnonKey):null;
const demoKey='vibes_demo_v3';
const seed={user:null,posts:[
{id:1,user:'Nadia',handle:'@nadia',text:'Vibes-এ সবাইকে স্বাগতম ✨',time:'এখনই',likes:12,liked:false,comments:['দারুণ শুরু!'],image:null},
{id:2,user:'Rahim',handle:'@rahim',text:'আজকের দিনটা সুন্দর হোক 🌿',time:'১০ মিনিট আগে',likes:5,liked:false,comments:[],image:null}
],messages:[{me:false,text:'হাই! Vibes কেমন লাগছে?'},{me:true,text:'ভালো লাগছে 😊'}],blocked:[],reports:[]};
let local=JSON.parse(localStorage.getItem(demoKey)||'null')||seed;
let state={user:local.user,tab:'feed',authTab:'login',chatOpen:false,posts:local.posts||[],messages:local.messages||[],blocked:local.blocked||[],reports:local.reports||[],profile:null,upload:null,loading:false};
const esc=(s='')=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const handleOf=n=>'@'+String(n||'user').toLowerCase().replace(/[^a-z0-9\u0980-\u09ff]+/g,'').slice(0,20);
function persist(){if(!cloudReady){local={user:state.user,posts:state.posts,messages:state.messages,blocked:state.blocked,reports:state.reports};localStorage.setItem(demoKey,JSON.stringify(local));}}
function toast(msg){let t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);setTimeout(()=>t.remove(),2200)}
function app(){document.getElementById('app').innerHTML=state.user?mainUI():authUI();bind();}
function authUI(){return `<div class="auth"><div class="logo">Vibes ✨</div><div class="card"><div class="tabs"><button id="loginTab" class="${state.authTab==='login'?'active':''}">লগইন</button><button id="signupTab" class="${state.authTab==='signup'?'active':''}">নতুন অ্যাকাউন্ট</button></div>${!cloudReady?`<div class="notice warn"><b>Demo mode:</b> এখন এই ডিভাইসেই ডেটা সেভ হবে। Supabase config দিলে একই কোড real account/database ব্যবহার করবে।</div>`:''}${state.authTab==='signup'?`<input id="name" placeholder="আপনার নাম" maxlength="50">`:''}<input id="email" type="email" placeholder="ইমেইল"><input id="password" type="password" placeholder="পাসওয়ার্ড (কমপক্ষে 6 অক্ষর)" minlength="6"><button id="authGo" class="btn" style="width:100%;margin-top:8px">${state.authTab==='login'?'লগইন করুন':'অ্যাকাউন্ট তৈরি করুন'}</button><p class="muted" style="line-height:1.55">অ্যাকাউন্ট তৈরি করলে আপনি Vibes-এর কমিউনিটি নিয়ম মেনে চলতে সম্মত হচ্ছেন।</p></div></div>`}
function mainUI(){return `<div class="app"><header class="top"><div class="brand">Vibes</div><div class="grow"></div><span class="badge">${cloudReady?'Cloud':'Demo'}</span><button class="pill" id="logout">লগআউট</button></header><main class="content">${view()}</main>${nav()}</div>`}
function nav(){const items=[['feed','🏠','হোম'],['search','🔎','খুঁজুন'],['create','➕','পোস্ট'],['chat','💬','চ্যাট'],['profile','👤','প্রোফাইল']];return `<nav class="nav">${items.map(x=>`<button data-tab="${x[0]}" class="${state.tab===x[0]?'active':''}"><span class="ico">${x[1]}</span>${x[2]}</button>`).join('')}</nav>`}
function view(){if(state.loading)return `<div class="empty">লোড হচ্ছে…</div>`;if(state.tab==='create')return createView();if(state.tab==='profile')return profileView();if(state.tab==='chat')return chatView();if(state.tab==='search')return searchView();return feedView();}
function feedView(){return `<div class="composer card"><textarea id="quickPost" placeholder="কী ভাবছেন?"></textarea><div class="composer-tools"><label class="pill">📷 ছবি/ভিডিও<input id="quickImage" type="file" accept="image/*,video/*" hidden></label><div class="grow"></div><button class="btn" id="quickPostBtn">পোস্ট করুন</button></div><div id="quickPreview"></div></div>${state.posts.length?state.posts.map(postCard).join(''):`<div class="empty">এখনও কোনো পোস্ট নেই। প্রথম পোস্টটি করুন ✨</div>`}`}
function isVideoMedia(url='',type=''){return String(type).startsWith('video/')||/\.(mp4|webm|mov|m4v)(\?|#|$)/i.test(String(url))}
function postCard(p){const comments=p.comments||[];const media=p.image?(isVideoMedia(p.image,p.media_type)?`<video class="post-img" src="${esc(p.image)}" controls playsinline preload="metadata"></video>`:`<img class="post-img" src="${esc(p.image)}" alt="Post image">`):'';return `<article class="card" data-post="${esc(p.id)}"><div class="row"><div class="avatar">${esc((p.user||'U')[0])}</div><div class="grow"><div class="name">${esc(p.user||'Vibes user')}</div><div class="muted">${esc(p.handle||handleOf(p.user))} · ${esc(p.time||'')}</div></div><div class="menu"><button class="icon-btn" data-menu="${esc(p.id)}">⋯</button><div id="menu-${esc(p.id)}" class="menu-panel hidden"><button data-report="${esc(p.id)}">⚑ রিপোর্ট</button><button data-block="${esc(p.user_id||p.user)}">⛔ ব্লক</button></div></div></div><div class="post-text">${esc(p.text||'')}</div>${media}<div class="actions"><button class="action ${p.liked?'active':''}" data-like="${esc(p.id)}">♥ ${Number(p.likes||0)}</button><button class="action" data-comment="${esc(p.id)}">💬 ${comments.length}</button><button class="action" data-share="${esc(p.id)}">↗ শেয়ার</button></div>${comments.slice(-3).map(c=>`<div class="comment muted">💬 ${esc(typeof c==='string'?c:c.text)}</div>`).join('')}</article>`}
function createView(){return `<div class="title">নতুন পোস্ট</div><div class="card composer"><textarea id="newPost" placeholder="আপনার কথা লিখুন..." maxlength="3000"></textarea><label class="pill">📷 ছবি/ভিডিও যোগ করুন<input id="newImage" type="file" accept="image/*,video/*" hidden></label><div id="newPreview"></div><div class="media-note">ছবি সর্বোচ্চ ${cfg.maxImageMB||5} MB, ভিডিও সর্বোচ্চ ${cfg.maxVideoMB||50} MB।</div><button class="btn" id="postBtn" style="margin-top:10px">প্রকাশ করুন</button></div>`}
function searchView(){return `<div class="title">মানুষ ও পোস্ট খুঁজুন</div><div class="card"><input id="searchBox" placeholder="নাম বা লেখা লিখুন"></div><div id="searchResults"><div class="empty">সার্চ শুরু করুন</div></div>`}
function profileView(){const u=state.profile||state.user||{};const name=u.name||u.user_metadata?.name||u.email?.split('@')[0]||'Vibes User';const own=state.posts.filter(p=>p.user_id===u.id||p.user===name).length;return `<div class="card profile-head"><div class="avatar lg">${esc(name[0]||'V')}</div><div class="title" style="margin-bottom:4px">${esc(name)}</div><div class="muted">${esc(u.email||u.handle||handleOf(name))}</div><div class="stats"><div class="stat"><b>${own}</b><div class="muted">পোস্ট</div></div><div class="stat"><b>${u.followers_count||0}</b><div class="muted">ফলোয়ার</div></div><div class="stat"><b>${u.following_count||0}</b><div class="muted">ফলোয়িং</div></div></div><button class="btn light" id="editProfile">প্রোফাইল এডিট</button></div><div class="card"><div class="section-title">নিরাপত্তা ও কমিউনিটি</div><p class="muted">অপমান, হুমকি, স্প্যাম বা অনুপযুক্ত কনটেন্ট দেখলে Report ব্যবহার করুন। Block করলে ওই ব্যবহারকারীর পোস্ট আপনার ফিডে আর দেখানো হবে না।</p><button class="pill" id="showRules">কমিউনিটি নিয়ম</button></div>`}
function chatView(){if(state.chatOpen)return `<div class="row" style="margin-bottom:10px"><button class="pill" id="backChat">←</button><div><b>Nadia</b><div class="muted"><span class="status-dot"></span> অনলাইন</div></div></div><div class="card messages">${state.messages.map(m=>`<div class="bubble ${m.me?'me':''}">${esc(m.text)}</div>`).join('')}</div><div class="chatbar"><input id="msg" placeholder="মেসেজ লিখুন"><button class="btn" id="sendMsg">পাঠান</button></div>`;return `<div class="title">চ্যাট</div><div class="notice">Cloud mode চালু হলে real-time private messaging database policies দিয়ে সুরক্ষিত থাকবে।</div><div class="chat-list"><div class="card row" id="openChat"><div class="avatar">N</div><div><b>Nadia</b><div class="muted">হাই! Vibes কেমন লাগছে?</div></div></div></div>`}
function filePreview(input,target){const f=input.files?.[0];if(!f){state.upload=null;return}const video=f.type.startsWith('video/');const limit=video?(cfg.maxVideoMB||50):(cfg.maxImageMB||5);if(!f.type.startsWith('image/')&&!video){input.value='';return toast('শুধু ছবি বা ভিডিও নির্বাচন করুন')}if(f.size>limit*1024*1024){input.value='';return toast(`${video?'ভিডিও':'ছবি'}টি ${limit} MB-এর বেশি`)}state.upload=f;const url=URL.createObjectURL(f);document.getElementById(target).innerHTML=`<div class="preview">${video?`<video src="${url}" controls playsinline></video>`:`<img src="${url}" alt="preview">`}</div>`}
async function cloudBootstrap(){if(!cloudReady)return;const {data:{session}}=await sb.auth.getSession();if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await loadCloudPosts();}sb.auth.onAuthStateChange(async(_,session)=>{if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await loadCloudPosts()}else state.user=null;app()});}
async function loadCloudPosts(){if(!cloudReady)return;state.loading=true;app();const {data,error}=await sb.from('posts').select('id,user_id,body,image_url,created_at,profiles(display_name,username),likes(count),comments(id,body)').order('created_at',{ascending:false}).limit(50);state.loading=false;if(error){toast('পোস্ট লোড করা যায়নি');console.error(error);return app()}state.posts=(data||[]).filter(p=>!state.blocked.includes(p.user_id)).map(p=>({id:p.id,user:p.profiles?.display_name||'Vibes user',handle:p.profiles?.username?('@'+p.profiles.username):'@user',text:p.body,image:p.image_url,time:new Date(p.created_at).toLocaleString('bn-BD'),likes:p.likes?.[0]?.count||0,comments:(p.comments||[]).map(c=>c.body),user_id:p.user_id,liked:false}));app();}
async function authAction(){const email=document.getElementById('email').value.trim();const password=document.getElementById('password').value;if(!email||password.length<6)return toast('সঠিক ইমেইল ও কমপক্ষে 6 অক্ষরের পাসওয়ার্ড দিন');if(!cloudReady){const name=(document.getElementById('name')?.value||email.split('@')[0]).trim();state.user={id:'demo-'+Date.now(),name,email};persist();return app()}if(state.authTab==='signup'){const name=document.getElementById('name').value.trim();if(!name)return toast('নাম লিখুন');const {data,error}=await sb.auth.signUp({email,password,options:{data:{name}}});if(error)return toast(error.message);if(data.user&&!data.session)toast('ইমেইল চেক করে অ্যাকাউন্ট নিশ্চিত করুন');else toast('অ্যাকাউন্ট তৈরি হয়েছে')}else{const {error}=await sb.auth.signInWithPassword({email,password});if(error)return toast(error.message)}}
async function uploadMedia(file){if(!cloudReady||!file)return null;const ext=(file.name.split('.').pop()||(file.type.startsWith('video/')?'mp4':'jpg')).toLowerCase();const path=`${state.user.id}/${crypto.randomUUID()}.${ext}`;const {error}=await sb.storage.from('post-media').upload(path,file,{cacheControl:'3600',upsert:false,contentType:file.type});if(error)throw error;return sb.storage.from('post-media').getPublicUrl(path).data.publicUrl;}
async function addPost(txt){txt=txt.trim();if(!txt&&!state.upload)return;if(!cloudReady){let image=null,media_type='';if(state.upload){media_type=state.upload.type;image=await fileToDataUrl(state.upload)}state.posts.unshift({id:Date.now(),user:state.user.name,handle:handleOf(state.user.name),text:txt,time:'এখনই',likes:0,liked:false,comments:[],image,media_type,user_id:state.user.id});state.upload=null;persist();state.tab='feed';return app()}try{let image_url=await uploadMedia(state.upload);const {error}=await sb.from('posts').insert({user_id:state.user.id,body:txt,image_url});if(error)throw error;state.upload=null;state.tab='feed';await loadCloudPosts()}catch(e){console.error(e);toast('পোস্ট করা যায়নি')}}
function fileToDataUrl(f){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(f)})}
async function likePost(id){const p=state.posts.find(x=>String(x.id)===String(id));if(!p)return;if(!cloudReady){p.liked=!p.liked;p.likes+=p.liked?1:-1;persist();return app()}if(p.liked){await sb.from('likes').delete().eq('post_id',id).eq('user_id',state.user.id);p.liked=false;p.likes=Math.max(0,p.likes-1)}else{const {error}=await sb.from('likes').insert({post_id:id,user_id:state.user.id});if(!error){p.liked=true;p.likes++}}app()}
async function commentPost(id){const c=prompt('কমেন্ট লিখুন');if(!c?.trim())return;if(!cloudReady){state.posts.find(x=>String(x.id)===String(id)).comments.push(c.trim());persist();return app()}const {error}=await sb.from('comments').insert({post_id:id,user_id:state.user.id,body:c.trim()});if(error)return toast('কমেন্ট করা যায়নি');await loadCloudPosts()}
async function reportPost(id){const reason=prompt('রিপোর্টের কারণ সংক্ষেপে লিখুন');if(!reason?.trim())return;if(!cloudReady){state.reports.push({id,reason:reason.trim(),at:Date.now()});persist();return toast('রিপোর্ট গ্রহণ করা হয়েছে')}const {error}=await sb.from('reports').insert({reporter_id:state.user.id,post_id:id,reason:reason.trim()});toast(error?'রিপোর্ট পাঠানো যায়নি':'রিপোর্ট গ্রহণ করা হয়েছে')}
async function blockUser(userId){if(!confirm('এই ব্যবহারকারীকে ব্লক করবেন?'))return;if(!cloudReady){state.blocked.push(userId);state.posts=state.posts.filter(p=>String(p.user_id||p.user)!==String(userId));persist();return app()}const {error}=await sb.from('blocks').insert({blocker_id:state.user.id,blocked_id:userId});if(error)return toast('ব্লক করা যায়নি');state.blocked.push(userId);await loadCloudPosts()}
function baseBind(){document.getElementById('loginTab')?.addEventListener('click',()=>{state.authTab='login';app()});document.getElementById('signupTab')?.addEventListener('click',()=>{state.authTab='signup';app()});document.getElementById('authGo')?.addEventListener('click',authAction);document.getElementById('logout')?.addEventListener('click',async()=>{if(cloudReady)await sb.auth.signOut();else{state.user=null;persist();app()}});document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab;state.chatOpen=false;app()});
 document.getElementById('quickImage')?.addEventListener('change',e=>filePreview(e.target,'quickPreview'));document.getElementById('newImage')?.addEventListener('change',e=>filePreview(e.target,'newPreview'));document.getElementById('quickPostBtn')?.addEventListener('click',()=>addPost(document.getElementById('quickPost').value));document.getElementById('postBtn')?.addEventListener('click',()=>addPost(document.getElementById('newPost').value));document.querySelectorAll('[data-like]').forEach(b=>b.onclick=()=>likePost(b.dataset.like));document.querySelectorAll('[data-comment]').forEach(b=>b.onclick=()=>commentPost(b.dataset.comment));document.querySelectorAll('[data-share]').forEach(b=>b.onclick=async()=>{let p=state.posts.find(x=>String(x.id)===String(b.dataset.share));try{if(navigator.share)await navigator.share({title:'Vibes',text:p.text});else{await navigator.clipboard.writeText(p.text);toast('পোস্ট কপি হয়েছে')}}catch{}});document.querySelectorAll('[data-menu]').forEach(b=>b.onclick=()=>document.getElementById('menu-'+b.dataset.menu)?.classList.toggle('hidden'));document.querySelectorAll('[data-report]').forEach(b=>b.onclick=()=>reportPost(b.dataset.report));document.querySelectorAll('[data-block]').forEach(b=>b.onclick=()=>blockUser(b.dataset.block));document.getElementById('searchBox')?.addEventListener('input',e=>{let q=e.target.value.toLowerCase().trim();let rs=state.posts.filter(p=>(p.user+' '+p.text+' '+p.handle).toLowerCase().includes(q));document.getElementById('searchResults').innerHTML=q?(rs.length?rs.map(postCard).join(''):`<div class="empty">কিছু পাওয়া যায়নি</div>`):`<div class="empty">সার্চ শুরু করুন</div>`;bind()});document.getElementById('openChat')?.addEventListener('click',()=>{state.chatOpen=true;app()});document.getElementById('backChat')?.addEventListener('click',()=>{state.chatOpen=false;app()});document.getElementById('sendMsg')?.addEventListener('click',()=>{let i=document.getElementById('msg');if(i.value.trim()){state.messages.push({me:true,text:i.value.trim()});persist();app()}});document.getElementById('editProfile')?.addEventListener('click',async()=>{const name=prompt('নতুন নাম',state.user.name||'');if(!name?.trim())return;if(!cloudReady){state.user.name=name.trim();persist();return app()}const username=handleOf(name).slice(1);const {error}=await sb.from('profiles').upsert({id:state.user.id,display_name:name.trim(),username});if(error)return toast('প্রোফাইল আপডেট করা যায়নি');state.user.name=name.trim();app()});document.getElementById('showRules')?.addEventListener('click',()=>alert('Vibes নিয়ম: সম্মানজনক আচরণ করুন; স্প্যাম, হুমকি, হয়রানি, ঘৃণামূলক বা অবৈধ কনটেন্ট পোস্ট করবেন না; কারও ব্যক্তিগত তথ্য অনুমতি ছাড়া প্রকাশ করবেন না।'))}
(async()=>{if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});await cloudBootstrap();app()})();


// ---- Vibes Calls v1: WebRTC audio/video + Supabase signaling ----
state.people=[];
state.call={incoming:null,active:null,pc:null,localStream:null,rawLocalStream:null,remoteStream:null,muted:false,cameraOff:false,remoteDescriptionSet:false,filter:'natural',filterCleanup:null};
state.turn={servers:[],expiresAt:0,loading:null};
let callsChannel=null, iceChannel=null;

function callIceServers(){
  const stun=(cfg.iceServers&&cfg.iceServers.length)?cfg.iceServers:[{urls:'stun:stun.l.google.com:19302'}];
  return [...stun,...(cfg.turnServers||[]),...(state.turn.servers||[])];
}
async function ensureTurnCredentials(){
  if(!cloudReady||!state.user)return;
  const now=Math.floor(Date.now()/1000);
  if(state.turn.servers.length&&state.turn.expiresAt>now+120)return;
  if(state.turn.loading)return state.turn.loading;
  state.turn.loading=(async()=>{
    try{
      const {data,error}=await sb.functions.invoke('turn-credentials',{body:{}});
      if(error||!data?.iceServers)return;
      state.turn.servers=data.iceServers;state.turn.expiresAt=Number(data.expires_at||0);
    }catch(e){console.warn('TURN unavailable; continuing with STUN',e)}
    finally{state.turn.loading=null}
  })();
  return state.turn.loading;
}
async function sendCallPush(payload){
  if(!cloudReady||!state.user)return;
  try{const {error}=await sb.functions.invoke('send-call-push',{body:payload});if(error)console.warn('Call push unavailable',error)}catch(e){console.warn('Call push failed',e)}
}

async function loadPeople(){
  if(!cloudReady||!state.user)return;
  const {data,error}=await sb.from('profiles').select('id,display_name,username,avatar_url').neq('id',state.user.id).order('created_at',{ascending:false}).limit(50);
  if(!error) state.people=data||[];
}
function callPersonName(id){const p=state.people.find(x=>x.id===id);return p?.display_name||'Vibes user'}

async function setupCallRealtime(){
  if(!cloudReady||!state.user)return;
  if(callsChannel) await sb.removeChannel(callsChannel);
  if(iceChannel) await sb.removeChannel(iceChannel);
  callsChannel=sb.channel('vibes-calls-'+state.user.id)
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'calls',filter:`callee_id=eq.${state.user.id}`},payload=>{
      if(payload.new.status==='ringing'){
        state.call.incoming=payload.new;
        toast(`${payload.new.call_type==='video'?'ভিডিও':'অডিও'} কল আসছে`);
        app();
      }
    })
    .on('postgres_changes',{event:'UPDATE',schema:'public',table:'calls'},async payload=>{
      const c=payload.new;
      if(c.caller_id!==state.user.id&&c.callee_id!==state.user.id)return;
      if(state.call.active?.id===c.id){
        state.call.active=c;
        if(c.answer&&state.call.pc&&!state.call.remoteDescriptionSet&&c.caller_id===state.user.id){
          try{await state.call.pc.setRemoteDescription(new RTCSessionDescription(c.answer));state.call.remoteDescriptionSet=true;await loadExistingIce(c.id)}catch(e){console.error(e)}
        }
        if(['ended','rejected','missed'].includes(c.status)){closeCallMedia();state.call.active=null;state.call.incoming=null;toast(c.status==='rejected'?'কল রিজেক্ট হয়েছে':'কল শেষ হয়েছে');app()}
      } else if(state.call.incoming?.id===c.id && c.status!=='ringing'){
        state.call.incoming=null;app();
      }
    }).subscribe();
  iceChannel=sb.channel('vibes-ice-'+state.user.id)
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'call_ice_candidates'},async payload=>{
      const row=payload.new;
      if(!state.call.active||row.call_id!==state.call.active.id||row.user_id===state.user.id||!state.call.pc)return;
      try{await state.call.pc.addIceCandidate(new RTCIceCandidate(row.candidate))}catch(e){console.error(e)}
    }).subscribe();
}

const CALL_FILTERS={
  natural:'none',
  studio:'brightness(1.08) contrast(1.06) saturate(1.04)',
  soft:'brightness(1.06) contrast(0.96) saturate(1.03)',
  warm:'brightness(1.04) saturate(1.08) sepia(0.10)',
  cool:'brightness(1.03) saturate(1.04) hue-rotate(8deg)'
};
function callFilterLabel(k){return ({natural:'Natural',studio:'Studio Light',soft:'Soft Glow',warm:'Warm',cool:'Cool'})[k]||'Natural'}
async function makeFilteredCallStream(raw,type){
  if(type!=='video') return raw;
  const v=document.createElement('video');v.autoplay=true;v.muted=true;v.playsInline=true;v.srcObject=new MediaStream(raw.getVideoTracks());
  await v.play().catch(()=>{});
  const c=document.createElement('canvas');
  const ctx=c.getContext('2d',{alpha:false});
  let raf=0,stopped=false;
  const draw=()=>{
    if(stopped)return;
    const w=v.videoWidth||720,h=v.videoHeight||1280;
    if(c.width!==w||c.height!==h){c.width=w;c.height=h}
    ctx.filter=CALL_FILTERS[state.call.filter]||'none';
    ctx.drawImage(v,0,0,c.width,c.height);
    raf=requestAnimationFrame(draw);
  };draw();
  if(!c.captureStream) return raw;
  const processed=c.captureStream(24);
  raw.getAudioTracks().forEach(t=>processed.addTrack(t));
  state.call.filterCleanup=()=>{stopped=true;cancelAnimationFrame(raf);try{v.pause();v.srcObject=null}catch{}};
  return processed;
}
async function createPeer(callId,type){
  await ensureTurnCredentials();
  const raw=await navigator.mediaDevices.getUserMedia({audio:true,video:type==='video'});
  state.call.rawLocalStream=raw;
  const stream=await makeFilteredCallStream(raw,type);
  const pc=new RTCPeerConnection({iceServers:callIceServers()});
  const remote=new MediaStream();
  stream.getTracks().forEach(t=>pc.addTrack(t,stream));
  pc.ontrack=e=>{e.streams[0].getTracks().forEach(t=>{if(!remote.getTracks().some(x=>x.id===t.id))remote.addTrack(t)});attachCallMedia()};
  pc.onicecandidate=async e=>{if(e.candidate&&cloudReady&&state.user){await sb.from('call_ice_candidates').insert({call_id:callId,user_id:state.user.id,candidate:e.candidate.toJSON()})}};
  pc.onconnectionstatechange=()=>{if(['failed','closed'].includes(pc.connectionState)&&state.call.active)toast('কল সংযোগ বিচ্ছিন্ন হয়েছে')};
  state.call.pc=pc;state.call.localStream=stream;state.call.remoteStream=remote;state.call.remoteDescriptionSet=false;
  return pc;
}
async function loadExistingIce(callId){
  if(!state.call.pc)return;
  const {data}=await sb.from('call_ice_candidates').select('id,user_id,candidate').eq('call_id',callId).neq('user_id',state.user.id).order('id');
  for(const row of data||[]){try{await state.call.pc.addIceCandidate(new RTCIceCandidate(row.candidate))}catch{}}
}
async function startCall(targetId,type='audio'){
  if(!cloudReady)return toast('Real call-এর জন্য Cloud mode দরকার');
  if(!navigator.mediaDevices?.getUserMedia)return toast('এই ডিভাইসে camera/microphone API পাওয়া যায়নি');
  try{
    const {data:call,error}=await sb.from('calls').insert({caller_id:state.user.id,callee_id:targetId,call_type:type,status:'ringing'}).select().single();
    if(error)throw error;
    state.call.active=call;state.call.incoming=null;app();
    const pc=await createPeer(call.id,type);
    const offer=await pc.createOffer();await pc.setLocalDescription(offer);
    const {error:upErr}=await sb.from('calls').update({offer:pc.localDescription.toJSON()}).eq('id',call.id);
    if(upErr)throw upErr;
    sendCallPush({call_id:call.id});
    await loadExistingIce(call.id);app();
  }catch(e){console.error(e);closeCallMedia();state.call.active=null;toast('কল শুরু করা যায়নি');app()}
}
async function acceptCall(){try{window.VibesNative?.clearIncomingCall()}catch{}
  const c=state.call.incoming;if(!c)return;
  try{
    state.call.active=c;state.call.incoming=null;app();
    const pc=await createPeer(c.id,c.call_type);
    if(!c.offer){const {data}=await sb.from('calls').select('*').eq('id',c.id).single();Object.assign(c,data||{})}
    await pc.setRemoteDescription(new RTCSessionDescription(c.offer));state.call.remoteDescriptionSet=true;
    const answer=await pc.createAnswer();await pc.setLocalDescription(answer);
    await sb.from('calls').update({answer:pc.localDescription.toJSON(),status:'accepted',accepted_at:new Date().toISOString()}).eq('id',c.id);
    await loadExistingIce(c.id);app();
  }catch(e){console.error(e);toast('কল গ্রহণ করা যায়নি');await endCall()}
}
async function rejectCall(){try{window.VibesNative?.clearIncomingCall()}catch{}const c=state.call.incoming;if(!c)return;await sb.from('calls').update({status:'rejected',ended_at:new Date().toISOString()}).eq('id',c.id);state.call.incoming=null;app()}
async function endCall(){try{window.VibesNative?.clearIncomingCall()}catch{}const c=state.call.active;if(c&&cloudReady)await sb.from('calls').update({status:'ended',ended_at:new Date().toISOString()}).eq('id',c.id);closeCallMedia();state.call.active=null;state.call.incoming=null;app()}
function closeCallMedia(){try{state.call.filterCleanup?.()}catch{}try{state.call.localStream?.getTracks().forEach(t=>t.stop())}catch{}try{state.call.rawLocalStream?.getTracks().forEach(t=>t.stop())}catch{}try{state.call.pc?.close()}catch{}state.call.pc=null;state.call.localStream=null;state.call.rawLocalStream=null;state.call.remoteStream=null;state.call.remoteDescriptionSet=false;state.call.muted=false;state.call.cameraOff=false;state.call.filter='natural';state.call.filterCleanup=null}
function toggleMute(){const tracks=state.call.localStream?.getAudioTracks()||[];state.call.muted=!state.call.muted;tracks.forEach(t=>t.enabled=!state.call.muted);app()}
function toggleCamera(){const tracks=state.call.rawLocalStream?.getVideoTracks()||state.call.localStream?.getVideoTracks()||[];state.call.cameraOff=!state.call.cameraOff;tracks.forEach(t=>t.enabled=!state.call.cameraOff);app()}
function setCallFilter(mode){if(!CALL_FILTERS[mode])return;state.call.filter=mode;app()}
function attachCallMedia(){const lv=document.getElementById('localVideo'),rv=document.getElementById('remoteVideo');if(lv&&state.call.localStream&&lv.srcObject!==state.call.localStream){lv.srcObject=state.call.localStream;lv.muted=true;lv.play().catch(()=>{})}if(rv&&state.call.remoteStream&&rv.srcObject!==state.call.remoteStream){rv.srcObject=state.call.remoteStream;rv.play().catch(()=>{})}}
function activeCallUI(){
  const c=state.call.active;if(!c)return '';
  const other=c.caller_id===state.user.id?c.callee_id:c.caller_id;const name=callPersonName(other);const video=c.call_type==='video';
  return `<div class="call-screen"><div class="call-title">${esc(name)}</div><div class="muted">${video?'ভিডিও কল':'অডিও কল'} · ${c.status==='ringing'?'কল হচ্ছে…':c.status==='accepted'?'সংযুক্ত':'সংযোগ হচ্ছে…'}</div>${video?`<div class="video-stage"><video id="remoteVideo" autoplay playsinline></video><video id="localVideo" autoplay muted playsinline></video></div><div class="call-filters">${Object.keys(CALL_FILTERS).map(k=>`<button class="filter-chip ${state.call.filter===k?'active':''}" data-call-filter="${k}">${callFilterLabel(k)}</button>`).join('')}</div>`:`<div class="call-avatar">${esc(name[0]||'V')}</div><audio id="remoteVideo" autoplay></audio>`}<div class="call-actions"><button class="call-round" id="muteCall">${state.call.muted?'🔇':'🎤'}</button>${video?`<button class="call-round" id="cameraCall">${state.call.cameraOff?'📷✕':'📹'}</button>`:''}<button class="call-round danger" id="endCall">📞</button></div></div>`
}
function incomingCallUI(){const c=state.call.incoming;if(!c)return '';const name=callPersonName(c.caller_id);return `<div class="incoming-call"><div class="call-avatar small">${esc(name[0]||'V')}</div><div class="grow"><b>${esc(name)}</b><div class="muted">${c.call_type==='video'?'ভিডিও':'অডিও'} কল আসছে…</div></div><button class="call-round accept" id="acceptCall">✓</button><button class="call-round danger" id="rejectCall">✕</button></div>`}
function chatView(){
  if(state.call.active)return activeCallUI();
  const incoming=incomingCallUI();
  if(state.chatOpen)return `${incoming}<div class="row" style="margin-bottom:10px"><button class="pill" id="backChat">←</button><div class="grow"><b>Nadia</b><div class="muted"><span class="status-dot"></span> চ্যাট</div></div></div><div class="card messages">${state.messages.map(m=>`<div class="bubble ${m.me?'me':''}">${esc(m.text)}</div>`).join('')}</div><div class="chatbar"><input id="msg" placeholder="মেসেজ লিখুন"><button class="btn" id="sendMsg">পাঠান</button></div>`;
  const people=state.people.length?state.people.map(p=>`<div class="card row person-row"><div class="avatar">${esc((p.display_name||'V')[0])}</div><div class="grow"><b>${esc(p.display_name||'Vibes user')}</b><div class="muted">${esc(p.username?'@'+p.username:'Vibes')}</div></div><button class="call-mini" data-audio-call="${p.id}" title="Audio call">📞</button><button class="call-mini" data-video-call="${p.id}" title="Video call">📹</button></div>`).join(''):`<div class="empty">আরও ব্যবহারকারী যোগ হলে এখানে Audio/Video call করা যাবে।</div>`;
  return `${incoming}<div class="title">চ্যাট ও কল</div><div class="notice">Vibes-to-Vibes encrypted WebRTC media connection ব্যবহার করে Audio/Video call করা হবে।</div><div class="chat-list">${people}</div>`
}

async function cloudBootstrap(){
  if(!cloudReady)return;
  const {data:{session}}=await sb.auth.getSession();
  if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople()]);await setupCallRealtime()}
  sb.auth.onAuthStateChange(async(_,session)=>{if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople()]);await setupCallRealtime()}else{closeCallMedia();state.user=null}app()});
}

// ---- Vibes 1.17: automatic Facebook Page imports, real private chat and rich profiles ----
state.meProfile=null;
state.conversations=[];
state.chatMessages=[];
state.activeConversationId=null;
state.activeChatUser=null;
state.profileAvatarFile=null;
state.profileCoverFile=null;
let messagesChannel=null;
let externalPostsChannel=null;
let externalRefreshTimer=null;
const RICH_PROFILE_FIELDS='id,display_name,first_name,middle_name,last_name,username,bio,avatar_url,cover_url,nickname,current_city,hometown,work,education,relationship_status,website,preferred_language,is_private,allow_messages,account_status,verification_status,premium_status,premium_until,show_premium_badge,update_channel,product_updates,created_at';

nav=function(){
  const items=[['feed','🏠',tr('home')],['search','🔎','Search'],['create','➕',tr('post')],['chat','💬','Chat'],['notifications','🔔',tr('notifications')],['profile','👤',tr('profile')]];
  return `<nav class="nav nav-six">${items.map(x=>`<button data-tab="${x[0]}" class="${state.tab===x[0]?'active':''}"><span class="ico">${x[1]}</span>${x[2]}</button>`).join('')}</nav>`;
};

async function loadRichProfile(){
  if(!cloudReady||!state.user)return;
  const {data,error}=await sb.from('profiles').select(RICH_PROFILE_FIELDS).eq('id',state.user.id).single();
  if(!error&&data){state.meProfile=data;state.user={...state.user,name:data.display_name,display_name:data.display_name,username:data.username,avatar_url:data.avatar_url}}
}

loadPeople=async function(){
  if(!cloudReady||!state.user)return;
  const {data,error}=await sb.from('profiles').select(RICH_PROFILE_FIELDS).neq('id',state.user.id).order('created_at',{ascending:false}).limit(80);
  if(!error)state.people=data||[];
};

searchPeople=async function(query){
  state.searchQuery=query.trim();
  if(!cloudReady||!state.searchQuery){state.userSearchResults=[];return renderPeopleSearch()}
  const term=state.searchQuery.replace(/^@/,'').slice(0,50);
  const [byName,byUsername]=await Promise.all([
    sb.from('profiles').select(RICH_PROFILE_FIELDS).ilike('display_name',`%${term}%`).limit(20),
    sb.from('profiles').select(RICH_PROFILE_FIELDS).ilike('username',`%${term}%`).limit(20)
  ]);
  state.userSearchResults=[...new Map([...(byName.data||[]),...(byUsername.data||[])].map(p=>[p.id,p])).values()].slice(0,20);
  renderPeopleSearch();
};

openPersonProfile=async function(userId){
  if(!userId)return;
  let person=[state.meProfile,...state.userSearchResults,...state.people].find(p=>p?.id===userId);
  if(cloudReady){const {data}=await sb.from('profiles').select(RICH_PROFILE_FIELDS).eq('id',userId).single();if(data)person=data}
  if(!person)return;
  state.profile=person;state.tab='profile';await loadProfileStats(userId);app();
};

function relationshipLabel(value){return({single:'Single',in_a_relationship:'In a relationship',engaged:'Engaged',married:'Married',complicated:'It’s complicated',prefer_not_to_say:'Not specified'})[value]||''}
function profileDetail(icon,label,value,link=false){if(!value)return'';const shown=link?`<a href="${esc(value)}" target="_blank" rel="noopener noreferrer">${esc(value)}</a>`:esc(value);return `<div class="profile-detail"><span>${icon}</span><div><small>${esc(label)}</small><div>${shown}</div></div></div>`}

function richProfileView(){
  const selected=state.profile||state.meProfile||state.user||{};
  const own=!state.profile||selected.id===state.user?.id;
  const u=own?(state.meProfile||selected):selected;
  const name=u.display_name||u.name||u.user_metadata?.name||u.email?.split('@')[0]||'Vibes User';
  const stats=own?state.followCounts:(state.profileStats[u.id]||{followers:0,following:0});
  const postCount=state.posts.filter(p=>!p.external&&(p.user_id===u.id||p.user===name)).length;
  const following=state.followingIds.includes(u.id);
  const details=[profileDetail('✦','Nickname',u.nickname),profileDetail('📍','Lives in',u.current_city),profileDetail('🏡','From',u.hometown),profileDetail('💼','Work',u.work),profileDetail('🎓','Education',u.education),profileDetail('♡','Relationship',relationshipLabel(u.relationship_status)),profileDetail('🔗','Website',u.website,true)].join('');
  return `<div class="card profile-head rich-profile"><div class="profile-cover" ${u.cover_url?`style="background-image:url('${esc(u.cover_url)}')"`:''}></div><div class="avatar lg profile-avatar">${u.avatar_url?`<img src="${esc(u.avatar_url)}" alt="">`:esc(name[0]||'V')}</div><div class="title">${esc(name)} ${u.verification_status==='verified'?'<span class="verified-badge" title="Authenticity reviewed">✓</span>':''}</div>${u.nickname?`<div class="muted">${esc(u.nickname)}</div>`:''}<div class="muted">${esc(u.username?'@'+u.username:(u.handle||handleOf(name)))}</div>${u.bio?`<p class="profile-bio">${esc(u.bio)}</p>`:''}<div class="stats"><div class="stat"><b>${postCount}</b><div class="muted">Posts</div></div><div class="stat"><b>${stats.followers||0}</b><div class="muted">Followers</div></div><div class="stat"><b>${stats.following||0}</b><div class="muted">Following</div></div></div>${own?'<button class="btn light" id="openRichProfileEdit">Edit profile</button> <button class="pill" id="openSettings">⚙ Settings</button>':`<button class="btn ${following?'light':''}" data-follow-user="${esc(u.id)}">${following?'Unfollow':'Follow'}</button> <button class="pill" data-start-message="${esc(u.id)}">💬 Message</button>`}</div>${details?`<div class="card profile-details"><div class="section-title">About</div>${details}</div>`:''}${own?'<div class="card"><div class="section-title">Safety & community</div><p class="muted">Illegal content, sexual harassment, threats, hate and fraud are not allowed. Use Report, Block or Restrict when needed.</p><button class="pill" id="openSafety">🛡 Safety controls</button></div>':''}`;
}
profileView=richProfileView;

function richProfileEditView(){
  const u=state.meProfile||{};
  const input=(id,label,value='',max=120,type='text')=>`<label class="profile-field"><span>${label}</span><input id="${id}" type="${type}" maxlength="${max}" value="${esc(value||'')}"></label>`;
  return `<div class="row"><button class="pill" id="profileEditBack">←</button><div class="title grow">Edit profile</div></div><div class="card profile-media-editor"><div class="profile-cover preview-cover" id="coverPreview" ${u.cover_url?`style="background-image:url('${esc(u.cover_url)}')"`:''}></div><label class="pill">Cover photo<input id="profileCoverFile" type="file" accept="image/*" hidden></label><div class="avatar lg" id="avatarPreview">${u.avatar_url?`<img src="${esc(u.avatar_url)}" alt="">`:esc((u.display_name||'V')[0])}</div><label class="pill">Profile photo<input id="profileAvatarFile" type="file" accept="image/*" hidden></label></div><div class="card profile-form">${input('profileDisplayName','Display name',u.display_name,50)}${input('profileUsername','Username',u.username,40)}${input('profileNickname','Nickname',u.nickname,50)}<label class="profile-field"><span>Bio</span><textarea id="profileBio" maxlength="240">${esc(u.bio||'')}</textarea></label>${input('profileCity','Current city',u.current_city,100)}${input('profileHometown','Hometown',u.hometown,100)}${input('profileWork','Work',u.work,120)}${input('profileEducation','Education',u.education,120)}<label class="profile-field"><span>Relationship</span><select id="profileRelationship"><option value="">Not shown</option>${[['single','Single'],['in_a_relationship','In a relationship'],['engaged','Engaged'],['married','Married'],['complicated','It’s complicated'],['prefer_not_to_say','Prefer not to say']].map(([v,l])=>`<option value="${v}" ${u.relationship_status===v?'selected':''}>${l}</option>`).join('')}</select></label>${input('profileWebsite','Website (HTTPS)',u.website,300,'url')}</div><button class="btn" id="saveRichProfile" style="width:100%">Save profile</button>`;
}

async function saveRichProfile(){
  const display_name=document.getElementById('profileDisplayName').value.trim(),username=document.getElementById('profileUsername').value.trim().replace(/^@/,'').toLowerCase();
  if(!display_name)return toast('Display name is required');
  if(username&&!/^[a-z0-9._]{3,40}$/.test(username))return toast('Username: 3–40 letters, numbers, dot or underscore');
  const website=document.getElementById('profileWebsite').value.trim();
  if(website){try{if(new URL(website).protocol!=='https:')throw 0}catch{return toast('Website must start with https://')}}
  const update={display_name,username:username||null,bio:document.getElementById('profileBio').value.trim(),nickname:document.getElementById('profileNickname').value.trim(),current_city:document.getElementById('profileCity').value.trim(),hometown:document.getElementById('profileHometown').value.trim(),work:document.getElementById('profileWork').value.trim(),education:document.getElementById('profileEducation').value.trim(),relationship_status:document.getElementById('profileRelationship').value,website};
  try{
    if(state.profileAvatarFile)update.avatar_url=await uploadMedia(state.profileAvatarFile);
    if(state.profileCoverFile)update.cover_url=await uploadMedia(state.profileCoverFile);
    const {data,error}=await sb.from('profiles').update(update).eq('id',state.user.id).select(RICH_PROFILE_FIELDS).single();
    if(error)throw error;
    state.meProfile=data;state.user={...state.user,name:data.display_name,display_name:data.display_name,username:data.username,avatar_url:data.avatar_url};state.profile=null;state.profileAvatarFile=null;state.profileCoverFile=null;state.tab='profile';toast('Profile saved');app();
  }catch(error){console.error(error);toast(error?.code==='23505'?'Username is already used':'Profile could not be saved')}
}

function previewProfileImage(input,target,cover=false){const file=input.files?.[0];if(!file)return;if(!file.type.startsWith('image/'))return toast('Choose an image');const url=URL.createObjectURL(file);if(cover){state.profileCoverFile=file;document.getElementById(target).style.backgroundImage=`url('${url}')`}else{state.profileAvatarFile=file;document.getElementById(target).innerHTML=`<img src="${url}" alt="preview">`}}

async function loadConversations(){
  if(!cloudReady||!state.user)return;
  const {data:mine,error}=await sb.from('conversation_members').select('conversation_id').eq('user_id',state.user.id);
  if(error){console.warn('Conversation list unavailable',error);return}
  const ids=(mine||[]).map(x=>x.conversation_id);
  if(!ids.length){state.conversations=[];state.chatMessages=[];return}
  const [membersResult,messagesResult]=await Promise.all([
    sb.from('conversation_members').select('conversation_id,user_id,profiles(id,display_name,username,avatar_url)').in('conversation_id',ids),
    sb.from('messages').select('id,conversation_id,sender_id,body,created_at').in('conversation_id',ids).order('created_at',{ascending:true}).limit(500)
  ]);
  if(messagesResult.error||membersResult.error)return console.warn('Private messages unavailable',messagesResult.error||membersResult.error);
  state.chatMessages=messagesResult.data||[];
  state.conversations=ids.map(id=>{const other=(membersResult.data||[]).find(m=>m.conversation_id===id&&m.user_id!==state.user.id)?.profiles||null;const messages=state.chatMessages.filter(m=>m.conversation_id===id);return{id,other,last:messages[messages.length-1]||null}}).filter(c=>c.other).sort((a,b)=>new Date(b.last?.created_at||0)-new Date(a.last?.created_at||0));
  if(state.activeConversationId){const active=state.conversations.find(c=>c.id===state.activeConversationId);if(active)state.activeChatUser=active.other}
}

async function startDirectChat(userId){
  if(!cloudReady)return toast('Cloud login is required for private chat');
  const {data,error}=await sb.rpc('start_direct_conversation',{other_user:userId});
  if(error){console.warn(error);return toast(error.message?.includes('messaging_not_allowed')?'This account is not accepting new messages':'Chat could not be opened')}
  await loadConversations();state.activeConversationId=data;state.activeChatUser=state.conversations.find(c=>c.id===data)?.other||state.people.find(p=>p.id===userId)||null;state.chatOpen=true;state.tab='chat';app();
}

async function sendCloudMessage(){
  const input=document.getElementById('cloudMessageInput'),body=input?.value.trim();if(!body||!state.activeConversationId)return;
  input.disabled=true;
  const {data,error}=await sb.from('messages').insert({conversation_id:state.activeConversationId,sender_id:state.user.id,body}).select('id,conversation_id,sender_id,body,created_at').single();
  if(error){input.disabled=false;return toast('Message could not be sent')}
  if(!state.chatMessages.some(m=>m.id===data.id))state.chatMessages.push(data);input.value='';await loadConversations();app();
}

async function setupMessageRealtime(){
  if(!cloudReady||!state.user)return;if(messagesChannel)await sb.removeChannel(messagesChannel);
  messagesChannel=sb.channel(`vibes-messages-${state.user.id}`).on('postgres_changes',{event:'INSERT',schema:'public',table:'messages'},async payload=>{if(!state.chatMessages.some(m=>m.id===payload.new.id))state.chatMessages.push(payload.new);await loadConversations();app()}).subscribe();
}

async function setupExternalPostRealtime(){
  if(!cloudReady||!state.user)return;if(externalPostsChannel)await sb.removeChannel(externalPostsChannel);
  externalPostsChannel=sb.channel(`vibes-external-${state.user.id}`).on('postgres_changes',{event:'*',schema:'public',table:'external_posts'},()=>{clearTimeout(externalRefreshTimer);externalRefreshTimer=setTimeout(loadCloudPosts,350)}).subscribe();
}

chatView=function(){
  if(state.group?.active)return groupCallUI();if(state.call?.active)return activeCallUI();const incoming=incomingCallUI();
  if(state.activeConversationId){const other=state.activeChatUser||state.conversations.find(c=>c.id===state.activeConversationId)?.other||{};const messages=state.chatMessages.filter(m=>m.conversation_id===state.activeConversationId);return `${incoming}<div class="row chat-head"><button class="pill" id="backCloudChat">←</button><div class="avatar">${other.avatar_url?`<img src="${esc(other.avatar_url)}" alt="">`:esc((other.display_name||'V')[0])}</div><div class="grow"><b>${esc(other.display_name||'Vibes user')}</b><div class="muted">${esc(other.username?'@'+other.username:'Private conversation')}</div></div><button class="call-mini" data-audio-call="${esc(other.id||'')}" title="Audio call">📞</button><button class="call-mini" data-video-call="${esc(other.id||'')}" title="Video call">📹</button></div><div class="card messages cloud-messages">${messages.length?messages.map(m=>`<div class="message-unit"><div class="bubble ${m.sender_id===state.user.id?'me':''}">${esc(m.body)}</div>${reactionBar('message',m.id)}</div>`).join(''):'<div class="empty compact">Start the conversation</div>'}</div><div class="chatbar"><div class="composer-wrap grow"><input id="cloudMessageInput" maxlength="4000" placeholder="Write a message">${emojiPicker('cloudMessageInput')}</div><button class="btn" id="sendCloudMessage">Send</button></div>`}
  const conversationRows=state.conversations.map(c=>`<button class="card row conversation-row" data-open-conversation="${esc(c.id)}"><div class="avatar">${c.other.avatar_url?`<img src="${esc(c.other.avatar_url)}" alt="">`:esc((c.other.display_name||'V')[0])}</div><div class="grow"><b>${esc(c.other.display_name||'Vibes user')}</b><div class="muted message-preview">${esc(c.last?.body||'Tap to start chatting')}</div></div></button>`).join('');
  const known=new Set(state.conversations.map(c=>c.other.id));const people=state.people.filter(p=>!known.has(p.id)).slice(0,30).map(p=>`<div class="card row person-row"><div class="avatar">${p.avatar_url?`<img src="${esc(p.avatar_url)}" alt="">`:esc((p.display_name||'V')[0])}</div><div class="grow"><b>${esc(p.display_name||'Vibes user')}</b><div class="muted">${esc(p.username?'@'+p.username:'Vibes')}</div></div><button class="pill" data-start-message="${esc(p.id)}">Message</button><button class="call-mini" data-audio-call="${esc(p.id)}">📞</button><button class="call-mini" data-video-call="${esc(p.id)}">📹</button></div>`).join('');
  return `${incoming}<div class="title">Messages & calls</div><div class="notice">Private messages are protected by database membership rules. Calls use encrypted WebRTC transport.</div>${conversationRows?`<div class="section-title">Conversations</div><div class="chat-list">${conversationRows}</div>`:''}<div class="section-title">People</div><div class="chat-list">${people||'<div class="empty">No other accounts yet.</div>'}</div>`;
};

const viewBeforeV117=view;
view=function(){if(state.tab==='editProfile')return richProfileEditView();return viewBeforeV117()};

const settingsBeforeV117=settingsWithSafety;
settingsWithSafety=function(){
  return settingsBeforeV117().replace('<button class="btn" id="saveSettings"',`<div class="card legal-settings"><div class="section-title">Legal & account</div><a class="pill" href="privacy.html">Privacy policy</a> <a class="pill" href="terms.html">Terms</a><p class="muted">Deleting your account permanently removes the account and its Vibes content.</p><button class="btn danger" id="deleteVibesAccount">Delete account</button></div><button class="btn" id="saveSettings"`);
};

async function deleteVibesAccount(){
  const confirmation=prompt('Permanent deletion cannot be undone. Type DELETE to continue:','');if(confirmation!=='DELETE')return;
  const {data,error}=await sb.functions.invoke('delete-account',{body:{confirmation}});if(error||!data?.deleted)return toast('Account could not be deleted');
  try{await sb.auth.signOut({scope:'local'})}catch{}localStorage.removeItem(demoKey);state.user=null;state.meProfile=null;state.posts=[];toast('Account deleted');app();
}

syncOfficialSocialPosts=async function(){
  if(!cloudReady||!state.user)return;
  const results=await Promise.allSettled(['sync-instagram-posts','sync-facebook-posts'].map(name=>sb.functions.invoke(name,{body:{}})));
  const imported=results.reduce((sum,result)=>sum+(result.status==='fulfilled'&&!result.value.error?Number(result.value.data?.imported||0):0),0);
  if(imported>0)await loadCloudPosts();
};

const bindBeforeV117=bindSafety;
bindSafety=function(){
  bindBeforeV117();
  document.getElementById('openRichProfileEdit')?.addEventListener('click',()=>{state.profileAvatarFile=null;state.profileCoverFile=null;state.tab='editProfile';app()});
  document.getElementById('profileEditBack')?.addEventListener('click',()=>{state.tab='profile';app()});
  document.getElementById('profileAvatarFile')?.addEventListener('change',e=>previewProfileImage(e.target,'avatarPreview'));
  document.getElementById('profileCoverFile')?.addEventListener('change',e=>previewProfileImage(e.target,'coverPreview',true));
  document.getElementById('saveRichProfile')?.addEventListener('click',saveRichProfile);
  document.querySelectorAll('[data-start-message]').forEach(b=>b.onclick=()=>startDirectChat(b.dataset.startMessage));
  document.querySelectorAll('[data-open-conversation]').forEach(b=>b.onclick=()=>{const c=state.conversations.find(x=>x.id===b.dataset.openConversation);state.activeConversationId=c?.id||null;state.activeChatUser=c?.other||null;state.chatOpen=true;app()});
  document.getElementById('backCloudChat')?.addEventListener('click',()=>{state.activeConversationId=null;state.activeChatUser=null;state.chatOpen=false;app()});
  document.getElementById('sendCloudMessage')?.addEventListener('click',sendCloudMessage);
  document.getElementById('cloudMessageInput')?.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendCloudMessage()}});
  document.getElementById('deleteVibesAccount')?.addEventListener('click',deleteVibesAccount);
};

async function cloudBootstrapV117(){
  if(!cloudReady)return;
  const hydrate=async session=>{
    state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};
    await loadRichProfile();
    await Promise.all([loadVerificationRequest(),loadPremiumEntitlement(),loadFutureSystem(),setupTrustRealtime(),setupFutureRealtime()]);
    if(state.meProfile?.account_status&&state.meProfile.account_status!=='active'){app();return}
    await Promise.all([loadPeople(),loadSocialWithReactions(),loadSafetyData(),loadFollowData(),loadFeatureRequests()]);
    await Promise.all([loadCloudPosts(),loadConversations()]);
    await Promise.all([setupCallRealtime(),setupGroupRealtime(),setupMessageRealtime(),setupExternalPostRealtime(),setupIdeasRealtime()]);
    await registerNativePushToken();syncOfficialSocialPosts();
  };
  const {data:{session}}=await sb.auth.getSession();if(session?.user)await hydrate(session);
    sb.auth.onAuthStateChange(async(_,next)=>{if(next?.user)await hydrate(next);else{closeCallMedia();if(messagesChannel)await sb.removeChannel(messagesChannel);if(externalPostsChannel)await sb.removeChannel(externalPostsChannel);if(ideasChannel)await sb.removeChannel(ideasChannel);if(trustChannel)await sb.removeChannel(trustChannel);if(futureChannel)await sb.removeChannel(futureChannel);state.user=null;state.meProfile=null;state.activeConversationId=null;state.featureRequests=[];state.verificationRequest=null;state.premiumEntitlement=null;state.latestRelease=null;state.featureFlags={}}app()});
}
function app(){document.getElementById('app').innerHTML=state.user?mainUI():authUI();bind();setTimeout(attachCallMedia,0)}
function bind(){
  baseBind();
  document.querySelectorAll('[data-audio-call]').forEach(b=>b.onclick=()=>startCall(b.dataset.audioCall,'audio'));
  document.querySelectorAll('[data-video-call]').forEach(b=>b.onclick=()=>startCall(b.dataset.videoCall,'video'));
  document.getElementById('acceptCall')?.addEventListener('click',acceptCall);
  document.getElementById('rejectCall')?.addEventListener('click',rejectCall);
  document.getElementById('endCall')?.addEventListener('click',endCall);
  document.getElementById('muteCall')?.addEventListener('click',toggleMute);
  document.getElementById('cameraCall')?.addEventListener('click',toggleCamera);
  document.querySelectorAll('[data-call-filter]').forEach(b=>b.onclick=()=>setCallFilter(b.dataset.callFilter));
}

// ---- Vibes Calls v2: background effects, camera switch, small group calls ----
state.call.facingMode=state.call.facingMode||'user';
state.call.bgEffect=state.call.bgEffect||'none';
state.call.virtualBg=state.call.virtualBg||null;
state.group={incoming:null,active:null,rawLocalStream:null,localStream:null,peers:{},remotes:{},muted:false,cameraOff:false,facingMode:'user',selected:[],channel:null};
let groupRealtimeChannel=null;

function drawVirtualBackground(ctx,w,h,img){
  if(img&&img.complete){ctx.drawImage(img,0,0,w,h);return}
  const g=ctx.createLinearGradient(0,0,w,h);g.addColorStop(0,'#32125f');g.addColorStop(.5,'#5d28d8');g.addColorStop(1,'#00a9d8');ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
}

async function makeFilteredCallStream(raw,type){
  if(type!=='video') return raw;
  const v=document.createElement('video');v.autoplay=true;v.muted=true;v.playsInline=true;v.srcObject=new MediaStream(raw.getVideoTracks());
  await v.play().catch(()=>{});
  const c=document.createElement('canvas');const ctx=c.getContext('2d',{alpha:false});
  let raf=0,stopped=false,busy=false,latest=null,bgImg=null;
  if(state.call.virtualBg){bgImg=new Image();bgImg.src=state.call.virtualBg}
  let segmenter=null;
  if(window.SelfieSegmentation){
    try{
      segmenter=new SelfieSegmentation({locateFile:f=>`https://cdn.jsdelivr.net/npm/@mediapipe/selfie_segmentation/${f}`});
      segmenter.setOptions({modelSelection:1});segmenter.onResults(r=>{latest=r});
    }catch(e){console.warn('Segmentation unavailable',e)}
  }
  const draw=()=>{
    if(stopped)return;
    const w=v.videoWidth||720,h=v.videoHeight||1280;if(c.width!==w||c.height!==h){c.width=w;c.height=h}
    ctx.save();ctx.clearRect(0,0,w,h);
    const effect=state.call.bgEffect;
    if(effect!=='none'&&latest?.segmentationMask){
      ctx.drawImage(latest.segmentationMask,0,0,w,h);
      ctx.globalCompositeOperation='source-in';ctx.filter=CALL_FILTERS[state.call.filter]||'none';ctx.drawImage(v,0,0,w,h);
      ctx.globalCompositeOperation='destination-over';
      if(effect==='blur'){ctx.filter='blur(18px)';ctx.drawImage(v,-18,-18,w+36,h+36)}
      else {ctx.filter='none';drawVirtualBackground(ctx,w,h,bgImg)}
      ctx.globalCompositeOperation='source-over';
    }else{
      ctx.filter=CALL_FILTERS[state.call.filter]||'none';ctx.drawImage(v,0,0,w,h);
    }
    ctx.restore();
    if(effect!=='none'&&segmenter&&!busy){busy=true;segmenter.send({image:v}).catch(()=>{}).finally(()=>busy=false)}
    raf=requestAnimationFrame(draw);
  };draw();
  if(!c.captureStream)return raw;
  const processed=c.captureStream(24);raw.getAudioTracks().forEach(t=>processed.addTrack(t));
  state.call.filterCleanup=()=>{stopped=true;cancelAnimationFrame(raf);try{segmenter?.close?.()}catch{}try{v.pause();v.srcObject=null}catch{}};
  return processed;
}

async function createPeer(callId,type){
  await ensureTurnCredentials();
  const raw=await navigator.mediaDevices.getUserMedia({audio:true,video:type==='video'?{facingMode:{ideal:state.call.facingMode}}:false});
  state.call.rawLocalStream=raw;const stream=await makeFilteredCallStream(raw,type);
  const pc=new RTCPeerConnection({iceServers:callIceServers()});const remote=new MediaStream();
  stream.getTracks().forEach(t=>pc.addTrack(t,stream));
  pc.ontrack=e=>{e.streams[0].getTracks().forEach(t=>{if(!remote.getTracks().some(x=>x.id===t.id))remote.addTrack(t)});attachCallMedia()};
  pc.onicecandidate=async e=>{if(e.candidate&&cloudReady&&state.user)await sb.from('call_ice_candidates').insert({call_id:callId,user_id:state.user.id,candidate:e.candidate.toJSON()})};
  pc.onconnectionstatechange=()=>{if(['failed','closed'].includes(pc.connectionState)&&state.call.active)toast('কল সংযোগ বিচ্ছিন্ন হয়েছে')};
  state.call.pc=pc;state.call.localStream=stream;state.call.remoteStream=remote;state.call.remoteDescriptionSet=false;return pc;
}

async function rebuildProcessedVideo(){
  if(!state.call.active||state.call.active.call_type!=='video'||!state.call.rawLocalStream)return;
  try{
    state.call.filterCleanup?.();const stream=await makeFilteredCallStream(state.call.rawLocalStream,'video');
    const newTrack=stream.getVideoTracks()[0];const sender=state.call.pc?.getSenders().find(s=>s.track?.kind==='video');if(sender&&newTrack)await sender.replaceTrack(newTrack);
    const oldProcessed=state.call.localStream;state.call.localStream=stream;oldProcessed?.getVideoTracks().forEach(t=>{if(t.id!==newTrack?.id)t.stop()});app();
  }catch(e){console.error(e);toast('ভিডিও effect বদলানো যায়নি')}
}
function setCallFilter(mode){if(!CALL_FILTERS[mode])return;state.call.filter=mode;rebuildProcessedVideo()}
function setCallBackground(mode){if(!['none','blur','virtual'].includes(mode))return;state.call.bgEffect=mode;rebuildProcessedVideo()}
async function pickVirtualBackground(file){if(!file)return;if(!file.type.startsWith('image/'))return toast('ছবি নির্বাচন করুন');const r=new FileReader();r.onload=()=>{state.call.virtualBg=r.result;state.call.bgEffect='virtual';rebuildProcessedVideo()};r.readAsDataURL(file)}
async function switchCamera(){
  if(!state.call.active||state.call.active.call_type!=='video')return;
  try{
    const next=state.call.facingMode==='user'?'environment':'user';const media=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:next}},audio:false});const newTrack=media.getVideoTracks()[0];
    const old=state.call.rawLocalStream.getVideoTracks();old.forEach(t=>{state.call.rawLocalStream.removeTrack(t);t.stop()});state.call.rawLocalStream.addTrack(newTrack);state.call.facingMode=next;await rebuildProcessedVideo();toast(next==='user'?'ফ্রন্ট ক্যামেরা':'ব্যাক ক্যামেরা');
  }catch(e){console.error(e);toast('ক্যামেরা বদলানো যায়নি')}
}

function activeCallUI(){
  const c=state.call.active;if(!c)return '';const other=c.caller_id===state.user.id?c.callee_id:c.caller_id;const name=callPersonName(other),video=c.call_type==='video';
  const privacyMark=callPrivacyWatermark(c.id);
  const filters=Object.keys(CALL_FILTERS).map(k=>`<button class="filter-chip ${state.call.filter===k?'active':''}" data-call-filter="${k}">${callFilterLabel(k)}</button>`).join('');
  const bg=`<div class="call-filters"><button class="filter-chip ${state.call.bgEffect==='none'?'active':''}" data-call-bg="none">No BG</button><button class="filter-chip ${state.call.bgEffect==='blur'?'active':''}" data-call-bg="blur">Blur</button><button class="filter-chip ${state.call.bgEffect==='virtual'?'active':''}" data-call-bg="virtual">Virtual</button><label class="filter-chip">নিজের ছবি<input id="virtualBgFile" type="file" accept="image/*" hidden></label></div>`;
  return `<div class="call-screen private-call"><div class="call-title">${esc(name)}</div><div class="muted">${video?'ভিডিও কল':'অডিও কল'} · ${c.status==='ringing'?'কল হচ্ছে…':c.status==='accepted'?'সংযুক্ত':'সংযোগ হচ্ছে…'}</div>${video?`<div class="video-stage"><video id="remoteVideo" autoplay playsinline></video><video id="localVideo" autoplay muted playsinline></video>${privacyMark}</div><div class="call-filters">${filters}</div>${bg}`:`<div class="call-avatar">${esc(name[0]||'V')}</div><audio id="remoteVideo" autoplay></audio>${privacyMark}`}<div class="call-privacy-note">🔒 Android screen capture blocked · personal watermark active</div><div class="call-actions"><button class="call-round" id="muteCall">${state.call.muted?'🔇':'🎤'}</button>${video?`<button class="call-round" id="cameraCall">${state.call.cameraOff?'📷✕':'📹'}</button><button class="call-round" id="switchCamera" title="Switch camera">🔄</button>`:''}<button class="call-round danger" id="endCall">📞</button></div></div>`;
}

function callPrivacyWatermark(callId){
  const profile=state.meProfile||{};
  const owner=profile.username?'@'+profile.username:(profile.display_name||state.user?.name||'Vibes member');
  const stamp=new Date().toLocaleString([], {month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit'});
  const label=esc(`${owner} · ${stamp} · ${String(callId||'').slice(-6)}`);
  return `<div class="call-watermarks" aria-hidden="true"><span>${label}</span><span>${label}</span><span>${label}</span></div>`;
}

async function setupGroupRealtime(){
  if(!cloudReady||!state.user)return;if(groupRealtimeChannel)await sb.removeChannel(groupRealtimeChannel);
  groupRealtimeChannel=sb.channel('vibes-group-'+state.user.id)
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'group_call_members',filter:`user_id=eq.${state.user.id}`},async p=>{if(p.new.status==='invited'){const {data}=await sb.from('group_calls').select('*').eq('id',p.new.room_id).single();if(data&&data.creator_id!==state.user.id){state.group.incoming=data;toast('Group video call আসছে');try{window.VibesNative?.showIncomingCall(callPersonName(data.creator_id),'video',data.id)}catch{}app()}}})
    .on('postgres_changes',{event:'UPDATE',schema:'public',table:'group_call_members'},async p=>{if(state.group.active&&p.new.room_id===state.group.active.id&&p.new.status==='joined'&&p.new.user_id!==state.user.id){if(state.user.id<p.new.user_id)await ensureGroupPeer(p.new.user_id,true);app()}})
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'group_call_signals',filter:`to_user=eq.${state.user.id}`},p=>handleGroupSignal(p.new))
    .on('postgres_changes',{event:'UPDATE',schema:'public',table:'group_calls'},p=>{if(state.group.active?.id===p.new.id&&p.new.status==='ended'){leaveGroupCall(false);toast('Group call শেষ হয়েছে')}}).subscribe();
}
async function groupLocalMedia(type='video'){
  const raw=await navigator.mediaDevices.getUserMedia({audio:true,video:type==='video'?{facingMode:{ideal:state.group.facingMode}}:false});state.group.rawLocalStream=raw;state.group.localStream=raw;return raw;
}
async function sendGroupSignal(roomId,to,kind,payload){await sb.from('group_call_signals').insert({room_id:roomId,from_user:state.user.id,to_user:to,kind,payload})}
async function ensureGroupPeer(peerId,initiate=false){
  if(state.group.peers[peerId])return state.group.peers[peerId];const pc=new RTCPeerConnection({iceServers:callIceServers()});state.group.peers[peerId]=pc;const remote=new MediaStream();state.group.remotes[peerId]=remote;
  state.group.localStream?.getTracks().forEach(t=>pc.addTrack(t,state.group.localStream));pc.ontrack=e=>{e.streams[0].getTracks().forEach(t=>{if(!remote.getTracks().some(x=>x.id===t.id))remote.addTrack(t)});attachGroupMedia()};
  pc.onicecandidate=e=>{if(e.candidate)sendGroupSignal(state.group.active.id,peerId,'ice',e.candidate.toJSON())};
  if(initiate){const offer=await pc.createOffer();await pc.setLocalDescription(offer);await sendGroupSignal(state.group.active.id,peerId,'offer',pc.localDescription.toJSON())}return pc;
}
async function handleGroupSignal(row){
  if(!state.group.active||row.room_id!==state.group.active.id)return;const peer=await ensureGroupPeer(row.from_user,false);
  try{if(row.kind==='offer'){await peer.setRemoteDescription(new RTCSessionDescription(row.payload));const a=await peer.createAnswer();await peer.setLocalDescription(a);await sendGroupSignal(row.room_id,row.from_user,'answer',peer.localDescription.toJSON())}else if(row.kind==='answer'){if(!peer.currentRemoteDescription)await peer.setRemoteDescription(new RTCSessionDescription(row.payload))}else if(row.kind==='ice'){await peer.addIceCandidate(new RTCIceCandidate(row.payload))}}catch(e){console.error('group signal',e)}
}
async function startGroupCall(ids){
  ids=[...new Set(ids)].filter(Boolean).slice(0,3);if(!ids.length)return toast('কমপক্ষে ১ জন নির্বাচন করুন');
  try{const {data:room,error}=await sb.from('group_calls').insert({creator_id:state.user.id,call_type:'video',status:'ringing'}).select().single();if(error)throw error;
    const members=[{room_id:room.id,user_id:state.user.id,status:'joined',joined_at:new Date().toISOString()},...ids.map(id=>({room_id:room.id,user_id:id,status:'invited'}))];const {error:me}=await sb.from('group_call_members').insert(members);if(me)throw me;
    sendCallPush({room_id:room.id});
    state.group.active=room;state.group.incoming=null;await ensureTurnCredentials();await groupLocalMedia('video');app();
  }catch(e){console.error(e);toast('Group call শুরু করা যায়নি')}
}
async function acceptGroupCall(){try{window.VibesNative?.clearIncomingCall()}catch{}const room=state.group.incoming;if(!room)return;state.group.active=room;state.group.incoming=null;await groupLocalMedia(room.call_type);await sb.from('group_call_members').update({status:'joined',joined_at:new Date().toISOString()}).eq('room_id',room.id).eq('user_id',state.user.id);await sb.from('group_calls').update({status:'active'}).eq('id',room.id).eq('creator_id',room.creator_id);const {data}=await sb.from('group_call_members').select('user_id,status').eq('room_id',room.id).eq('status','joined');for(const m of data||[]){if(m.user_id!==state.user.id&&state.user.id<m.user_id)await ensureGroupPeer(m.user_id,true)}app()}
async function rejectGroupCall(){try{window.VibesNative?.clearIncomingCall()}catch{}const r=state.group.incoming;if(!r)return;await sb.from('group_call_members').update({status:'rejected'}).eq('room_id',r.id).eq('user_id',state.user.id);state.group.incoming=null;app()}
async function leaveGroupCall(mark=true){try{window.VibesNative?.clearIncomingCall()}catch{}const r=state.group.active;if(mark&&r){await sb.from('group_call_members').update({status:'left'}).eq('room_id',r.id).eq('user_id',state.user.id);if(r.creator_id===state.user.id)await sb.from('group_calls').update({status:'ended',ended_at:new Date().toISOString()}).eq('id',r.id)}Object.values(state.group.peers).forEach(pc=>{try{pc.close()}catch{}});state.group.localStream?.getTracks().forEach(t=>t.stop());state.group.rawLocalStream?.getTracks().forEach(t=>t.stop());state.group.active=null;state.group.peers={};state.group.remotes={};state.group.localStream=null;state.group.rawLocalStream=null;app()}
function toggleGroupMute(){state.group.muted=!state.group.muted;state.group.localStream?.getAudioTracks().forEach(t=>t.enabled=!state.group.muted);app()}
function toggleGroupCamera(){state.group.cameraOff=!state.group.cameraOff;state.group.localStream?.getVideoTracks().forEach(t=>t.enabled=!state.group.cameraOff);app()}
function attachGroupMedia(){const lv=document.getElementById('groupLocal');if(lv&&state.group.localStream&&lv.srcObject!==state.group.localStream){lv.srcObject=state.group.localStream;lv.muted=true;lv.play().catch(()=>{})}Object.entries(state.group.remotes).forEach(([id,s])=>{const el=document.getElementById('group-'+id);if(el&&el.srcObject!==s){el.srcObject=s;el.play().catch(()=>{})}})}
function groupCallUI(){const r=state.group.active;if(!r)return '';const rem=Object.keys(state.group.remotes);return `<div class="call-screen group-call private-call"><div class="call-title">Group Video Call</div><div class="muted">সর্বোচ্চ ৪ জন</div><div class="group-grid protected-stage"><div class="group-tile"><video id="groupLocal" autoplay muted playsinline></video><span>আপনি</span></div>${rem.map(id=>`<div class="group-tile"><video id="group-${id}" autoplay playsinline></video><span>${esc(callPersonName(id))}</span></div>`).join('')}${callPrivacyWatermark(r.id)}</div><div class="call-privacy-note">🔒 Android screen capture blocked · personal watermark active</div><div class="call-actions"><button class="call-round" id="groupMute">${state.group.muted?'🔇':'🎤'}</button><button class="call-round" id="groupCamera">${state.group.cameraOff?'📷✕':'📹'}</button><button class="call-round danger" id="groupLeave">📞</button></div></div>`}
function incomingGroupUI(){const r=state.group.incoming;if(!r)return '';return `<div class="incoming-call"><div class="call-avatar small">G</div><div class="grow"><b>Group Video Call</b><div class="muted">${esc(callPersonName(r.creator_id))} আপনাকে ডাকছে</div></div><button class="call-round accept" id="acceptGroup">✓</button><button class="call-round danger" id="rejectGroup">✕</button></div>`}
function groupPickerUI(){const people=state.people.slice(0,20);return `<div class="card"><div class="section-title">Group Video Call</div><div class="muted" style="margin-bottom:8px">৩ জন পর্যন্ত বেছে নিন — আপনিসহ মোট ৪ জন।</div><div class="group-picker">${people.map(p=>`<label><input type="checkbox" data-group-pick="${p.id}"> ${esc(p.display_name||'Vibes user')}</label>`).join('')}</div><button class="btn" id="startGroup" style="margin-top:10px">Group Call শুরু</button></div>`}

function chatView(){
  if(state.group.active)return groupCallUI();if(state.call.active)return activeCallUI();const incoming=incomingCallUI()+incomingGroupUI();
  if(state.chatOpen)return `${incoming}<div class="row" style="margin-bottom:10px"><button class="pill" id="backChat">←</button><div class="grow"><b>Nadia</b><div class="muted"><span class="status-dot"></span> চ্যাট</div></div></div><div class="card messages">${state.messages.map(m=>`<div class="bubble ${m.me?'me':''}">${esc(m.text)}</div>`).join('')}</div><div class="chatbar"><input id="msg" placeholder="মেসেজ লিখুন"><button class="btn" id="sendMsg">পাঠান</button></div>`;
  const people=state.people.length?state.people.map(p=>`<div class="card row person-row"><div class="avatar">${esc((p.display_name||'V')[0])}</div><div class="grow"><b>${esc(p.display_name||'Vibes user')}</b><div class="muted">${esc(p.username?'@'+p.username:'Vibes')}</div></div><button class="call-mini" data-audio-call="${p.id}">📞</button><button class="call-mini" data-video-call="${p.id}">📹</button></div>`).join(''):`<div class="empty">আরও ব্যবহারকারী যোগ হলে এখানে call করা যাবে।</div>`;
  return `${incoming}<div class="title">চ্যাট ও কল</div>${groupPickerUI()}<div class="notice">1-to-1 এবং ছোট Group Video Call WebRTC ব্যবহার করে। Background Blur/Virtual Background আপনার ডিভাইসেই process হয়।</div><div class="chat-list">${people}</div>`;
}

async function cloudBootstrap(){if(!cloudReady)return;const {data:{session}}=await sb.auth.getSession();if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople()]);await Promise.all([setupCallRealtime(),setupGroupRealtime()]);await registerNativePushToken();const pending=readPendingNativeCall();if(pending)console.info('Vibes opened from call notification',pending)}sb.auth.onAuthStateChange(async(_,session)=>{if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople()]);await Promise.all([setupCallRealtime(),setupGroupRealtime()]);await registerNativePushToken()}else{closeCallMedia();await leaveGroupCall(false);state.user=null}app()})}
function app(){document.getElementById('app').innerHTML=state.user?mainUI():authUI();bind();setTimeout(()=>{attachCallMedia();attachGroupMedia()},0)}
function bind(){
  baseBind();document.querySelectorAll('[data-audio-call]').forEach(b=>b.onclick=()=>startCall(b.dataset.audioCall,'audio'));document.querySelectorAll('[data-video-call]').forEach(b=>b.onclick=()=>startCall(b.dataset.videoCall,'video'));
  document.getElementById('acceptCall')?.addEventListener('click',acceptCall);document.getElementById('rejectCall')?.addEventListener('click',rejectCall);document.getElementById('endCall')?.addEventListener('click',endCall);document.getElementById('muteCall')?.addEventListener('click',toggleMute);document.getElementById('cameraCall')?.addEventListener('click',toggleCamera);document.getElementById('switchCamera')?.addEventListener('click',switchCamera);
  document.querySelectorAll('[data-call-filter]').forEach(b=>b.onclick=()=>setCallFilter(b.dataset.callFilter));document.querySelectorAll('[data-call-bg]').forEach(b=>b.onclick=()=>setCallBackground(b.dataset.callBg));document.getElementById('virtualBgFile')?.addEventListener('change',e=>pickVirtualBackground(e.target.files?.[0]));
  document.getElementById('startGroup')?.addEventListener('click',()=>startGroupCall([...document.querySelectorAll('[data-group-pick]:checked')].map(x=>x.dataset.groupPick)));document.getElementById('acceptGroup')?.addEventListener('click',acceptGroupCall);document.getElementById('rejectGroup')?.addEventListener('click',rejectGroupCall);document.getElementById('groupLeave')?.addEventListener('click',()=>leaveGroupCall(true));document.getElementById('groupMute')?.addEventListener('click',toggleGroupMute);document.getElementById('groupCamera')?.addEventListener('click',toggleGroupCamera);
}


// ---- Vibes native push registration ----
async function registerNativePushToken(){
  if(!cloudReady||!state.user?.id||!window.VibesNative?.getPushToken)return;
  try{
    const token=String(window.VibesNative.getPushToken()||'').trim();
    if(!token)return;
    const {error}=await sb.from('push_tokens').upsert({user_id:state.user.id,token,platform:'android',device_label:'Vibes Android',updated_at:new Date().toISOString()},{onConflict:'token'});
    if(error)console.warn('push token registration',error);
  }catch(e){console.warn('native push token',e)}
}
function readPendingNativeCall(){
  if(!window.VibesNative?.getPendingCallJson)return null;
  try{const x=JSON.parse(window.VibesNative.getPendingCallJson()||'{}');return x&&x.type?x:null}catch{return null}
}

// ---- Vibes Social v1.8: stories, reels, saved posts, notifications ----
state.saved=local.saved||[];
state.notifications=[];
state.stories=[];

function persist(){if(!cloudReady){local={user:state.user,posts:state.posts,messages:state.messages,blocked:state.blocked,reports:state.reports,saved:state.saved};localStorage.setItem(demoKey,JSON.stringify(local));}}
function nav(){const items=[['feed','🏠','হোম'],['reels','▶','রিলস'],['create','➕','পোস্ট'],['notifications','🔔','নোটিফিকেশন'],['profile','👤','প্রোফাইল']];return `<nav class="nav">${items.map(x=>`<button data-tab="${x[0]}" class="${state.tab===x[0]?'active':''}"><span class="ico">${x[1]}</span>${x[2]}</button>`).join('')}</nav>`}
function view(){if(state.loading)return `<div class="empty">লোড হচ্ছে…</div>`;if(state.tab==='create')return createView();if(state.tab==='profile')return profileView();if(state.tab==='chat')return chatView();if(state.tab==='search')return searchView();if(state.tab==='reels')return reelsView();if(state.tab==='notifications')return notificationsView();return feedView();}
function storiesTray(){const stories=(state.stories.length?state.stories:state.posts.slice(0,6)).map((s,i)=>({name:s.profiles?.display_name||s.user||['আপনি','Nadia','Rahim'][i%3],media:s.media_url||s.image}));return `<div class="stories"><label class="story add-story"><span class="story-ring">＋</span><small>স্টোরি দিন</small><input id="storyFile" type="file" accept="image/*,video/*" hidden></label>${stories.map((s,i)=>`<button class="story" data-story="${i}"><span class="story-ring">${s.media?`<img src="${esc(s.media)}" alt="">`:esc((s.name||'V')[0])}</span><small>${esc(s.name||'Vibes')}</small></button>`).join('')}</div>`}
function feedView(){return `${storiesTray()}<div class="feed-tabs"><button class="active">আপনার জন্য</button><button>ফলো করা</button></div><div class="composer card"><textarea id="quickPost" placeholder="কী ভাবছেন?"></textarea><div class="composer-tools"><label class="pill">📷 ছবি/ভিডিও<input id="quickImage" type="file" accept="image/*,video/*" hidden></label><button class="pill" data-tab="reels">▶ রিলস</button><div class="grow"></div><button class="btn" id="quickPostBtn">পোস্ট করুন</button></div><div id="quickPreview"></div></div>${state.posts.length?state.posts.map(postCard).join(''):`<div class="empty">এখনও কোনো পোস্ট নেই। প্রথম পোস্টটি করুন ✨</div>`}`}
function postCard(p){const comments=p.comments||[];const media=p.image?(isVideoMedia(p.image,p.media_type)?`<video class="post-img" src="${esc(p.image)}" controls playsinline preload="metadata"></video>`:`<img class="post-img" src="${esc(p.image)}" alt="Post image">`):'';const saved=state.saved.some(x=>String(x)===String(p.id));return `<article class="card" data-post="${esc(p.id)}"><div class="row"><div class="avatar">${esc((p.user||'U')[0])}</div><div class="grow"><div class="name">${esc(p.user||'Vibes user')}</div><div class="muted">${esc(p.handle||handleOf(p.user))} · ${esc(p.time||'')}</div></div><button class="icon-btn" data-save="${esc(p.id)}" aria-label="Save">${saved?'🔖':'▱'}</button><div class="menu"><button class="icon-btn" data-menu="${esc(p.id)}">⋯</button><div id="menu-${esc(p.id)}" class="menu-panel hidden"><button data-report="${esc(p.id)}">⚑ রিপোর্ট</button><button data-block="${esc(p.user_id||p.user)}">⛔ ব্লক</button></div></div></div><div class="post-text">${esc(p.text||'')}</div>${media}<div class="actions"><button class="action ${p.liked?'active':''}" data-like="${esc(p.id)}">♥ ${Number(p.likes||0)}</button><button class="action" data-comment="${esc(p.id)}">💬 ${comments.length}</button><button class="action" data-share="${esc(p.id)}">↗ শেয়ার</button></div>${comments.slice(-3).map(c=>`<div class="comment muted">💬 ${esc(typeof c==='string'?c:c.text)}</div>`).join('')}</article>`}
function reelsView(){const videos=state.posts.filter(p=>p.image&&isVideoMedia(p.image,p.media_type));if(!videos.length)return `<div class="title">রিলস</div><div class="empty">ভিডিও পোস্ট করলে এখানে TikTok-এর মতো রিলস দেখা যাবে।</div>`;return `<div class="reels-feed">${videos.map(p=>`<section class="reel"><video src="${esc(p.image)}" controls playsinline loop preload="metadata"></video><div class="reel-info"><b>${esc(p.user||'Vibes user')}</b><p>${esc(p.text||'')}</p></div><div class="reel-actions"><button data-like="${esc(p.id)}">♥<small>${Number(p.likes||0)}</small></button><button data-comment="${esc(p.id)}">💬</button><button data-share="${esc(p.id)}">↗</button></div></section>`).join('')}</div>`}
function notificationsView(){const rows=state.notifications.length?state.notifications:[{id:'welcome',type:'system',body:'Vibes-এ স্বাগতম! নতুন পোস্ট ও রিলস শেয়ার করুন।',created_at:new Date().toISOString()}];return `<div class="row"><div class="title grow">নোটিফিকেশন</div>${state.notifications.some(n=>!n.read_at)?`<button class="pill" id="readAll">সব পড়া হয়েছে</button>`:''}</div>${rows.map(n=>`<div class="card notification ${n.read_at?'':'unread'}"><span>${({like:'♥',comment:'💬',follow:'👤',message:'✉',system:'✨'})[n.type]||'🔔'}</span><div class="grow"><b>${esc(n.body||'নতুন আপডেট')}</b><div class="muted">${new Date(n.created_at).toLocaleString('bn-BD')}</div></div></div>`).join('')}`}
async function toggleSave(id){const saved=state.saved.some(x=>String(x)===String(id));if(!cloudReady){state.saved=saved?state.saved.filter(x=>String(x)!==String(id)):[...state.saved,id];persist();return app()}const q=sb.from('saved_posts');const {error}=saved?await q.delete().eq('post_id',id).eq('user_id',state.user.id):await q.insert({post_id:id,user_id:state.user.id});if(error)return toast('সেভ করা যায়নি');state.saved=saved?state.saved.filter(x=>String(x)!==String(id)):[...state.saved,id];app()}
async function loadSocialExtras(){if(!cloudReady||!state.user)return;const [saved,notes,stories]=await Promise.all([sb.from('saved_posts').select('post_id').eq('user_id',state.user.id),sb.from('notifications').select('*').order('created_at',{ascending:false}).limit(50),sb.from('stories').select('*,profiles(display_name,username)').gt('expires_at',new Date().toISOString()).order('created_at',{ascending:false})]);if(!saved.error)state.saved=(saved.data||[]).map(x=>x.post_id);if(!notes.error)state.notifications=notes.data||[];if(!stories.error)state.stories=stories.data||[];}
async function addStory(file){if(!file)return;if(!cloudReady)return toast('Demo mode-এ Story server-এ প্রকাশ হবে না');try{const media_url=await uploadMedia(file);const {error}=await sb.from('stories').insert({user_id:state.user.id,media_url,media_type:file.type});if(error)throw error;await loadSocialExtras();app();toast('স্টোরি প্রকাশ হয়েছে')}catch(e){console.error(e);toast('স্টোরি প্রকাশ করা যায়নি')}}
async function markNotificationsRead(){if(!cloudReady){state.notifications.forEach(n=>n.read_at=new Date().toISOString());return app()}const {error}=await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('user_id',state.user.id).is('read_at',null);if(error)return toast('নোটিফিকেশন আপডেট হয়নি');await loadSocialExtras();app()}
async function cloudBootstrap(){if(!cloudReady)return;const {data:{session}}=await sb.auth.getSession();if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople(),loadSocialExtras()]);await Promise.all([setupCallRealtime(),setupGroupRealtime()]);await registerNativePushToken()}sb.auth.onAuthStateChange(async(_,session)=>{if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople(),loadSocialExtras()]);await Promise.all([setupCallRealtime(),setupGroupRealtime()]);await registerNativePushToken()}else{closeCallMedia();await leaveGroupCall(false);state.user=null}app()})}
function bind(){baseBind();document.querySelectorAll('[data-audio-call]').forEach(b=>b.onclick=()=>startCall(b.dataset.audioCall,'audio'));document.querySelectorAll('[data-video-call]').forEach(b=>b.onclick=()=>startCall(b.dataset.videoCall,'video'));document.getElementById('acceptCall')?.addEventListener('click',acceptCall);document.getElementById('rejectCall')?.addEventListener('click',rejectCall);document.getElementById('endCall')?.addEventListener('click',endCall);document.getElementById('muteCall')?.addEventListener('click',toggleMute);document.getElementById('cameraCall')?.addEventListener('click',toggleCamera);document.getElementById('switchCamera')?.addEventListener('click',switchCamera);document.querySelectorAll('[data-call-filter]').forEach(b=>b.onclick=()=>setCallFilter(b.dataset.callFilter));document.querySelectorAll('[data-call-bg]').forEach(b=>b.onclick=()=>setCallBackground(b.dataset.callBg));document.getElementById('virtualBgFile')?.addEventListener('change',e=>pickVirtualBackground(e.target.files?.[0]));document.getElementById('startGroup')?.addEventListener('click',()=>startGroupCall([...document.querySelectorAll('[data-group-pick]:checked')].map(x=>x.dataset.groupPick)));document.getElementById('acceptGroup')?.addEventListener('click',acceptGroupCall);document.getElementById('rejectGroup')?.addEventListener('click',rejectGroupCall);document.getElementById('groupLeave')?.addEventListener('click',()=>leaveGroupCall(true));document.getElementById('groupMute')?.addEventListener('click',toggleGroupMute);document.getElementById('groupCamera')?.addEventListener('click',toggleGroupCamera);document.querySelectorAll('[data-save]').forEach(b=>b.onclick=()=>toggleSave(b.dataset.save));document.getElementById('storyFile')?.addEventListener('change',e=>addStory(e.target.files?.[0]));document.querySelectorAll('[data-story]').forEach(b=>b.onclick=()=>toast('স্টোরি দেখা হচ্ছে'));document.getElementById('readAll')?.addEventListener('click',markNotificationsRead)}

// Large media uploads: no app-level MB cap; files over 6 MB use resumable TUS upload.
function createView(){return `<div class="title">নতুন পোস্ট</div><div class="card composer"><textarea id="newPost" placeholder="আপনার কথা লিখুন..." maxlength="3000"></textarea><label class="pill">📷 ছবি/ভিডিও যোগ করুন<input id="newImage" type="file" accept="image/*,video/*" hidden></label><div id="newPreview"></div><div class="media-note">অ্যাপে নির্দিষ্ট MB সীমা নেই। বড় ফাইল resumable upload হবে।</div><div id="uploadProgress" class="upload-progress"></div><button class="btn" id="postBtn" style="margin-top:10px">প্রকাশ করুন</button></div>`}
function filePreview(input,target){const f=input.files?.[0];if(!f){state.upload=null;return}const video=f.type.startsWith('video/');if(!f.type.startsWith('image/')&&!video){input.value='';return toast('শুধু ছবি বা ভিডিও নির্বাচন করুন')}state.upload=f;const url=URL.createObjectURL(f);document.getElementById(target).innerHTML=`<div class="preview">${video?`<video src="${url}" controls playsinline></video>`:`<img src="${url}" alt="preview">`}</div><div class="muted">${(f.size/1024/1024).toFixed(1)} MB</div>`}
function showUploadProgress(done,total){const pct=total?Math.round(done/total*100):0;const el=document.getElementById('uploadProgress');if(el)el.innerHTML=`<div class="progress-track"><span style="width:${pct}%"></span></div><div class="muted">আপলোড ${pct}%</div>`}
async function uploadMedia(file){if(!cloudReady||!file)return null;const ext=(file.name.split('.').pop()||(file.type.startsWith('video/')?'mp4':'jpg')).toLowerCase();const path=`${state.user.id}/${crypto.randomUUID()}.${ext}`;if(file.size<=6*1024*1024||!window.tus){const {error}=await sb.storage.from('post-media').upload(path,file,{cacheControl:'3600',upsert:false,contentType:file.type});if(error)throw error;showUploadProgress(file.size,file.size)}else{const {data:{session}}=await sb.auth.getSession();if(!session?.access_token)throw new Error('Login required');const projectId=new URL(cfg.supabaseUrl).hostname.split('.')[0];await new Promise((resolve,reject)=>{const upload=new window.tus.Upload(file,{endpoint:`https://${projectId}.storage.supabase.co/storage/v1/upload/resumable`,retryDelays:[0,3000,5000,10000,20000],headers:{authorization:`Bearer ${session.access_token}`,apikey:cfg.supabaseAnonKey},uploadDataDuringCreation:true,removeFingerprintOnSuccess:true,chunkSize:6*1024*1024,metadata:{bucketName:'post-media',objectName:path,contentType:file.type||'application/octet-stream',cacheControl:'3600'},onError:reject,onProgress:showUploadProgress,onSuccess:resolve});upload.findPreviousUploads().then(old=>{if(old.length)upload.resumeFromPreviousUpload(old[0]);upload.start()}).catch(reject)})}return sb.storage.from('post-media').getPublicUrl(path).data.publicUrl;}

// Crystal-clear, non-destructive filters and smooth feed rendering.
state.feedLimit=15;state.storyDraft=null;state.storyFilter='natural';state.storyOpen=null;state.uploadFilter='natural';
const SOCIAL_FILTERS={natural:'none',bright:'brightness(1.10) contrast(1.03)',warm:'brightness(1.04) saturate(1.10) sepia(.10)',cool:'brightness(1.04) saturate(1.04) hue-rotate(8deg)',vivid:'saturate(1.28) contrast(1.07)',mono:'grayscale(1) contrast(1.08)',soft:'brightness(1.07) contrast(.96) saturate(1.04)'};
const FILTER_LABELS={natural:'Natural',bright:'Bright',warm:'Warm',cool:'Cool',vivid:'Vivid',mono:'B&W',soft:'Soft Glow'};
function filterCss(name){return SOCIAL_FILTERS[name]||'none'}
function filterButtons(scope){return `<div class="filter-row">${Object.entries(FILTER_LABELS).map(([k,v])=>`<button class="pill ${(scope==='story'?state.storyFilter:state.uploadFilter)===k?'active':''}" data-${scope}-filter="${k}">${v}</button>`).join('')}</div>`}
function filePreview(input,target){const f=input.files?.[0];if(!f){state.upload=null;return}const video=f.type.startsWith('video/');if(!f.type.startsWith('image/')&&!video){input.value='';return toast('শুধু ছবি বা ভিডিও নির্বাচন করুন')}state.upload=f;state.uploadFilter='natural';const url=URL.createObjectURL(f);document.getElementById(target).innerHTML=`<div class="preview" id="postMediaPreview">${video?`<video src="${url}" controls playsinline></video>`:`<img src="${url}" alt="preview" decoding="async">`}</div><div class="muted">${(f.size/1024/1024).toFixed(1)} MB · Original quality</div>${filterButtons('post')}`;bindPostFilterButtons()}
function bindPostFilterButtons(){document.querySelectorAll('[data-post-filter]').forEach(b=>b.onclick=()=>{state.uploadFilter=b.dataset.postFilter;const media=document.querySelector('#postMediaPreview img,#postMediaPreview video');if(media)media.style.filter=filterCss(state.uploadFilter);document.querySelectorAll('[data-post-filter]').forEach(x=>x.classList.toggle('active',x.dataset.postFilter===state.uploadFilter))})}
async function loadCloudPosts(){if(!cloudReady)return;state.loading=true;app();const {data,error}=await sb.from('posts').select('id,user_id,body,image_url,filter_name,created_at,profiles(display_name,username),likes(count),comments(id,body)').order('created_at',{ascending:false}).limit(50);state.loading=false;if(error){toast('পোস্ট লোড করা যায়নি');console.error(error);return app()}state.posts=(data||[]).filter(p=>!state.blocked.includes(p.user_id)).map(p=>({id:p.id,user:p.profiles?.display_name||'Vibes user',handle:p.profiles?.username?('@'+p.profiles.username):'@user',text:p.body,image:p.image_url,filter_name:p.filter_name||'natural',time:new Date(p.created_at).toLocaleString('bn-BD'),likes:p.likes?.[0]?.count||0,comments:(p.comments||[]).map(c=>c.body),user_id:p.user_id,liked:false}));app()}
async function addPost(txt){txt=txt.trim();if(!txt&&!state.upload)return;if(!cloudReady){let image=null,media_type='';if(state.upload){media_type=state.upload.type;image=await fileToDataUrl(state.upload)}state.posts.unshift({id:Date.now(),user:state.user.name,handle:handleOf(state.user.name),text:txt,time:'এখনই',likes:0,liked:false,comments:[],image,media_type,filter_name:state.uploadFilter,user_id:state.user.id});state.upload=null;state.uploadFilter='natural';persist();state.tab='feed';return app()}try{const image_url=await uploadMedia(state.upload);const {error}=await sb.from('posts').insert({user_id:state.user.id,body:txt,image_url,filter_name:state.uploadFilter});if(error)throw error;state.upload=null;state.uploadFilter='natural';state.tab='feed';await loadCloudPosts()}catch(e){console.error(e);toast('পোস্ট করা যায়নি')}}
function postCard(p){const comments=p.comments||[];const fx=filterCss(p.filter_name);const media=p.image?(isVideoMedia(p.image,p.media_type)?`<video class="post-img smart-video" src="${esc(p.image)}" controls playsinline preload="metadata" style="filter:${fx}"></video>`:`<img class="post-img" src="${esc(p.image)}" alt="Post image" loading="lazy" decoding="async" style="filter:${fx}">`):'';const saved=state.saved.some(x=>String(x)===String(p.id));return `<article class="card"><div class="row"><div class="avatar">${esc((p.user||'U')[0])}</div><div class="grow"><div class="name">${esc(p.user||'Vibes user')}</div><div class="muted">${esc(p.handle||handleOf(p.user))} · ${esc(p.time||'')}</div></div><button class="icon-btn" data-save="${esc(p.id)}">${saved?'🔖':'▱'}</button></div><div class="post-text">${esc(p.text||'')}</div>${media}<div class="actions"><button class="action ${p.liked?'active':''}" data-like="${esc(p.id)}">♥ ${Number(p.likes||0)}</button><button class="action" data-comment="${esc(p.id)}">💬 ${comments.length}</button><button class="action" data-share="${esc(p.id)}">↗ শেয়ার</button></div></article>`}
function storiesTray(){const list=state.stories.length?state.stories:state.posts.slice(0,6);return `<div class="stories"><label class="story"><span class="story-ring">＋</span><small>স্টোরি দিন</small><input id="storyFile" type="file" accept="image/*,video/*" hidden></label>${list.map((s,i)=>`<button class="story" data-story="${i}"><span class="story-ring">${s.media_url||s.image?`<img src="${esc(s.media_url||s.image)}" loading="lazy" decoding="async" style="filter:${filterCss(s.filter_name)}">`:esc((s.user||'V')[0])}</span><small>${esc(s.profiles?.display_name||s.user||'Vibes')}</small></button>`).join('')}</div>`}
function feedView(){const visible=state.posts.slice(0,state.feedLimit);return `${storiesTray()}<div class="feed-tabs"><button class="active">আপনার জন্য</button><button>ফলো করা</button></div><div class="composer card"><textarea id="quickPost" placeholder="কী ভাবছেন?"></textarea><div class="composer-tools"><label class="pill">📷 ছবি/ভিডিও<input id="quickImage" type="file" accept="image/*,video/*" hidden></label><div class="grow"></div><button class="btn" id="quickPostBtn">পোস্ট করুন</button></div><div id="quickPreview"></div></div>${visible.length?visible.map(postCard).join(''):`<div class="empty">এখনও কোনো পোস্ট নেই।</div>`}${state.posts.length>visible.length?`<button id="loadMore" class="pill perf-load-more">আরও পোস্ট দেখুন</button>`:''}`}
function openStoryEditor(file){if(!file)return;const video=file.type.startsWith('video/');if(!file.type.startsWith('image/')&&!video)return toast('শুধু ছবি বা ভিডিও নির্বাচন করুন');state.storyDraft={file,url:URL.createObjectURL(file),video};state.storyFilter='natural';state.tab='storyEdit';app()}
function storyEditorView(){const d=state.storyDraft;if(!d)return feedView();return `<div class="story-editor"><button class="pill" id="cancelStory">← ফিরে যান</button>${d.video?`<video class="story-media" src="${d.url}" controls playsinline style="filter:${filterCss(state.storyFilter)}"></video>`:`<img class="story-media" src="${d.url}" style="filter:${filterCss(state.storyFilter)}">`}${filterButtons('story')}<div class="notice">Original resolution অপরিবর্তিত থাকবে।</div><div id="uploadProgress"></div><button class="btn" id="publishStory">স্টোরি প্রকাশ করুন</button></div>`}
function storyViewerView(){const s=state.storyOpen;if(!s)return feedView();const media=s.media_url||s.image;return `<div class="story-viewer"><button class="pill" id="closeStory">✕ বন্ধ করুন</button>${isVideoMedia(media,s.media_type)?`<video class="story-media smart-video" src="${esc(media)}" controls autoplay playsinline style="filter:${filterCss(s.filter_name)}"></video>`:`<img class="story-media" src="${esc(media)}" decoding="async" style="filter:${filterCss(s.filter_name)}">`}</div>`}
function view(){if(state.loading)return `<div class="empty">লোড হচ্ছে…</div>`;if(state.tab==='storyEdit')return storyEditorView();if(state.tab==='storyView')return storyViewerView();if(state.tab==='create')return createView();if(state.tab==='profile')return profileView();if(state.tab==='chat')return chatView();if(state.tab==='reels')return reelsView();if(state.tab==='notifications')return notificationsView();return feedView()}
async function publishStory(){const d=state.storyDraft;if(!d)return;if(!cloudReady)return toast('Story প্রকাশ করতে Cloud login প্রয়োজন');try{const media_url=await uploadMedia(d.file);const {error}=await sb.from('stories').insert({user_id:state.user.id,media_url,media_type:d.file.type,filter_name:state.storyFilter});if(error)throw error;URL.revokeObjectURL(d.url);state.storyDraft=null;state.tab='feed';await loadSocialExtras();app()}catch(e){console.error(e);toast('স্টোরি প্রকাশ করা যায়নি')}}
function setupMediaEfficiency(){document.querySelectorAll('.smart-video').forEach(v=>v.addEventListener('play',()=>document.querySelectorAll('.smart-video').forEach(o=>{if(o!==v)o.pause()}),{passive:true}));if('IntersectionObserver'in window){const ob=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting&&e.target instanceof HTMLVideoElement)e.target.pause()}),{rootMargin:'100px'});document.querySelectorAll('video').forEach(v=>ob.observe(v))}}
function app(){document.getElementById('app').innerHTML=state.user?mainUI():authUI();bindSocialOptimized();requestAnimationFrame(()=>{attachCallMedia();attachGroupMedia();setupMediaEfficiency()})}
const priorSocialBind=bind;
function bindSocialOptimized(){priorSocialBind();bindPostFilterButtons();document.getElementById('storyFile')?.addEventListener('change',e=>openStoryEditor(e.target.files?.[0]));document.querySelectorAll('[data-story-filter]').forEach(b=>b.onclick=()=>{state.storyFilter=b.dataset.storyFilter;app()});document.getElementById('publishStory')?.addEventListener('click',publishStory);document.getElementById('cancelStory')?.addEventListener('click',()=>{if(state.storyDraft?.url)URL.revokeObjectURL(state.storyDraft.url);state.storyDraft=null;state.tab='feed';app()});document.querySelectorAll('[data-story]').forEach(b=>b.onclick=()=>{state.storyOpen=(state.stories.length?state.stories:state.posts.slice(0,6))[Number(b.dataset.story)];state.tab='storyView';app()});document.getElementById('closeStory')?.addEventListener('click',()=>{state.storyOpen=null;state.tab='feed';app()});document.getElementById('loadMore')?.addEventListener('click',()=>{state.feedLimit+=15;app()})}

// Vibes 1.8.1: complete account registration.
function authUI(){const signup=state.authTab==='signup';return `<div class="auth"><div class="logo">Vibes ✨</div><div class="card"><div class="tabs"><button id="loginTab" class="${!signup?'active':''}">লগইন</button><button id="signupTab" class="${signup?'active':''}">নতুন অ্যাকাউন্ট</button></div>${!cloudReady?`<div class="notice warn"><b>Demo mode:</b> ডেটা এই ডিভাইসে সেভ হবে।</div>`:''}${signup?`<div class="name-grid"><input id="firstName" placeholder="First name" maxlength="50" autocomplete="given-name"><input id="middleName" placeholder="Middle name (ঐচ্ছিক)" maxlength="50" autocomplete="additional-name"><input id="lastName" placeholder="Last name" maxlength="50" autocomplete="family-name"></div><div class="signup-grid"><input id="age" type="number" min="13" max="120" placeholder="বয়স"><select id="gender"><option value="">Gender নির্বাচন করুন</option><option value="male">পুরুষ</option><option value="female">নারী</option><option value="other">অন্যান্য</option><option value="prefer_not_to_say">বলতে চাই না</option></select></div>`:''}<input id="email" type="email" placeholder="ইমেইল" autocomplete="email"><input id="password" type="password" placeholder="পাসওয়ার্ড (কমপক্ষে ৮ অক্ষর)" minlength="8" autocomplete="${signup?'new-password':'current-password'}"><button id="authGo" class="btn" style="width:100%;margin-top:8px">${signup?'অ্যাকাউন্ট তৈরি করুন':'লগইন করুন'}</button><p class="muted">অ্যাকাউন্ট তৈরি করলে আপনি Vibes-এর কমিউনিটি নিয়ম মেনে চলতে সম্মত হচ্ছেন।</p></div></div>`}
async function authAction(){const email=document.getElementById('email').value.trim();const password=document.getElementById('password').value;if(!email||password.length<8)return toast('সঠিক ইমেইল ও কমপক্ষে ৮ অক্ষরের পাসওয়ার্ড দিন');if(state.authTab==='login'){if(!cloudReady){state.user={id:'demo-'+Date.now(),name:email.split('@')[0],email};persist();return app()}const {error}=await sb.auth.signInWithPassword({email,password});if(error)toast(error.message);return}const first_name=document.getElementById('firstName').value.trim();const middle_name=document.getElementById('middleName').value.trim();const last_name=document.getElementById('lastName').value.trim();const age=Number(document.getElementById('age').value);const gender=document.getElementById('gender').value;if(!first_name||!last_name)return toast('First name এবং Last name লিখুন');if(!Number.isInteger(age)||age<13||age>120)return toast('সঠিক বয়স দিন (১৩–১২০)');if(!gender)return toast('Gender নির্বাচন করুন');const name=[first_name,middle_name,last_name].filter(Boolean).join(' ');if(!cloudReady){state.user={id:'demo-'+Date.now(),name,email,first_name,middle_name,last_name,age,gender};persist();return app()}const {data,error}=await sb.auth.signUp({email,password,options:{data:{name,first_name,middle_name,last_name,age,gender}}});if(error)return toast(error.message);toast(data.user&&!data.session?'ইমেইল চেক করে অ্যাকাউন্ট নিশ্চিত করুন':'অ্যাকাউন্ট তৈরি হয়েছে')}

// Vibes 1.9: language system. English is the stable fallback for every locale.
const LANGUAGE_OPTIONS={en:'English',bn:'বাংলা',ar:'العربية',hi:'हिन्दी',ur:'اردو',es:'Español',fr:'Français',de:'Deutsch',pt:'Português',zh:'中文',ja:'日本語',ko:'한국어',tr:'Türkçe',id:'Bahasa Indonesia',ms:'Bahasa Melayu',th:'ไทย',vi:'Tiếng Việt',ru:'Русский',it:'Italiano',nl:'Nederlands',fa:'فارسی',sw:'Kiswahili'};
const I18N={en:{login:'Log in',signup:'Create account',email:'Email',password:'Password (at least 8 characters)',create:'Create account',first:'First name',middle:'Middle name (optional)',last:'Last name',age:'Age',gender:'Select gender',male:'Male',female:'Female',other:'Other',private:'Prefer not to say',home:'Home',reels:'Reels',post:'Post',notifications:'Notifications',profile:'Profile',logout:'Log out',language:'Language',welcome:'Create vibes. Share moments. Connect.'},bn:{login:'লগইন',signup:'নতুন অ্যাকাউন্ট',email:'ইমেইল',password:'পাসওয়ার্ড (কমপক্ষে ৮ অক্ষর)',create:'অ্যাকাউন্ট তৈরি করুন',first:'First name',middle:'Middle name (ঐচ্ছিক)',last:'Last name',age:'বয়স',gender:'Gender নির্বাচন করুন',male:'পুরুষ',female:'নারী',other:'অন্যান্য',private:'বলতে চাই না',home:'হোম',reels:'রিলস',post:'পোস্ট',notifications:'নোটিফিকেশন',profile:'প্রোফাইল',logout:'লগআউট',language:'ভাষা',welcome:'মুহূর্ত তৈরি করুন, শেয়ার করুন, যুক্ত থাকুন।'},ar:{login:'تسجيل الدخول',signup:'إنشاء حساب',email:'البريد الإلكتروني',password:'كلمة المرور (8 أحرف على الأقل)',create:'إنشاء حساب',first:'الاسم الأول',middle:'الاسم الأوسط (اختياري)',last:'اسم العائلة',age:'العمر',gender:'اختر الجنس',male:'ذكر',female:'أنثى',other:'آخر',private:'أفضل عدم القول',home:'الرئيسية',reels:'ريلز',post:'منشور',notifications:'الإشعارات',profile:'الملف الشخصي',logout:'تسجيل الخروج',language:'اللغة',welcome:'أنشئ اللحظات وشاركها وتواصل.'}};
let currentLanguage=localStorage.getItem('vibes_language')||'en';
function tr(key){return (I18N[currentLanguage]||I18N.en)[key]||I18N.en[key]||key}
function languageSelect(){return `<select id="languageSelect" class="language-select" aria-label="${tr('language')}">${Object.entries(LANGUAGE_OPTIONS).map(([code,name])=>`<option value="${code}" ${currentLanguage===code?'selected':''}>${name}</option>`).join('')}</select>`}
function nav(){const items=[['feed','🏠',tr('home')],['reels','▶',tr('reels')],['create','➕',tr('post')],['notifications','🔔',tr('notifications')],['profile','👤',tr('profile')]];return `<nav class="nav">${items.map(x=>`<button data-tab="${x[0]}" class="${state.tab===x[0]?'active':''}"><span class="ico">${x[1]}</span>${x[2]}</button>`).join('')}</nav>`}
function mainUI(){return `<div class="app"><header class="top"><div class="brand">Vibes</div><div class="grow"></div>${languageSelect()}<button class="pill" id="logout">${tr('logout')}</button></header><main class="content">${view()}</main>${nav()}</div>`}
function authUI(){const signup=state.authTab==='signup';return `<div class="auth"><div class="auth-language">${languageSelect()}</div><div class="logo">Vibes ✨</div><div class="muted auth-tagline">${tr('welcome')}</div><div class="card"><div class="tabs"><button id="loginTab" class="${!signup?'active':''}">${tr('login')}</button><button id="signupTab" class="${signup?'active':''}">${tr('signup')}</button></div>${signup?`<input id="firstName" placeholder="${tr('first')}" maxlength="50"><input id="middleName" placeholder="${tr('middle')}" maxlength="50"><input id="lastName" placeholder="${tr('last')}" maxlength="50"><div class="signup-grid"><input id="age" type="number" min="13" max="120" placeholder="${tr('age')}"><select id="gender"><option value="">${tr('gender')}</option><option value="male">${tr('male')}</option><option value="female">${tr('female')}</option><option value="other">${tr('other')}</option><option value="prefer_not_to_say">${tr('private')}</option></select></div>`:''}<input id="email" type="email" placeholder="${tr('email')}"><input id="password" type="password" placeholder="${tr('password')}" minlength="8"><button id="authGo" class="btn" style="width:100%;margin-top:8px">${signup?tr('create'):tr('login')}</button></div></div>`}
async function changeLanguage(code){currentLanguage=LANGUAGE_OPTIONS[code]?code:'en';localStorage.setItem('vibes_language',currentLanguage);document.documentElement.lang=currentLanguage;document.documentElement.dir=['ar','ur','fa'].includes(currentLanguage)?'rtl':'ltr';if(cloudReady&&state.user?.id)await sb.from('profiles').update({preferred_language:currentLanguage}).eq('id',state.user.id);app()}
const bindBeforeI18n=bindSocialOptimized;
function bindI18n(){bindBeforeI18n();document.getElementById('languageSelect')?.addEventListener('change',e=>changeLanguage(e.target.value))}
function app(){document.documentElement.lang=currentLanguage;document.documentElement.dir=['ar','ur','fa'].includes(currentLanguage)?'rtl':'ltr';document.getElementById('app').innerHTML=state.user?mainUI():authUI();bindI18n();requestAnimationFrame(()=>{attachCallMedia();attachGroupMedia();setupMediaEfficiency()})}

// Vibes 1.10: functional settings, privacy, accessibility, and data controls.
const defaultPrefs={theme:'system',fontScale:100,dataSaver:false,autoplay:true,notifications:true,privateAccount:false,allowMessages:'everyone',highQualityUploads:true};
let prefs={...defaultPrefs,...JSON.parse(localStorage.getItem('vibes_preferences')||'{}')};
function applyPrefs(){const systemDark=window.matchMedia?.('(prefers-color-scheme: dark)').matches;const dark=prefs.theme==='dark'||(prefs.theme==='system'&&systemDark);document.documentElement.dataset.theme=dark?'dark':'light';document.documentElement.style.fontSize=`${Math.max(85,Math.min(125,Number(prefs.fontScale)||100))}%`;document.documentElement.dataset.dataSaver=prefs.dataSaver?'true':'false'}
function settingRow(title,description,control){return `<div class="setting-row"><div class="grow"><b>${title}</b><div class="muted">${description}</div></div>${control}</div>`}
function settingsView(){return `<div class="row"><button class="pill" id="settingsBack">←</button><div class="title grow">Settings</div></div><div class="card"><div class="section-title">Account & privacy</div>${settingRow('Private account','Only approved followers can see new content.',`<input id="prefPrivate" type="checkbox" ${prefs.privateAccount?'checked':''}>`)}${settingRow('Who can message me','Control new message requests.',`<select id="prefMessages"><option value="everyone" ${prefs.allowMessages==='everyone'?'selected':''}>Everyone</option><option value="following" ${prefs.allowMessages==='following'?'selected':''}>People I follow</option><option value="none" ${prefs.allowMessages==='none'?'selected':''}>No one</option></select>`)}</div><div class="card"><div class="section-title">Display & accessibility</div>${settingRow('Theme','Dark, light, or follow phone settings.',`<select id="prefTheme"><option value="dark" ${prefs.theme==='dark'?'selected':''}>Dark</option><option value="light" ${prefs.theme==='light'?'selected':''}>Light</option><option value="system" ${prefs.theme==='system'?'selected':''}>System</option></select>`)}${settingRow('Text size','Adjust text across the app.',`<input id="prefFont" type="range" min="85" max="125" step="5" value="${prefs.fontScale}">`)}</div><div class="card"><div class="section-title">Media & performance</div>${settingRow('Data saver','Loads less media and disables autoplay.',`<input id="prefDataSaver" type="checkbox" ${prefs.dataSaver?'checked':''}>`)}${settingRow('Autoplay videos','Play visible videos automatically.',`<input id="prefAutoplay" type="checkbox" ${prefs.autoplay?'checked':''}>`)}${settingRow('High-quality uploads','Keep original media quality when possible.',`<input id="prefQuality" type="checkbox" ${prefs.highQualityUploads?'checked':''}>`)}</div><div class="card"><div class="section-title">Notifications</div>${settingRow('Push notifications','Receive activity and message alerts.',`<input id="prefNotifications" type="checkbox" ${prefs.notifications?'checked':''}>`)}</div><button class="btn" id="saveSettings" style="width:100%">Save settings</button>`}
function profileView(){const u=state.profile||state.user||{};const name=u.name||u.user_metadata?.name||u.email?.split('@')[0]||'Vibes User';const own=state.posts.filter(p=>p.user_id===u.id||p.user===name).length;return `<div class="card profile-head"><div class="avatar lg">${esc(name[0]||'V')}</div><div class="title">${esc(name)}</div><div class="muted">${esc(u.email||u.handle||handleOf(name))}</div><div class="stats"><div class="stat"><b>${own}</b><div class="muted">Posts</div></div><div class="stat"><b>${u.followers_count||0}</b><div class="muted">Followers</div></div><div class="stat"><b>${u.following_count||0}</b><div class="muted">Following</div></div></div><button class="btn light" id="editProfile">Edit profile</button> <button class="pill" id="openSettings">⚙ Settings</button></div>`}
const viewBeforeSettings=view;
function viewWithSettings(){if(state.tab==='settings')return settingsView();return viewBeforeSettings()}
async function saveSettings(){prefs.theme=document.getElementById('prefTheme').value;prefs.fontScale=Number(document.getElementById('prefFont').value);prefs.dataSaver=document.getElementById('prefDataSaver').checked;prefs.autoplay=document.getElementById('prefAutoplay').checked&&!prefs.dataSaver;prefs.notifications=document.getElementById('prefNotifications').checked;prefs.privateAccount=document.getElementById('prefPrivate').checked;prefs.allowMessages=document.getElementById('prefMessages').value;prefs.highQualityUploads=document.getElementById('prefQuality').checked;localStorage.setItem('vibes_preferences',JSON.stringify(prefs));applyPrefs();if(cloudReady&&state.user?.id){const {error}=await sb.from('profiles').update({theme:prefs.theme,data_saver:prefs.dataSaver,autoplay_videos:prefs.autoplay,is_private:prefs.privateAccount,allow_messages:prefs.allowMessages}).eq('id',state.user.id);if(error)return toast('Settings could not be saved')}toast('Settings saved');state.tab='profile';app()}
const bindBeforeSettings=bindI18n;
function bindSettings(){bindBeforeSettings();document.getElementById('openSettings')?.addEventListener('click',()=>{state.tab='settings';app()});document.getElementById('settingsBack')?.addEventListener('click',()=>{state.tab='profile';app()});document.getElementById('saveSettings')?.addEventListener('click',saveSettings)}
function app(){applyPrefs();document.documentElement.lang=currentLanguage;document.documentElement.dir=['ar','ur','fa'].includes(currentLanguage)?'rtl':'ltr';document.getElementById('app').innerHTML=state.user?mainUI().replace('${view()}',viewWithSettings()):authUI();if(state.user){const main=document.querySelector('main.content');if(main)main.innerHTML=viewWithSettings()}bindSettings();requestAnimationFrame(()=>{attachCallMedia();attachGroupMedia();setupMediaEfficiency()})}

// Vibes 1.11: reactions and emoji composer.
const REACTION_EMOJIS=['👍','❤️','😂','😮','😢','😡','🔥','👏'];
const COMPOSER_EMOJIS=['😀','😊','😍','🥰','😂','😎','🤔','😢','😡','👍','❤️','🔥','🎉','✨','🙏','💯'];
state.reactions=[];state.emojiTarget=null;
function reactionsFor(type,id){return state.reactions.filter(r=>r.target_type===type&&String(r.target_id)===String(id))}
function reactionBar(type,id){const rows=reactionsFor(type,id);return `<div class="reaction-bar">${REACTION_EMOJIS.map(e=>{const count=rows.filter(r=>r.emoji===e).length;const mine=rows.some(r=>r.emoji===e&&r.user_id===state.user?.id);return `<button class="${mine?'active':''}" data-react-type="${type}" data-react-id="${esc(id)}" data-react-emoji="${e}">${e}${count?` <small>${count}</small>`:''}</button>`}).join('')}</div>`}
function emojiPicker(target){return `<button class="emoji-open" data-emoji-target="${target}">😊</button><div class="emoji-picker hidden" id="emoji-${target}">${COMPOSER_EMOJIS.map(e=>`<button data-insert-emoji="${e}" data-emoji-target="${target}">${e}</button>`).join('')}</div>`}
async function toggleReaction(type,id,emoji){const mine=state.reactions.find(r=>r.target_type===type&&String(r.target_id)===String(id)&&r.user_id===state.user.id);if(!cloudReady){state.reactions=state.reactions.filter(r=>r!==mine);if(!mine||mine.emoji!==emoji)state.reactions.push({user_id:state.user.id,target_type:type,target_id:String(id),emoji});return app()}let error;if(mine&&mine.emoji===emoji){({error}=await sb.from('content_reactions').delete().eq('user_id',state.user.id).eq('target_type',type).eq('target_id',String(id)))}else{({error}=await sb.from('content_reactions').upsert({user_id:state.user.id,target_type:type,target_id:String(id),emoji},{onConflict:'user_id,target_type,target_id'}))}if(error)return toast('Reaction could not be saved');await loadReactions();app()}
async function loadReactions(){if(!cloudReady||!state.user)return;const {data,error}=await sb.from('content_reactions').select('*').limit(1000);if(!error)state.reactions=data||[]}
const loadSocialBeforeReactions=loadSocialExtras;
async function loadSocialWithReactions(){await Promise.all([loadSocialBeforeReactions(),loadReactions()])}
function postCard(p){const fx=filterCss(p.filter_name);const media=p.image?(isVideoMedia(p.image,p.media_type)?`<video class="post-img smart-video" src="${esc(p.image)}" controls playsinline preload="metadata" style="filter:${fx}"></video>`:`<img class="post-img" src="${esc(p.image)}" loading="lazy" decoding="async" style="filter:${fx}">`):'';return `<article class="card"><div class="row"><div class="avatar">${esc((p.user||'U')[0])}</div><div class="grow"><b>${esc(p.user||'Vibes user')}</b><div class="muted">${esc(p.handle||handleOf(p.user))} · ${esc(p.time||'')}</div></div></div><div class="post-text">${esc(p.text||'')}</div>${media}${reactionBar('post',p.id)}<div class="actions"><button class="action" data-comment="${esc(p.id)}">💬 ${(p.comments||[]).length}</button><button class="action" data-share="${esc(p.id)}">↗ Share</button><button class="action" data-save="${esc(p.id)}">🔖 Save</button></div></article>`}
function feedView(){const visible=state.posts.slice(0,state.feedLimit);return `${storiesTray()}<div class="composer card"><div class="composer-wrap"><textarea id="quickPost" placeholder="What's on your mind?"></textarea>${emojiPicker('quickPost')}</div><div class="composer-tools"><label class="pill">📷 Photo/Video<input id="quickImage" type="file" accept="image/*,video/*" hidden></label><div class="grow"></div><button class="btn" id="quickPostBtn">Post</button></div><div id="quickPreview"></div></div>${visible.map(postCard).join('')}${state.posts.length>visible.length?`<button id="loadMore" class="pill perf-load-more">Load more</button>`:''}`}
function storyViewerView(){const s=state.storyOpen;if(!s)return feedView();const media=s.media_url||s.image;const id=s.id||s.media_url||s.image;return `<div class="story-viewer"><button class="pill" id="closeStory">✕ Close</button>${isVideoMedia(media,s.media_type)?`<video class="story-media smart-video" src="${esc(media)}" controls autoplay playsinline style="filter:${filterCss(s.filter_name)}"></video>`:`<img class="story-media" src="${esc(media)}" style="filter:${filterCss(s.filter_name)}">`}${reactionBar('story',id)}</div>`}
function chatView(){if(state.group?.active)return groupCallUI();if(state.call?.active)return activeCallUI();if(!state.chatOpen)return `<div class="title">Messages</div><div class="chat-list"><div class="card row" id="openChat"><div class="avatar">N</div><div><b>Nadia</b><div class="muted">Tap to open chat</div></div></div></div>`;return `<button class="pill" id="backChat">← Back</button><div class="card messages">${state.messages.map((m,i)=>`<div class="message-unit"><div class="bubble ${m.me?'me':''}">${esc(m.text)}</div>${reactionBar('message',String(i))}</div>`).join('')}</div><div class="chatbar"><div class="composer-wrap grow"><input id="msg" placeholder="Write a message">${emojiPicker('msg')}</div><button class="btn" id="sendMsg">Send</button></div>`}
function bindReactions(){bindSettings();document.querySelectorAll('[data-react-type]').forEach(b=>b.onclick=()=>toggleReaction(b.dataset.reactType,b.dataset.reactId,b.dataset.reactEmoji));document.querySelectorAll('.emoji-open').forEach(b=>b.onclick=()=>document.getElementById('emoji-'+b.dataset.emojiTarget)?.classList.toggle('hidden'));document.querySelectorAll('[data-insert-emoji]').forEach(b=>b.onclick=()=>{const input=document.getElementById(b.dataset.emojiTarget);if(!input)return;const start=input.selectionStart??input.value.length;input.value=input.value.slice(0,start)+b.dataset.insertEmoji+input.value.slice(input.selectionEnd??start);input.focus();input.selectionStart=input.selectionEnd=start+b.dataset.insertEmoji.length})}
function app(){applyPrefs();document.documentElement.lang=currentLanguage;document.documentElement.dir=['ar','ur','fa'].includes(currentLanguage)?'rtl':'ltr';document.getElementById('app').innerHTML=state.user?mainUI():authUI();if(state.user&&state.tab==='settings'){const main=document.querySelector('main.content');if(main)main.innerHTML=settingsView()}bindReactions();requestAnimationFrame(()=>{attachCallMedia();attachGroupMedia();setupMediaEfficiency()})}
async function cloudBootstrap(){if(!cloudReady)return;const {data:{session}}=await sb.auth.getSession();if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople(),loadSocialWithReactions()]);await Promise.all([setupCallRealtime(),setupGroupRealtime()]);await registerNativePushToken()}sb.auth.onAuthStateChange(async(_,next)=>{if(next?.user){state.user={...next.user,name:next.user.user_metadata?.name||next.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople(),loadSocialWithReactions()]);await Promise.all([setupCallRealtime(),setupGroupRealtime()]);await registerNativePushToken()}else{closeCallMedia();state.user=null}app()})}

// Vibes 1.12: nested comments, replies, comment reactions, share, and save.
state.activePost=null;state.replyTo=null;
async function loadCloudPosts(){if(!cloudReady)return;state.loading=true;app();const {data,error}=await sb.from('posts').select('id,user_id,body,image_url,filter_name,created_at,profiles(display_name,username),likes(count),comments(id,body,user_id,parent_comment_id,created_at)').order('created_at',{ascending:false}).limit(50);state.loading=false;if(error){console.error(error);return toast('Posts could not be loaded')}state.posts=(data||[]).filter(p=>!state.blocked.includes(p.user_id)).map(p=>({id:p.id,user:p.profiles?.display_name||'Vibes user',handle:p.profiles?.username?('@'+p.profiles.username):'@user',text:p.body,image:p.image_url,filter_name:p.filter_name||'natural',time:new Date(p.created_at).toLocaleString(),likes:p.likes?.[0]?.count||0,comments:p.comments||[],user_id:p.user_id,liked:false}));app()}
function commentTree(comments,parent=null,depth=0){return comments.filter(c=>(c.parent_comment_id||null)===parent).map(c=>`<div class="comment-node depth-${Math.min(depth,2)}"><div class="comment-body"><b>User</b><div>${esc(c.body)}</div></div>${reactionBar('comment',c.id)}<button class="comment-reply" data-reply-comment="${c.id}">Reply</button>${commentTree(comments,c.id,depth+1)}</div>`).join('')}
function commentsView(){const p=state.posts.find(x=>String(x.id)===String(state.activePost));if(!p)return `<div class="empty">Post not found</div>`;return `<div class="row"><button class="pill" id="commentsBack">←</button><div class="title grow">Comments</div></div><div class="card"><b>${esc(p.user)}</b><div class="post-text">${esc(p.text)}</div></div><div class="comments-list">${p.comments.length?commentTree(p.comments):`<div class="empty">Be the first to comment.</div>`}</div>${state.replyTo?`<div class="replying">Replying to a comment <button id="cancelReply">✕</button></div>`:''}<div class="chatbar"><div class="composer-wrap grow"><input id="commentInput" placeholder="Write a comment"><button class="emoji-open" data-emoji-target="commentInput">😊</button><div class="emoji-picker hidden" id="emoji-commentInput">${COMPOSER_EMOJIS.map(e=>`<button data-insert-emoji="${e}" data-emoji-target="commentInput">${e}</button>`).join('')}</div></div><button class="btn" id="sendComment">Send</button></div>`}
async function sendNestedComment(){const input=document.getElementById('commentInput');const body=input?.value.trim();if(!body)return;const p=state.posts.find(x=>String(x.id)===String(state.activePost));if(!p)return;if(!cloudReady){p.comments.push({id:'demo-comment-'+Date.now(),body,user_id:state.user.id,parent_comment_id:state.replyTo});state.replyTo=null;persist();return app()}const {error}=await sb.from('comments').insert({post_id:p.id,user_id:state.user.id,body,parent_comment_id:state.replyTo});if(error)return toast('Comment could not be posted');state.replyTo=null;await loadCloudPosts();state.activePost=p.id;state.tab='comments';app()}
function postCard(p){const fx=filterCss(p.filter_name);const media=p.image?(isVideoMedia(p.image,p.media_type)?`<video class="post-img smart-video" src="${esc(p.image)}" controls playsinline preload="metadata" style="filter:${fx}"></video>`:`<img class="post-img" src="${esc(p.image)}" loading="lazy" decoding="async" style="filter:${fx}">`):'';const saved=state.saved.some(x=>String(x)===String(p.id));return `<article class="card"><div class="row"><div class="avatar">${esc((p.user||'U')[0])}</div><div class="grow"><b>${esc(p.user||'Vibes user')}</b><div class="muted">${esc(p.handle||handleOf(p.user))} · ${esc(p.time||'')}</div></div></div><div class="post-text">${esc(p.text||'')}</div>${media}${reactionBar('post',p.id)}<div class="actions four"><button class="action" data-open-comments="${esc(p.id)}">💬 ${(p.comments||[]).length}</button><button class="action" data-share="${esc(p.id)}">↗ Share</button><button class="action" data-save="${esc(p.id)}">${saved?'🔖 Saved':'▱ Save'}</button><button class="action" data-react-type="post" data-react-id="${esc(p.id)}" data-react-emoji="❤️">❤️ React</button></div></article>`}
const bindBeforeComments=bindReactions;
function bindComments(){bindBeforeComments();document.querySelectorAll('[data-open-comments]').forEach(b=>b.onclick=()=>{state.activePost=b.dataset.openComments;state.tab='comments';app()});document.getElementById('commentsBack')?.addEventListener('click',()=>{state.tab='feed';state.replyTo=null;app()});document.querySelectorAll('[data-reply-comment]').forEach(b=>b.onclick=()=>{state.replyTo=b.dataset.replyComment;app()});document.getElementById('cancelReply')?.addEventListener('click',()=>{state.replyTo=null;app()});document.getElementById('sendComment')?.addEventListener('click',sendNestedComment)}
function app(){applyPrefs();document.documentElement.lang=currentLanguage;document.documentElement.dir=['ar','ur','fa'].includes(currentLanguage)?'rtl':'ltr';document.getElementById('app').innerHTML=state.user?mainUI():authUI();if(state.user){const main=document.querySelector('main.content');if(state.tab==='settings')main.innerHTML=settingsView();if(state.tab==='comments')main.innerHTML=commentsView()}bindComments();requestAnimationFrame(()=>{attachCallMedia();attachGroupMedia();setupMediaEfficiency()})}

// Vibes 1.13: text, photo, and video status.
const STATUS_BACKGROUNDS=['violet','sunset','ocean','forest','midnight'];
function storiesTray(){const list=state.stories.length?state.stories:state.posts.slice(0,6);return `<div class="status-create"><button class="pill" id="textStatus">✍ Text status</button><label class="pill">📷 Photo/Video status<input id="storyFile" type="file" accept="image/*,video/*" hidden></label></div><div class="stories">${list.map((s,i)=>`<button class="story" data-story="${i}"><span class="story-ring">${s.media_type==='text'?`<span class="status-mini bg-${esc(s.background||'violet')}">${esc((s.body||'Aa').slice(0,2))}</span>`:(s.media_url||s.image?`<img src="${esc(s.media_url||s.image)}" loading="lazy" decoding="async" style="filter:${filterCss(s.filter_name)}">`:esc((s.user||'V')[0]))}</span><small>${esc(s.profiles?.display_name||s.user||'Vibes')}</small></button>`).join('')}</div>`}
function textStatusEditor(){return `<div class="text-status-editor bg-${esc(state.statusBackground||'violet')}"><button class="pill" id="cancelTextStatus">← Back</button><textarea id="statusText" maxlength="500" placeholder="Write a status...">${esc(state.statusDraft||'')}</textarea><div class="status-colors">${STATUS_BACKGROUNDS.map(x=>`<button class="bg-${x} ${state.statusBackground===x?'active':''}" data-status-bg="${x}" aria-label="${x}"></button>`).join('')}</div><button class="btn" id="publishTextStatus">Share status</button></div>`}
function storyViewerView(){const s=state.storyOpen;if(!s)return feedView();const id=s.id||s.media_url||s.image||s.body;if(s.media_type==='text')return `<div class="story-viewer text-story bg-${esc(s.background||'violet')}"><button class="pill" id="closeStory">✕ Close</button><div class="text-story-body">${esc(s.body)}</div>${reactionBar('story',id)}</div>`;const media=s.media_url||s.image;return `<div class="story-viewer"><button class="pill" id="closeStory">✕ Close</button>${isVideoMedia(media,s.media_type)?`<video class="story-media smart-video" src="${esc(media)}" controls autoplay playsinline style="filter:${filterCss(s.filter_name)}"></video>`:`<img class="story-media" src="${esc(media)}" style="filter:${filterCss(s.filter_name)}">`}${reactionBar('story',id)}</div>`}
async function publishTextStatus(){const body=document.getElementById('statusText')?.value.trim();if(!body)return toast('Write something first');const background=state.statusBackground||'violet';if(!cloudReady){state.stories.unshift({id:'demo-story-'+Date.now(),user:state.user.name,media_type:'text',body,background,expires_at:new Date(Date.now()+86400000).toISOString()});state.tab='feed';return app()}const {error}=await sb.from('stories').insert({user_id:state.user.id,media_type:'text',body,background});if(error)return toast('Status could not be shared');state.tab='feed';await loadSocialExtras();app()}
const bindBeforeStatus=bindComments;
function bindStatus(){bindBeforeStatus();document.getElementById('textStatus')?.addEventListener('click',()=>{state.statusDraft='';state.statusBackground='violet';state.tab='textStatus';app()});document.querySelectorAll('[data-status-bg]').forEach(b=>b.onclick=()=>{state.statusDraft=document.getElementById('statusText')?.value||'';state.statusBackground=b.dataset.statusBg;app()});document.getElementById('publishTextStatus')?.addEventListener('click',publishTextStatus);document.getElementById('cancelTextStatus')?.addEventListener('click',()=>{state.tab='feed';app()})}
function app(){applyPrefs();document.documentElement.lang=currentLanguage;document.documentElement.dir=['ar','ur','fa'].includes(currentLanguage)?'rtl':'ltr';document.getElementById('app').innerHTML=state.user?mainUI():authUI();if(state.user){const main=document.querySelector('main.content');if(state.tab==='settings')main.innerHTML=settingsView();if(state.tab==='comments')main.innerHTML=commentsView();if(state.tab==='textStatus')main.innerHTML=textStatusEditor()}bindStatus();requestAnimationFrame(()=>{attachCallMedia();attachGroupMedia();setupMediaEfficiency()})}

// Vibes 1.14: block, unblock, restrict, unrestrict, and categorized reporting.
state.restricted=[];state.safetyProfiles={};
async function loadSafetyData(){if(!cloudReady||!state.user)return;const [blocks,restrictions]=await Promise.all([sb.from('blocks').select('blocked_id,profiles!blocks_blocked_id_fkey(display_name,username)').eq('blocker_id',state.user.id),sb.from('restrictions').select('restricted_id,profiles!restrictions_restricted_id_fkey(display_name,username)').eq('owner_id',state.user.id)]);if(!blocks.error){state.blocked=(blocks.data||[]).map(x=>x.blocked_id);(blocks.data||[]).forEach(x=>state.safetyProfiles[x.blocked_id]=x.profiles)}if(!restrictions.error){state.restricted=(restrictions.data||[]).map(x=>x.restricted_id);(restrictions.data||[]).forEach(x=>state.safetyProfiles[x.restricted_id]=x.profiles)}}
async function blockUser(userId){if(!userId||userId===state.user.id)return;if(!confirm('Block this account? They will no longer be able to contact you.'))return;if(!cloudReady){if(!state.blocked.includes(userId))state.blocked.push(userId);persist();return app()}const {error}=await sb.from('blocks').upsert({blocker_id:state.user.id,blocked_id:userId});if(error)return toast('Account could not be blocked');await loadSafetyData();await loadCloudPosts();toast('Account blocked')}
async function unblockUser(userId){if(!cloudReady){state.blocked=state.blocked.filter(x=>x!==userId);persist();return app()}const {error}=await sb.from('blocks').delete().eq('blocker_id',state.user.id).eq('blocked_id',userId);if(error)return toast('Account could not be unblocked');await loadSafetyData();app()}
async function toggleRestrict(userId){const active=state.restricted.includes(userId);if(!cloudReady){state.restricted=active?state.restricted.filter(x=>x!==userId):[...state.restricted,userId];return app()}const q=sb.from('restrictions');const {error}=active?await q.delete().eq('owner_id',state.user.id).eq('restricted_id',userId):await q.insert({owner_id:state.user.id,restricted_id:userId});if(error)return toast('Restrict setting could not be updated');await loadSafetyData();app()}
async function reportPost(id){const p=state.posts.find(x=>String(x.id)===String(id));if(!p)return;const categories=['spam','harassment','hate','nudity','violence','fraud','impersonation','other'];const choice=prompt('Report category:\n1 Spam\n2 Harassment\n3 Hate\n4 Nudity\n5 Violence\n6 Fraud\n7 Impersonation\n8 Other','1');if(!choice)return;const category=categories[Math.max(0,Math.min(7,Number(choice)-1))]||'other';const reason=prompt('Please add details (required):');if(!reason?.trim())return;if(!cloudReady){state.reports.push({id,category,reason:reason.trim(),status:'open'});persist();return toast('Report submitted for review')}const {error}=await sb.from('reports').insert({reporter_id:state.user.id,post_id:id,target_user_id:p.user_id,category,reason:reason.trim()});toast(error?'Report could not be submitted':'Report submitted for moderator review')}
function safetyView(){const rows=(title,ids,action,label)=>`<div class="card"><div class="section-title">${title}</div>${ids.length?ids.map(id=>{const p=state.safetyProfiles[id]||{};return `<div class="setting-row"><div class="grow"><b>${esc(p.display_name||'Vibes user')}</b><div class="muted">${esc(p.username?'@'+p.username:id)}</div></div><button class="pill" data-${action}="${id}">${label}</button></div>`}).join(''):`<div class="muted">No accounts</div>`}</div>`;return `<div class="row"><button class="pill" id="safetyBack">←</button><div class="title grow">Safety controls</div></div>${rows('Blocked accounts',state.blocked,'unblock','Unblock')}${rows('Restricted accounts',state.restricted,'unrestrict','Unrestrict')}<div class="notice">Reports are reviewed by moderators. A report alone never automatically suspends an account.</div>`}
function postCard(p){const fx=filterCss(p.filter_name);const media=p.image?(isVideoMedia(p.image,p.media_type)?`<video class="post-img smart-video" src="${esc(p.image)}" controls playsinline preload="metadata" style="filter:${fx}"></video>`:`<img class="post-img" src="${esc(p.image)}" loading="lazy" decoding="async" style="filter:${fx}">`):'';return `<article class="card"><div class="row"><div class="avatar">${esc((p.user||'U')[0])}</div><div class="grow"><b>${esc(p.user||'Vibes user')}</b><div class="muted">${esc(p.handle||'')}</div></div>${p.user_id&&p.user_id!==state.user.id?`<div class="menu"><button class="icon-btn" data-menu="${p.id}">⋯</button><div id="menu-${p.id}" class="menu-panel hidden"><button data-report="${p.id}">⚑ Report</button><button data-restrict="${p.user_id}">${state.restricted.includes(p.user_id)?'Unrestrict':'Restrict'}</button><button data-block="${p.user_id}">Block</button></div></div>`:''}</div><div class="post-text">${esc(p.text||'')}</div>${media}${reactionBar('post',p.id)}<div class="actions four"><button class="action" data-open-comments="${p.id}">💬 ${(p.comments||[]).length}</button><button class="action" data-share="${p.id}">↗ Share</button><button class="action" data-save="${p.id}">🔖 Save</button><button class="action" data-react-type="post" data-react-id="${p.id}" data-react-emoji="❤️">❤️ React</button></div></article>`}
const settingsBeforeSafety=settingsView;
function settingsWithSafety(){return settingsBeforeSafety().replace('</div><button class="btn" id="saveSettings"',`<button class="pill safety-link" id="openSafety">🛡 Blocked & restricted accounts</button></div><button class="btn" id="saveSettings"`)}
const bindBeforeSafety=bindStatus;
function bindSafety(){bindBeforeSafety();document.getElementById('openSafety')?.addEventListener('click',()=>{state.tab='safety';app()});document.getElementById('safetyBack')?.addEventListener('click',()=>{state.tab='settings';app()});document.querySelectorAll('[data-unblock]').forEach(b=>b.onclick=()=>unblockUser(b.dataset.unblock));document.querySelectorAll('[data-unrestrict]').forEach(b=>b.onclick=()=>toggleRestrict(b.dataset.unrestrict));document.querySelectorAll('[data-restrict]').forEach(b=>b.onclick=()=>toggleRestrict(b.dataset.restrict))}
function app(){applyPrefs();document.documentElement.lang=currentLanguage;document.documentElement.dir=['ar','ur','fa'].includes(currentLanguage)?'rtl':'ltr';document.getElementById('app').innerHTML=state.user?mainUI():authUI();if(state.user){const main=document.querySelector('main.content');if(state.tab==='settings')main.innerHTML=settingsWithSafety();if(state.tab==='safety')main.innerHTML=safetyView();if(state.tab==='comments')main.innerHTML=commentsView();if(state.tab==='textStatus')main.innerHTML=textStatusEditor()}bindSafety();requestAnimationFrame(()=>{attachCallMedia();attachGroupMedia();setupMediaEfficiency()})}

// ---- Vibes 1.15: official API/embed social import feed ----
// A trusted backend normalizes official platform responses into external_posts.
// The Android client has read-only access and never receives platform secrets.
const nativePostCard=postCard;
function platformLabel(platform){return ({facebook:'Facebook',instagram:'Instagram',tiktok:'TikTok'})[platform]||'Social'}
function externalPostCard(p){
  const platform=String(p.platform||'social').toLowerCase();
  const preview=p.thumbnail_url||p.media_url||'';
  const media=preview?`<img class="post-img" src="${esc(preview)}" loading="lazy" decoding="async" referrerpolicy="no-referrer" alt="${esc(platformLabel(platform))} post preview">`:'';
  return `<article class="card external-card"><a class="external-link" href="${esc(p.permalink)}" target="_blank" rel="noopener noreferrer"><div class="row"><div class="avatar">${esc((p.creator_name||platformLabel(platform))[0]||'S')}</div><div class="grow"><b>${esc(p.creator_name||platformLabel(platform))}</b><div class="muted">${esc(p.creator_handle||'')} · ${esc(p.time||'')}</div><span class="source-badge ${esc(platform)}">↗ ${esc(platformLabel(platform))}</span></div></div><div class="post-text">${esc(p.caption||'')}</div>${media}<div class="muted source-note">View the original post on ${esc(platformLabel(platform))}</div></a></article>`
}
postCard=function(p){return p?.external?externalPostCard(p):nativePostCard(p)};

async function loadOfficialSocialPosts(){
  if(!cloudReady)return [];
  const {data,error}=await sb.from('external_posts').select('id,platform,external_id,creator_name,creator_handle,caption,media_type,media_url,thumbnail_url,permalink,published_at').eq('is_available',true).order('published_at',{ascending:false}).limit(50);
  if(error){console.warn('Official social feed unavailable',error);return []}
  return (data||[]).map(p=>({...p,external:true,user:p.creator_name,handle:p.creator_handle,text:p.caption,image:p.thumbnail_url||p.media_url,time:new Date(p.published_at).toLocaleString()}));
}

async function loadCloudPosts(){
  if(!cloudReady)return;
  state.loading=true;app();
  const [nativeResult,externalPosts]=await Promise.all([
    sb.from('posts').select('id,user_id,body,image_url,filter_name,created_at,profiles(display_name,username),likes(count),comments(id,body,user_id,parent_comment_id,created_at)').order('created_at',{ascending:false}).limit(50),
    loadOfficialSocialPosts()
  ]);
  state.loading=false;
  if(nativeResult.error){console.error(nativeResult.error);toast('Posts could not be loaded');return app()}
  const nativePosts=(nativeResult.data||[]).filter(p=>!state.blocked.includes(p.user_id)).map(p=>({id:p.id,user:p.profiles?.display_name||'Vibes user',handle:p.profiles?.username?('@'+p.profiles.username):'@user',text:p.body,image:p.image_url,filter_name:p.filter_name||'natural',time:new Date(p.created_at).toLocaleString(),sortTime:new Date(p.created_at).getTime(),likes:p.likes?.[0]?.count||0,comments:p.comments||[],user_id:p.user_id,liked:false}));
  externalPosts.forEach(p=>p.sortTime=new Date(p.published_at).getTime());
  state.posts=[...nativePosts,...externalPosts].sort((a,b)=>(b.sortTime||0)-(a.sortTime||0));
  app();
}
async function cloudBootstrap(){if(!cloudReady)return;const hydrate=async session=>{state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople(),loadSocialWithReactions(),loadSafetyData()]);await Promise.all([setupCallRealtime(),setupGroupRealtime()]);await registerNativePushToken()};const {data:{session}}=await sb.auth.getSession();if(session?.user)await hydrate(session);sb.auth.onAuthStateChange(async(_,next)=>{if(next?.user)await hydrate(next);else{closeCallMedia();state.user=null}app()})}

// ---- Vibes 1.16: username/name search, follow/unfollow, and authenticated Instagram sync ----
state.followingIds=[];
state.followCounts={followers:0,following:0};
state.profileStats={};
state.userSearchResults=[];
state.searchQuery='';
let peopleSearchTimer=null;

async function loadFollowData(){
  if(!cloudReady||!state.user)return;
  const [following,followers]=await Promise.all([
    sb.from('follows').select('following_id').eq('follower_id',state.user.id),
    sb.from('follows').select('follower_id').eq('following_id',state.user.id)
  ]);
  if(!following.error)state.followingIds=(following.data||[]).map(x=>x.following_id);
  if(!followers.error)state.followCounts.followers=(followers.data||[]).length;
  state.followCounts.following=state.followingIds.length;
}

async function loadProfileStats(userId){
  if(!cloudReady||!userId)return;
  const [followers,following]=await Promise.all([
    sb.from('follows').select('follower_id',{count:'exact',head:true}).eq('following_id',userId),
    sb.from('follows').select('following_id',{count:'exact',head:true}).eq('follower_id',userId)
  ]);
  state.profileStats[userId]={followers:followers.count||0,following:following.count||0};
}

function personSearchCard(person){
  const own=person.id===state.user?.id;
  const following=state.followingIds.includes(person.id);
  const name=person.display_name||[person.first_name,person.middle_name,person.last_name].filter(Boolean).join(' ')||'Vibes user';
  return `<div class="card row person-result" data-open-profile="${esc(person.id)}"><div class="avatar">${person.avatar_url?`<img src="${esc(person.avatar_url)}" alt="">`:esc(name[0]||'V')}</div><div class="grow"><b>${esc(name)}</b><div class="muted">${esc(person.username?'@'+person.username:'Vibes user')}</div></div>${own?'<span class="muted">You</span>':`<button class="pill follow-btn ${following?'following':''}" data-follow-user="${esc(person.id)}">${following?'Following':'Follow'}</button>`}</div>`;
}

function renderPeopleSearch(){
  const target=document.getElementById('peopleSearchResults');
  if(!target)return;
  const q=state.searchQuery.trim().toLowerCase();
  const postMatches=q?state.posts.filter(p=>!p.external&&`${p.user||''} ${p.handle||''} ${p.text||''}`.toLowerCase().includes(q)).slice(0,12):[];
  const people=state.userSearchResults;
  if(!q){target.innerHTML='<div class="empty">Search by name or @username</div>';return}
  target.innerHTML=`<div class="search-section-title">People</div>${people.length?people.map(personSearchCard).join(''):'<div class="empty compact">No matching account</div>'}<div class="search-section-title">Posts</div>${postMatches.length?postMatches.map(postCard).join(''):'<div class="empty compact">No matching post</div>'}`;
  bindPeopleSearchActions();
}

async function searchPeople(query){
  state.searchQuery=query.trim();
  if(!cloudReady||!state.searchQuery){state.userSearchResults=[];return renderPeopleSearch()}
  const term=state.searchQuery.replace(/^@/,'').slice(0,50);
  const fields='id,display_name,first_name,middle_name,last_name,username,avatar_url';
  const [byName,byUsername]=await Promise.all([
    sb.from('profiles').select(fields).ilike('display_name',`%${term}%`).limit(20),
    sb.from('profiles').select(fields).ilike('username',`%${term}%`).limit(20)
  ]);
  const found=[...(byName.data||[]),...(byUsername.data||[])];
  state.userSearchResults=[...new Map(found.map(p=>[p.id,p])).values()].slice(0,20);
  renderPeopleSearch();
}

async function toggleFollow(userId){
  if(!userId||userId===state.user?.id)return;
  const following=state.followingIds.includes(userId);
  const query=sb.from('follows');
  const {error}=following
    ?await query.delete().eq('follower_id',state.user.id).eq('following_id',userId)
    :await query.insert({follower_id:state.user.id,following_id:userId});
  if(error)return toast('Follow setting could not be updated');
  await Promise.all([loadFollowData(),loadProfileStats(userId)]);
  app();
}

async function openPersonProfile(userId){
  const person=[state.user,...state.userSearchResults,...state.people].find(p=>p?.id===userId);
  if(!person)return;
  state.profile=person;
  state.tab='profile';
  await loadProfileStats(userId);
  app();
}

function bindPeopleSearchActions(){
  document.querySelectorAll('[data-follow-user]').forEach(b=>b.onclick=e=>{e.stopPropagation();toggleFollow(b.dataset.followUser)});
  document.querySelectorAll('[data-open-profile]').forEach(row=>row.onclick=()=>openPersonProfile(row.dataset.openProfile));
}

searchView=function(){return `<div class="title">Search people & posts</div><div class="card people-search"><input id="searchBox" value="${esc(state.searchQuery)}" placeholder="Name or @username" autocomplete="off"></div><div id="peopleSearchResults"><div class="empty">Search by name or @username</div></div>`};

profileView=function(){
  const u=state.profile||state.user||{};
  const own=u.id===state.user?.id;
  const name=u.display_name||u.name||u.user_metadata?.name||u.email?.split('@')[0]||'Vibes User';
  const stats=own?state.followCounts:(state.profileStats[u.id]||{followers:0,following:0});
  const postCount=state.posts.filter(p=>!p.external&&(p.user_id===u.id||p.user===name)).length;
  const following=state.followingIds.includes(u.id);
  return `<div class="card profile-head"><div class="avatar lg">${u.avatar_url?`<img src="${esc(u.avatar_url)}" alt="">`:esc(name[0]||'V')}</div><div class="title">${esc(name)}</div><div class="muted">${esc(u.username?'@'+u.username:(u.handle||handleOf(name)))}</div><div class="stats"><div class="stat"><b>${postCount}</b><div class="muted">Posts</div></div><div class="stat"><b>${stats.followers||0}</b><div class="muted">Followers</div></div><div class="stat"><b>${stats.following||0}</b><div class="muted">Following</div></div></div>${own?'<button class="btn light" id="editProfile">Edit profile</button> <button class="pill" id="openSettings">⚙ Settings</button>':`<button class="btn ${following?'light':''}" data-follow-user="${esc(u.id)}">${following?'Unfollow':'Follow'}</button>`}</div>${own?'<div class="card"><div class="section-title">Safety & community</div><p class="muted">Illegal content, sexual harassment, threats, hate and fraud are not allowed. Use Report, Block or Restrict when needed.</p><button class="pill" id="openSafety">🛡 Safety controls</button></div>':''}`;
};

async function syncOfficialSocialPosts(){
  if(!cloudReady||!state.user)return;
  try{
    const {data,error}=await sb.functions.invoke('sync-instagram-posts',{body:{}});
    if(error){console.warn('Instagram sync unavailable',error);return}
    if(data?.imported>0)await loadCloudPosts();
  }catch(error){console.warn('Instagram sync failed',error)}
}

const bindBeforeFollowSearch=bindSafety;
bindSafety=function(){
  bindBeforeFollowSearch();
  const originalSearch=document.getElementById('searchBox');
  if(originalSearch){
    const search=originalSearch.cloneNode(true);
    originalSearch.replaceWith(search);
    search.oninput=e=>{state.searchQuery=e.target.value;clearTimeout(peopleSearchTimer);peopleSearchTimer=setTimeout(()=>searchPeople(state.searchQuery),280)};
  }
  const profileNav=document.querySelector('[data-tab="profile"]');
  if(profileNav)profileNav.onclick=()=>{state.profile=null;state.tab='profile';state.chatOpen=false;app()};
  bindPeopleSearchActions();
};

async function cloudBootstrap(){
  if(!cloudReady)return;
  const hydrate=async session=>{
    state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};
    await Promise.all([loadCloudPosts(),loadPeople(),loadSocialWithReactions(),loadSafetyData(),loadFollowData()]);
    await Promise.all([setupCallRealtime(),setupGroupRealtime()]);
    await registerNativePushToken();
    syncOfficialSocialPosts();
  };
  const {data:{session}}=await sb.auth.getSession();
  if(session?.user)await hydrate(session);
  sb.auth.onAuthStateChange(async(_,next)=>{
    if(next?.user)await hydrate(next);
    else{closeCallMedia();state.user=null}
    app();
  });
}

// Keep the final release bootstrap and profile implementation authoritative.
profileView=richProfileView;
async function cloudBootstrap(){return cloudBootstrapV117()}

// ---- Vibes Ideas Lab: community proposals, voting and transparent delivery status ----
state.featureRequests=[];
let ideasChannel=null;
let ideasRefreshTimer=null;

async function loadFeatureRequests(){
  if(!cloudReady||!state.user)return;
  const {data,error}=await sb.from('feature_requests').select('id,user_id,title,description,status,created_at,profiles(display_name,username),feature_request_votes(user_id)').order('created_at',{ascending:false}).limit(100);
  if(error){console.warn('Ideas Lab unavailable',error);return}
  state.featureRequests=(data||[]).map(item=>({...item,votes:item.feature_request_votes?.length||0,voted:item.feature_request_votes?.some(v=>v.user_id===state.user.id)})).sort((a,b)=>b.votes-a.votes||new Date(b.created_at)-new Date(a.created_at));
}

function ideaStatus(status){return({submitted:'Submitted',reviewing:'Reviewing',planned:'Planned',building:'Building',released:'Released',declined:'Not planned'})[status]||'Submitted'}
function ideasView(){
  const cards=state.featureRequests.map(item=>`<article class="card idea-card"><div class="row"><div class="grow"><b>${esc(item.title)}</b><div class="muted">${esc(item.profiles?.display_name||item.profiles?.username||'Vibes member')} · ${new Date(item.created_at).toLocaleDateString()}</div></div><span class="idea-status status-${esc(item.status)}">${esc(ideaStatus(item.status))}</span></div>${item.description?`<p>${esc(item.description)}</p>`:''}<button class="pill idea-vote ${item.voted?'active':''}" data-idea-vote="${esc(item.id)}">▲ ${Number(item.votes||0)} vote${Number(item.votes||0)===1?'':'s'}</button>${item.user_id===state.user.id&&item.status==='submitted'?` <button class="pill danger-soft" data-idea-delete="${esc(item.id)}">Delete</button>`:''}</article>`).join('');
  return `<div class="row"><button class="pill" id="ideasBack">←</button><div class="title grow">💡 Ideas Lab</div></div><div class="notice">Tell us what Vibes should build next. Voting uses only your account ID; it does not inspect private messages or external browsing.</div><div class="card idea-composer"><input id="ideaTitle" maxlength="100" placeholder="Feature title"><textarea id="ideaDescription" maxlength="1000" placeholder="How would this improve Vibes?"></textarea><button class="btn" id="submitIdea">Submit idea</button></div><div class="section-title">Community priorities</div>${cards||'<div class="empty">Be the first to suggest a feature.</div>'}`;
}

async function submitIdea(){
  const title=document.getElementById('ideaTitle')?.value.trim(),description=document.getElementById('ideaDescription')?.value.trim()||'';
  if(!title||title.length<3)return toast('Write a feature title');
  if(!cloudReady)return toast('Cloud login is required');
  const {error}=await sb.from('feature_requests').insert({user_id:state.user.id,title,description,status:'submitted'});
  if(error)return toast('Idea could not be submitted');
  await loadFeatureRequests();toast('Idea submitted');app();
}

async function toggleIdeaVote(id){
  const idea=state.featureRequests.find(item=>item.id===id);if(!idea||!cloudReady)return;
  const query=sb.from('feature_request_votes');
  const {error}=idea.voted?await query.delete().eq('request_id',id).eq('user_id',state.user.id):await query.insert({request_id:id,user_id:state.user.id});
  if(error)return toast('Vote could not be updated');
  await loadFeatureRequests();app();
}

async function deleteIdea(id){
  if(!confirm('Delete this submitted idea?'))return;
  const {error}=await sb.from('feature_requests').delete().eq('id',id).eq('user_id',state.user.id);
  if(error)return toast('Idea could not be deleted');
  await loadFeatureRequests();app();
}

async function setupIdeasRealtime(){
  if(!cloudReady||!state.user)return;if(ideasChannel)await sb.removeChannel(ideasChannel);
  ideasChannel=sb.channel(`vibes-ideas-${state.user.id}`).on('postgres_changes',{event:'*',schema:'public',table:'feature_requests'},()=>{clearTimeout(ideasRefreshTimer);ideasRefreshTimer=setTimeout(async()=>{await loadFeatureRequests();if(state.tab==='ideas')app()},300)}).on('postgres_changes',{event:'*',schema:'public',table:'feature_request_votes'},()=>{clearTimeout(ideasRefreshTimer);ideasRefreshTimer=setTimeout(async()=>{await loadFeatureRequests();if(state.tab==='ideas')app()},300)}).subscribe();
}

const profileBeforeIdeas=profileView;
profileView=function(){
  const html=profileBeforeIdeas();
  const selected=state.profile||state.meProfile||state.user||{};
  const own=!state.profile||selected.id===state.user?.id;
  return own?`${html}<div class="card ideas-entry"><div class="section-title">Help shape Vibes</div><p class="muted">Suggest new features, vote on community ideas and follow their progress.</p><button class="btn light" id="openIdeas">💡 Open Ideas Lab</button></div>`:html;
};
const viewBeforeIdeas=view;
view=function(){if(state.tab==='ideas')return ideasView();return viewBeforeIdeas()};
const bindBeforeIdeas=bindSafety;
bindSafety=function(){
  bindBeforeIdeas();
  document.getElementById('openIdeas')?.addEventListener('click',()=>{state.tab='ideas';app()});
  document.getElementById('ideasBack')?.addEventListener('click',()=>{state.tab='profile';state.profile=null;app()});
  document.getElementById('submitIdea')?.addEventListener('click',submitIdea);
  document.querySelectorAll('[data-idea-vote]').forEach(button=>button.onclick=()=>toggleIdeaVote(button.dataset.ideaVote));
  document.querySelectorAll('[data-idea-delete]').forEach(button=>button.onclick=()=>deleteIdea(button.dataset.ideaDelete));
};

// ---- Account authenticity and Premium: distinct trust and billing states ----
state.verificationRequest=null;
state.premiumEntitlement=null;
let trustChannel=null;

async function loadVerificationRequest(){
  if(!cloudReady||!state.user)return;
  const result=await sb.from('verification_requests').select('id,reason,note,status,created_at,reviewed_at').eq('user_id',state.user.id).order('created_at',{ascending:false}).limit(1).maybeSingle();
  if(!result.error)state.verificationRequest=result.data||null;
}

async function loadPremiumEntitlement(){
  if(!cloudReady||!state.user)return;
  const result=await sb.from('premium_entitlements').select('status,provider,product_id,current_period_end,updated_at').eq('user_id',state.user.id).maybeSingle();
  if(!result.error)state.premiumEntitlement=result.data||null;
}

function identityStatusLabel(status){
  return ({unverified:'Not verified',pending:'Review pending',verified:'Identity reviewed',rejected:'Review not approved'})[status]||'Not verified';
}

function authenticityView(){
  const profile=state.meProfile||{};
  const request=state.verificationRequest;
  const verified=profile.verification_status==='verified';
  const pending=request?.status==='pending'||profile.verification_status==='pending';
  const emailVerified=Boolean(state.user?.email_confirmed_at);
  const requestArea=verified
    ?'<div class="trust-success">✓ This account passed authenticity review.</div>'
    :pending
      ?'<div class="notice">Your request is pending human review. Reports alone do not automatically disable an account.</div>'
      :'<textarea id="verificationNote" maxlength="500" placeholder="Explain why this account should be reviewed"></textarea><button class="btn" id="requestVerification">Request human review</button>';
  return '<div class="row"><button class="pill" id="authenticityBack">←</button><div class="title grow">Account authenticity</div></div>'
    +'<div class="card"><div class="section-title">Verification status</div>'
    +'<div class="trust-row"><span>Email</span><b>'+(emailVerified?'Confirmed':'Confirmation required')+'</b></div>'
    +'<div class="trust-row"><span>Identity</span><b>'+esc(identityStatusLabel(profile.verification_status))+'</b></div>'
    +requestArea+'</div>'
    +'<div class="card"><div class="section-title">Fair verification</div><p>Profile photos are optional. Having no photo is never treated as proof of a fake account.</p><p class="muted">Vibes does not run hidden face recognition. Any future liveness check must use explicit consent, a disclosed provider, retention limits and a human appeal path.</p></div>';
}

function premiumView(){
  const profile=state.meProfile||{};
  const entitlement=state.premiumEntitlement;
  const active=['active','trial'].includes(entitlement?.status||profile.premium_status);
  const end=entitlement?.current_period_end||profile.premium_until;
  return '<div class="row"><button class="pill" id="premiumBack">←</button><div class="title grow">Vibes Premium</div></div>'
    +'<div class="card premium-card"><div class="premium-mark">✦</div><div class="section-title">'+(active?'Premium is active':'Premium membership')+'</div>'
    +'<p>Premium is an optional ad-free membership with a separate Premium badge. It never purchases identity verification.</p>'
    +(end?'<div class="muted">Current period ends '+esc(new Date(end).toLocaleDateString())+'</div>':'')
    +'<label class="setting-row"><div class="grow"><b>Show Premium badge</b><div class="muted">You can hide it from your profile.</div></div><input id="showPremiumBadge" type="checkbox" '+(profile.show_premium_badge!==false?'checked':'')+'></label>'
    +'<button class="btn light" id="savePremiumBadge">Save badge preference</button>'
    +(active?'':'<div class="notice">Secure purchases require a configured Google Play or payment-provider product. No payment is accepted until server-side receipt verification is connected.</div>')
    +'</div><div class="card"><div class="section-title">Clean experience</div><p class="muted">This release contains no third-party advertising SDK and does not sell an identity badge. Any future ads must pass content and privacy controls.</p></div>';
}

function restrictedAccountView(){
  const status=state.meProfile?.account_status||'under_review';
  const pending=state.verificationRequest?.status==='pending';
  return '<div class="restriction-shell"><div class="card"><div class="title">Account '+(status==='disabled'?'disabled':'under review')+'</div><p>Your account access is temporarily limited. You can request a human review and sign out.</p>'
    +(pending?'<div class="notice">A review request is already pending.</div>':'<textarea id="restrictionNote" maxlength="500" placeholder="Add context for the reviewer"></textarea><button class="btn" id="requestAccountReview">Request review</button>')
    +'<button class="pill" id="restrictedLogout">Sign out</button></div></div>';
}

async function submitVerificationRequest(reason='verified_badge',inputId='verificationNote'){
  if(!cloudReady||!state.user)return toast('Cloud login is required');
  const note=document.getElementById(inputId)?.value.trim()||'';
  const result=await sb.from('verification_requests').insert({user_id:state.user.id,reason,note,status:'pending'});
  if(result.error)return toast(result.error.code==='23505'?'A review is already pending':'Request could not be submitted');
  await loadVerificationRequest();
  toast('Review request submitted');
  app();
}

async function savePremiumBadgePreference(){
  const show=document.getElementById('showPremiumBadge')?.checked!==false;
  const result=await sb.from('profiles').update({show_premium_badge:show}).eq('id',state.user.id).select(RICH_PROFILE_FIELDS).single();
  if(result.error)return toast('Preference could not be saved');
  state.meProfile=result.data;
  toast('Badge preference saved');
  app();
}

async function setupTrustRealtime(){
  if(!cloudReady||!state.user)return;
  if(trustChannel)await sb.removeChannel(trustChannel);
  const refresh=async()=>{await Promise.all([loadRichProfile(),loadVerificationRequest(),loadPremiumEntitlement()]);app()};
  trustChannel=sb.channel('vibes-trust-'+state.user.id)
    .on('postgres_changes',{event:'UPDATE',schema:'public',table:'profiles',filter:'id=eq.'+state.user.id},refresh)
    .on('postgres_changes',{event:'*',schema:'public',table:'verification_requests',filter:'user_id=eq.'+state.user.id},refresh)
    .on('postgres_changes',{event:'*',schema:'public',table:'premium_entitlements',filter:'user_id=eq.'+state.user.id},refresh)
    .subscribe();
}

const profileBeforeTrust=profileView;
profileView=function(){
  const html=profileBeforeTrust();
  const selected=state.profile||state.meProfile||state.user||{};
  const own=!state.profile||selected.id===state.user?.id;
  const premium=['active','trial'].includes(selected.premium_status)&&selected.show_premium_badge!==false;
  const badge=premium?'<span class="premium-badge">✦ Premium</span>':'';
  return html+badge+(own?'<div class="card authenticity-entry"><div class="section-title">Account & membership</div><p class="muted">Manage human-reviewed authenticity and optional ad-free Premium separately.</p><button class="pill" id="openAuthenticity">✓ Authenticity</button> <button class="pill" id="openPremium">✦ Premium</button></div>':'');
};

const viewBeforeTrust=view;
view=function(){
  if(state.tab==='authenticity')return authenticityView();
  if(state.tab==='premium')return premiumView();
  return viewBeforeTrust();
};

const mainUIBeforeTrust=mainUI;
mainUI=function(){
  if(state.meProfile?.account_status&&state.meProfile.account_status!=='active')return restrictedAccountView();
  return mainUIBeforeTrust();
};

const bindBeforeTrust=bindSafety;
bindSafety=function(){
  bindBeforeTrust();
  document.getElementById('openAuthenticity')?.addEventListener('click',()=>{state.tab='authenticity';app()});
  document.getElementById('openPremium')?.addEventListener('click',()=>{state.tab='premium';app()});
  document.getElementById('authenticityBack')?.addEventListener('click',()=>{state.tab='profile';app()});
  document.getElementById('premiumBack')?.addEventListener('click',()=>{state.tab='profile';app()});
  document.getElementById('requestVerification')?.addEventListener('click',()=>submitVerificationRequest('verified_badge','verificationNote'));
  document.getElementById('requestAccountReview')?.addEventListener('click',()=>submitVerificationRequest('account_review','restrictionNote'));
  document.getElementById('savePremiumBadge')?.addEventListener('click',savePremiumBadgePreference);
  document.getElementById('restrictedLogout')?.addEventListener('click',()=>sb.auth.signOut());
};

// ---- Reviewed future releases and data-only feature rollouts ----
const CURRENT_VERSION_CODE=19;
state.latestRelease=null;
state.featureFlags={};
let futureChannel=null;

function rolloutBucket(id){
  return Array.from(String(id||'vibes')).reduce((sum,char)=>(sum*31+char.charCodeAt(0))%100,0);
}

async function loadFutureSystem(){
  if(!cloudReady||!state.user)return;
  const channels=state.meProfile?.update_channel==='early_access'?['stable','early_access']:['stable'];
  const [releases,flags]=await Promise.all([
    sb.from('app_releases').select('version_name,version_code,channel,summary,is_mandatory,published_at').in('channel',channels).order('version_code',{ascending:false}).limit(1),
    sb.from('app_feature_flags').select('key,enabled,rollout_percent,min_version_code,description')
  ]);
  if(!releases.error)state.latestRelease=releases.data?.[0]||null;
  if(!flags.error){
    const bucket=rolloutBucket(state.user.id);
    state.featureFlags=Object.fromEntries((flags.data||[]).map(flag=>[flag.key,Boolean(flag.enabled&&flag.min_version_code<=CURRENT_VERSION_CODE&&bucket<flag.rollout_percent)]));
  }
}

async function setupFutureRealtime(){
  if(!cloudReady||!state.user)return;
  if(futureChannel)await sb.removeChannel(futureChannel);
  const refresh=async()=>{await loadFutureSystem();if(state.tab==='settings'||state.tab==='profile')app()};
  futureChannel=sb.channel('vibes-future-'+state.user.id)
    .on('postgres_changes',{event:'*',schema:'public',table:'app_releases'},refresh)
    .on('postgres_changes',{event:'*',schema:'public',table:'app_feature_flags'},refresh)
    .subscribe();
}

const settingsBeforeFuture=settingsWithSafety;
settingsWithSafety=function(){
  const html=settingsBeforeFuture();
  const profile=state.meProfile||{};
  const release=state.latestRelease;
  const available=Number(release?.version_code||0)>CURRENT_VERSION_CODE;
  const futureCard='<div class="card"><div class="section-title">Future updates</div>'
    +settingRow('Release channel','Stable is tested broadly. Early access receives reviewed previews.', '<select id="prefUpdateChannel"><option value="stable" '+(profile.update_channel!=='early_access'?'selected':'')+'>Stable</option><option value="early_access" '+(profile.update_channel==='early_access'?'selected':'')+'>Early access</option></select>')
    +settingRow('Product update notices','Show important release and feature notices.', '<input id="prefProductUpdates" type="checkbox" '+(profile.product_updates!==false?'checked':'')+'>')
    +'<div class="release-status"><b>'+(available?'Update '+esc(release.version_name)+' available':'Vibes is up to date')+'</b><div class="muted">'+esc(available?release.summary:'Current version 1.17.0')+'</div></div></div>';
  return html.replace('<button class="btn" id="saveSettings"',futureCard+'<button class="btn" id="saveSettings"');
};

saveSettings=async function(){
  prefs.theme=document.getElementById('prefTheme').value;
  prefs.fontScale=Number(document.getElementById('prefFont').value);
  prefs.dataSaver=document.getElementById('prefDataSaver').checked;
  prefs.autoplay=document.getElementById('prefAutoplay').checked&&!prefs.dataSaver;
  prefs.notifications=document.getElementById('prefNotifications').checked;
  prefs.privateAccount=document.getElementById('prefPrivate').checked;
  prefs.allowMessages=document.getElementById('prefMessages').value;
  prefs.highQualityUploads=document.getElementById('prefQuality').checked;
  localStorage.setItem('vibes_preferences',JSON.stringify(prefs));
  applyPrefs();
  if(cloudReady&&state.user?.id){
    const update={
      theme:prefs.theme,
      data_saver:prefs.dataSaver,
      autoplay_videos:prefs.autoplay,
      is_private:prefs.privateAccount,
      allow_messages:prefs.allowMessages,
      update_channel:document.getElementById('prefUpdateChannel')?.value||'stable',
      product_updates:document.getElementById('prefProductUpdates')?.checked!==false
    };
    const result=await sb.from('profiles').update(update).eq('id',state.user.id).select(RICH_PROFILE_FIELDS).single();
    if(result.error)return toast('Settings could not be saved');
    state.meProfile=result.data;
    await loadFutureSystem();
  }
  toast('Settings saved');
  state.tab='profile';
  app();
};
