-- Vibes / Supabase schema
-- Run in Supabase SQL Editor on a NEW project.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Vibes User' check (char_length(display_name) between 1 and 50),
  first_name text not null default '' check (char_length(first_name) <= 50),
  middle_name text not null default '' check (char_length(middle_name) <= 50),
  last_name text not null default '' check (char_length(last_name) <= 50),
  age smallint check (age between 13 and 120),
  gender text check (gender in ('male','female','other','prefer_not_to_say')),
  preferred_language text not null default 'en' check (char_length(preferred_language) between 2 and 10),
  is_private boolean not null default false,
  allow_messages text not null default 'everyone' check (allow_messages in ('everyone','following','none')),
  autoplay_videos boolean not null default true,
  data_saver boolean not null default false,
  theme text not null default 'dark' check (theme in ('dark','light','system')),
  username text unique,
  bio text default '' check (char_length(bio) <= 240),
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null default '' check (char_length(body) <= 3000),
  image_url text,
  filter_name text not null default 'natural' check (filter_name in ('natural','bright','warm','cool','vivid','mono','soft')),
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(post_id,user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  parent_comment_id uuid references public.comments(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);

create table if not exists public.content_reactions (
  user_id uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('post','story','message','comment')),
  target_id text not null,
  emoji text not null check (emoji in ('👍','❤️','😂','😮','😢','😡','🔥','👏')),
  created_at timestamptz not null default now(),
  primary key (user_id,target_type,target_id)
);

create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(follower_id,following_id),
  check (follower_id <> following_id)
);

create index if not exists follows_following_idx on public.follows(following_id);
create index if not exists profiles_username_search_idx on public.profiles(lower(username));
create index if not exists profiles_display_name_search_idx on public.profiles(lower(display_name));

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(blocker_id,blocked_id),
  check (blocker_id <> blocked_id)
);

create table if not exists public.restrictions (
  owner_id uuid not null references public.profiles(id) on delete cascade,
  restricted_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(owner_id,restricted_id),
  check (owner_id <> restricted_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid references public.posts(id) on delete cascade,
  reason text not null check (char_length(reason) between 1 and 500),
  category text not null default 'other' check(category in ('spam','harassment','hate','nudity','violence','fraud','impersonation','other')),
  target_user_id uuid references public.profiles(id) on delete set null,
  resolution text,
  status text not null default 'open' check(status in ('open','reviewed','resolved')),
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now()
);
create table if not exists public.conversation_members (
  conversation_id uuid references public.conversations(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key(conversation_id,user_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check(char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);

-- Create profile automatically after signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,display_name,first_name,middle_name,last_name,age,gender,username)
  values(new.id,coalesce(new.raw_user_meta_data->>'name',split_part(new.email,'@',1)),
    coalesce(new.raw_user_meta_data->>'first_name',''),coalesce(new.raw_user_meta_data->>'middle_name',''),coalesce(new.raw_user_meta_data->>'last_name',''),
    nullif(new.raw_user_meta_data->>'age','')::smallint,nullif(new.raw_user_meta_data->>'gender',''),
    lower(regexp_replace(coalesce(new.raw_user_meta_data->>'name',split_part(new.email,'@',1)),'[^a-zA-Z0-9]+','','g')) || substr(new.id::text,1,6))
  on conflict(id) do nothing;
  return new;
end;$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.content_reactions enable row level security;
alter table public.follows enable row level security;
alter table public.blocks enable row level security;
alter table public.restrictions enable row level security;
alter table public.reports enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

-- Read public social content when signed in
create policy "profiles readable" on public.profiles for select to authenticated using (true);
create policy "profile owner insert" on public.profiles for insert to authenticated with check (auth.uid()=id);
create policy "profile owner update" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);
create policy "posts readable" on public.posts for select to authenticated using (true);
create policy "posts own insert" on public.posts for insert to authenticated with check (auth.uid()=user_id);
create policy "posts own update" on public.posts for update to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "posts own delete" on public.posts for delete to authenticated using (auth.uid()=user_id);
create policy "likes readable" on public.likes for select to authenticated using (true);
create policy "likes own insert" on public.likes for insert to authenticated with check (auth.uid()=user_id);
create policy "likes own delete" on public.likes for delete to authenticated using (auth.uid()=user_id);
create policy "comments readable" on public.comments for select to authenticated using (true);
create policy "comments own insert" on public.comments for insert to authenticated with check (auth.uid()=user_id);
create policy "comments own delete" on public.comments for delete to authenticated using (auth.uid()=user_id);
create policy "reactions readable" on public.content_reactions for select to authenticated using (true);
create policy "reactions own insert" on public.content_reactions for insert to authenticated with check ((select auth.uid())=user_id);
create policy "reactions own update" on public.content_reactions for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "reactions own delete" on public.content_reactions for delete to authenticated using ((select auth.uid())=user_id);
create policy "follows readable" on public.follows for select to authenticated using (true);
create policy "follows own insert" on public.follows for insert to authenticated with check (auth.uid()=follower_id);
create policy "follows own delete" on public.follows for delete to authenticated using (auth.uid()=follower_id);
create policy "blocks own read" on public.blocks for select to authenticated using (auth.uid()=blocker_id);
create policy "blocks own insert" on public.blocks for insert to authenticated with check (auth.uid()=blocker_id);
create policy "blocks own delete" on public.blocks for delete to authenticated using (auth.uid()=blocker_id);
create policy "restrictions owner read" on public.restrictions for select to authenticated using ((select auth.uid())=owner_id);
create policy "restrictions owner insert" on public.restrictions for insert to authenticated with check ((select auth.uid())=owner_id);
create policy "restrictions owner delete" on public.restrictions for delete to authenticated using ((select auth.uid())=owner_id);
create policy "reports own insert" on public.reports for insert to authenticated with check (auth.uid()=reporter_id);
create policy "reports own read" on public.reports for select to authenticated using (auth.uid()=reporter_id);

-- Private chat: only conversation members can see/access
create policy "conversation member read" on public.conversations for select to authenticated using (
  exists(select 1 from public.conversation_members cm where cm.conversation_id=id and cm.user_id=auth.uid())
);
create policy "member rows read" on public.conversation_members for select to authenticated using (
  exists(select 1 from public.conversation_members me where me.conversation_id=conversation_id and me.user_id=auth.uid())
);
create policy "message member read" on public.messages for select to authenticated using (
  exists(select 1 from public.conversation_members cm where cm.conversation_id=conversation_id and cm.user_id=auth.uid())
);
create policy "message member insert" on public.messages for insert to authenticated with check (
  auth.uid()=sender_id and exists(select 1 from public.conversation_members cm where cm.conversation_id=conversation_id and cm.user_id=auth.uid())
);

-- Least-privilege grants for browser clients
grant select,insert,update,delete on public.profiles,public.posts,public.likes,public.comments,public.follows,public.blocks to authenticated;
grant select,insert,delete on public.restrictions to authenticated;
grant select,insert,update,delete on public.content_reactions to authenticated;
grant select,insert on public.reports to authenticated;
grant select on public.conversations,public.conversation_members to authenticated;
grant select,insert on public.messages to authenticated;
revoke all on public.profiles,public.posts,public.likes,public.comments,public.follows,public.blocks,public.reports,public.conversations,public.conversation_members,public.messages from anon;
revoke all on public.restrictions from anon;
revoke all on public.content_reactions from anon;

-- Public post-media bucket. Post deletion can be paired with a server-side cleanup later.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('post-media','post-media',true,null,array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime'])
on conflict(id) do update set public=true,file_size_limit=null,allowed_mime_types=array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime'];

create policy "post media authenticated upload" on storage.objects for insert to authenticated with check (
  bucket_id='post-media' and (storage.foldername(name))[1]=auth.uid()::text
);
create policy "post media public read" on storage.objects for select using (bucket_id='post-media');
create policy "post media owner delete" on storage.objects for delete to authenticated using (
  bucket_id='post-media' and (storage.foldername(name))[1]=auth.uid()::text
);


-- Added in Vibes 1.1: in-app notifications
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete cascade,
  type text not null check(type in ('like','comment','follow','message','system')),
  post_id uuid references public.posts(id) on delete cascade,
  body text default '',
  read_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.notifications enable row level security;
create policy "notification owner read" on public.notifications for select to authenticated using(auth.uid()=user_id);
create policy "notification owner update" on public.notifications for update to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
grant select,update on public.notifications to authenticated;
revoke all on public.notifications from anon;

-- Vibes 1.15: normalized public posts imported by a trusted server worker.
-- OAuth credentials and platform access tokens must never be stored in this public table.
create table if not exists public.external_posts (
  id uuid primary key default gen_random_uuid(),
  platform text not null check (platform in ('facebook','instagram','tiktok')),
  external_id text not null,
  creator_name text not null default '',
  creator_handle text not null default '',
  caption text not null default '',
  media_type text not null default 'link' check (media_type in ('image','video','carousel','link')),
  media_url text,
  thumbnail_url text,
  permalink text not null,
  published_at timestamptz not null,
  is_available boolean not null default true,
  imported_at timestamptz not null default now(),
  unique(platform, external_id)
);

create index if not exists external_posts_feed_idx
  on public.external_posts (published_at desc) where is_available;

alter table public.external_posts enable row level security;
drop policy if exists "external posts authenticated read" on public.external_posts;
create policy "external posts authenticated read" on public.external_posts
  for select to authenticated using (is_available = true);
grant select on public.external_posts to authenticated;
revoke all on public.external_posts from anon;

-- Realtime one-to-one and small-group call signaling.
create table if not exists public.calls (
  id uuid primary key default gen_random_uuid(),
  caller_id uuid not null references public.profiles(id) on delete cascade,
  callee_id uuid not null references public.profiles(id) on delete cascade,
  call_type text not null check (call_type in ('audio','video')),
  status text not null default 'ringing' check (status in ('ringing','accepted','rejected','ended','missed')),
  offer jsonb,
  answer jsonb,
  created_at timestamptz not null default now(),
  accepted_at timestamptz,
  ended_at timestamptz,
  check (caller_id<>callee_id)
);
create table if not exists public.call_ice_candidates (
  id bigint generated by default as identity primary key,
  call_id uuid not null references public.calls(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  candidate jsonb not null,
  created_at timestamptz not null default now()
);
create table if not exists public.group_calls (
  id uuid primary key default gen_random_uuid(),
  creator_id uuid not null references public.profiles(id) on delete cascade,
  call_type text not null default 'video' check (call_type in ('audio','video')),
  status text not null default 'ringing' check (status in ('ringing','active','ended')),
  created_at timestamptz not null default now(),
  ended_at timestamptz
);
create table if not exists public.group_call_members (
  room_id uuid not null references public.group_calls(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'invited' check (status in ('invited','joined','left','rejected')),
  joined_at timestamptz,
  primary key(room_id,user_id)
);
create table if not exists public.group_call_signals (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.group_calls(id) on delete cascade,
  from_user uuid not null references public.profiles(id) on delete cascade,
  to_user uuid not null references public.profiles(id) on delete cascade,
  kind text not null check (kind in ('offer','answer','ice')),
  payload jsonb not null,
  created_at timestamptz not null default now()
);
alter table public.calls enable row level security;
alter table public.call_ice_candidates enable row level security;
alter table public.group_calls enable row level security;
alter table public.group_call_members enable row level security;
alter table public.group_call_signals enable row level security;
create policy "call participants read" on public.calls for select to authenticated using (auth.uid()=caller_id or auth.uid()=callee_id);
create policy "caller creates call" on public.calls for insert to authenticated with check (auth.uid()=caller_id);
create policy "participants update call" on public.calls for update to authenticated using (auth.uid()=caller_id or auth.uid()=callee_id) with check (auth.uid()=caller_id or auth.uid()=callee_id);
create policy "participants delete call" on public.calls for delete to authenticated using (auth.uid()=caller_id or auth.uid()=callee_id);
create policy "call candidates read" on public.call_ice_candidates for select to authenticated using (exists(select 1 from public.calls c where c.id=call_id and (c.caller_id=auth.uid() or c.callee_id=auth.uid())));
create policy "call candidates insert" on public.call_ice_candidates for insert to authenticated with check (auth.uid()=user_id and exists(select 1 from public.calls c where c.id=call_id and (c.caller_id=auth.uid() or c.callee_id=auth.uid())));
create policy "call candidates delete" on public.call_ice_candidates for delete to authenticated using (auth.uid()=user_id);
create policy "group calls creator insert" on public.group_calls for insert to authenticated with check (creator_id=auth.uid());
create policy "group calls creator update" on public.group_calls for update to authenticated using (creator_id=auth.uid()) with check (creator_id=auth.uid());
create policy "group calls member read" on public.group_calls for select to authenticated using (creator_id=auth.uid() or exists(select 1 from public.group_call_members m where m.room_id=id and m.user_id=auth.uid()));
create policy "group members creator insert" on public.group_call_members for insert to authenticated with check (exists(select 1 from public.group_calls g where g.id=room_id and g.creator_id=auth.uid()) or user_id=auth.uid());
create policy "group members member read" on public.group_call_members for select to authenticated using (exists(select 1 from public.group_call_members me where me.room_id=room_id and me.user_id=auth.uid()));
create policy "group members self update" on public.group_call_members for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "group signals member insert" on public.group_call_signals for insert to authenticated with check (from_user=auth.uid() and exists(select 1 from public.group_call_members m where m.room_id=room_id and m.user_id=auth.uid()));
create policy "group signals member read" on public.group_call_signals for select to authenticated using (to_user=auth.uid() and exists(select 1 from public.group_call_members m where m.room_id=room_id and m.user_id=auth.uid()));
revoke all on public.calls,public.call_ice_candidates,public.group_calls,public.group_call_members,public.group_call_signals from anon;
grant select,insert,update,delete on public.calls to authenticated;
grant select,insert,delete on public.call_ice_candidates to authenticated;
grant select,insert,update on public.group_calls,public.group_call_members to authenticated;
grant select,insert on public.group_call_signals to authenticated;

-- Vibes 1.16: indexes for profile search, social relationships, calls and feed joins.
create index if not exists blocks_blocked_id_idx on public.blocks(blocked_id);
create index if not exists call_ice_candidates_user_id_idx on public.call_ice_candidates(user_id);
create index if not exists comments_parent_comment_id_idx on public.comments(parent_comment_id);
create index if not exists comments_post_id_idx on public.comments(post_id);
create index if not exists comments_user_id_idx on public.comments(user_id);
create index if not exists conversation_members_user_id_idx on public.conversation_members(user_id);
create index if not exists group_call_members_user_id_idx on public.group_call_members(user_id);
create index if not exists group_call_signals_from_user_idx on public.group_call_signals(from_user);
create index if not exists group_call_signals_room_id_idx on public.group_call_signals(room_id);
create index if not exists group_call_signals_to_user_idx on public.group_call_signals(to_user);
create index if not exists group_calls_creator_id_idx on public.group_calls(creator_id);
create index if not exists likes_user_id_idx on public.likes(user_id);
create index if not exists messages_conversation_id_idx on public.messages(conversation_id);
create index if not exists messages_sender_id_idx on public.messages(sender_id);
create index if not exists notifications_actor_id_idx on public.notifications(actor_id);
create index if not exists notifications_post_id_idx on public.notifications(post_id);
create index if not exists notifications_user_id_idx on public.notifications(user_id);
create index if not exists posts_user_id_idx on public.posts(user_id);
create index if not exists reports_post_id_idx on public.reports(post_id);
create index if not exists reports_reporter_id_idx on public.reports(reporter_id);

-- Vibes 1.17: secure direct conversations, realtime messages, and text-only imports.
alter table public.conversations
  add column if not exists created_by uuid references public.profiles(id) on delete set null,
  add column if not exists direct_key text;
create unique index if not exists conversations_direct_key_idx
  on public.conversations(direct_key) where direct_key is not null;

alter table public.external_posts drop constraint if exists external_posts_media_type_check;
alter table public.external_posts add constraint external_posts_media_type_check
  check (media_type in ('text','image','video','carousel','link'));
alter table public.external_posts add column if not exists source_id text not null default '';
create index if not exists external_posts_source_idx on public.external_posts(platform,source_id,published_at desc);

alter table public.profiles
  add column if not exists cover_url text,
  add column if not exists nickname text check (char_length(nickname) <= 50),
  add column if not exists current_city text check (char_length(current_city) <= 100),
  add column if not exists hometown text check (char_length(hometown) <= 100),
  add column if not exists work text check (char_length(work) <= 120),
  add column if not exists education text check (char_length(education) <= 120),
  add column if not exists relationship_status text check (relationship_status in ('','single','in_a_relationship','engaged','married','complicated','prefer_not_to_say')),
  add column if not exists website text check (char_length(website) <= 300);

create schema if not exists private;
create or replace function private.is_conversation_member(target_conversation uuid, candidate_user uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.conversation_members cm where cm.conversation_id=target_conversation and cm.user_id=candidate_user);
$$;
revoke all on function private.is_conversation_member(uuid,uuid) from public;
grant usage on schema private to authenticated;
grant execute on function private.is_conversation_member(uuid,uuid) to authenticated;

create or replace function private.can_send_conversation_message(target_conversation uuid, candidate_user uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select private.is_conversation_member(target_conversation,candidate_user)
    and not exists(
      select 1 from public.conversation_members other_member
      join public.blocks b on (b.blocker_id=candidate_user and b.blocked_id=other_member.user_id)
        or (b.blocked_id=candidate_user and b.blocker_id=other_member.user_id)
      where other_member.conversation_id=target_conversation and other_member.user_id<>candidate_user
    );
$$;
revoke all on function private.can_send_conversation_message(uuid,uuid) from public;
grant execute on function private.can_send_conversation_message(uuid,uuid) to authenticated;

create or replace function public.start_direct_conversation(other_user uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare requester uuid := (select auth.uid()); recipient_policy text; conversation_key text; result_id uuid;
begin
  if requester is null then raise exception 'authentication_required' using errcode='42501'; end if;
  if other_user is null or other_user=requester then raise exception 'invalid_recipient' using errcode='22023'; end if;
  select p.allow_messages into recipient_policy from public.profiles p where p.id=other_user;
  if recipient_policy is null then raise exception 'recipient_not_found' using errcode='22023'; end if;
  if exists(select 1 from public.blocks b where (b.blocker_id=requester and b.blocked_id=other_user) or (b.blocker_id=other_user and b.blocked_id=requester))
    then raise exception 'messaging_not_allowed' using errcode='42501'; end if;
  if recipient_policy='none' then raise exception 'messaging_not_allowed' using errcode='42501'; end if;
  if recipient_policy='following' and not exists(select 1 from public.follows f where f.follower_id=other_user and f.following_id=requester)
    then raise exception 'messaging_not_allowed' using errcode='42501'; end if;
  conversation_key := least(requester::text,other_user::text)||':'||greatest(requester::text,other_user::text);
  insert into public.conversations(created_by,direct_key) values(requester,conversation_key)
    on conflict (direct_key) where direct_key is not null do update set direct_key=excluded.direct_key returning id into result_id;
  insert into public.conversation_members(conversation_id,user_id) values(result_id,requester),(result_id,other_user) on conflict do nothing;
  return result_id;
end;$$;
revoke all on function public.start_direct_conversation(uuid) from public;
grant execute on function public.start_direct_conversation(uuid) to authenticated;

drop policy if exists "conversation member read" on public.conversations;
drop policy if exists "member rows read" on public.conversation_members;
drop policy if exists "message member read" on public.messages;
drop policy if exists "message member insert" on public.messages;
drop policy if exists "message sender delete" on public.messages;
create policy "conversation member read" on public.conversations for select to authenticated using ((select private.is_conversation_member(id,(select auth.uid()))));
create policy "member rows read" on public.conversation_members for select to authenticated using ((select private.is_conversation_member(conversation_id,(select auth.uid()))));
create policy "message member read" on public.messages for select to authenticated using ((select private.is_conversation_member(conversation_id,(select auth.uid()))));
create policy "message member insert" on public.messages for insert to authenticated with check ((select auth.uid())=sender_id and (select private.can_send_conversation_message(conversation_id,(select auth.uid()))));
create policy "message sender delete" on public.messages for delete to authenticated using ((select auth.uid())=sender_id);
revoke insert,update,delete on public.conversations,public.conversation_members from authenticated;
grant select on public.conversations,public.conversation_members to authenticated;
grant select,insert,delete on public.messages to authenticated;

create or replace function public.notify_new_message()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.notifications(user_id,actor_id,type,body)
  select cm.user_id,new.sender_id,'message',left(new.body,160)
  from public.conversation_members cm
  where cm.conversation_id=new.conversation_id and cm.user_id<>new.sender_id;
  return new;
end;$$;
revoke all on function public.notify_new_message() from public;
drop trigger if exists on_message_created_notify on public.messages;
create trigger on_message_created_notify after insert on public.messages for each row execute function public.notify_new_message();

create table if not exists public.feature_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 3 and 100),
  description text not null default '' check (char_length(description) <= 1000),
  status text not null default 'submitted' check (status in ('submitted','reviewing','planned','building','released','declined')),
  created_at timestamptz not null default now()
);
create table if not exists public.feature_request_votes (
  request_id uuid not null references public.feature_requests(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(request_id,user_id)
);
create index if not exists feature_requests_status_created_idx on public.feature_requests(status,created_at desc);
create index if not exists feature_request_votes_user_idx on public.feature_request_votes(user_id);
alter table public.feature_requests enable row level security;
alter table public.feature_request_votes enable row level security;
create policy "feature requests read" on public.feature_requests for select to authenticated using (true);
create policy "feature requests create" on public.feature_requests for insert to authenticated with check ((select auth.uid())=user_id and status='submitted');
create policy "feature requests owner delete" on public.feature_requests for delete to authenticated using ((select auth.uid())=user_id and status='submitted');
create policy "feature votes read" on public.feature_request_votes for select to authenticated using (true);
create policy "feature votes create" on public.feature_request_votes for insert to authenticated with check ((select auth.uid())=user_id);
create policy "feature votes owner delete" on public.feature_request_votes for delete to authenticated using ((select auth.uid())=user_id);
revoke all on public.feature_requests,public.feature_request_votes from anon;
grant select,insert,delete on public.feature_requests,public.feature_request_votes to authenticated;

do $$ begin
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
     and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='messages')
  then alter publication supabase_realtime add table public.messages; end if;
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
     and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='external_posts')
  then alter publication supabase_realtime add table public.external_posts; end if;
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
     and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='feature_requests')
  then alter publication supabase_realtime add table public.feature_requests; end if;
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
     and not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='feature_request_votes')
  then alter publication supabase_realtime add table public.feature_request_votes; end if;
end $$;
