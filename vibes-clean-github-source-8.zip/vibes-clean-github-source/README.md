# Vibes Android

Native Android WebView wrapper for the Vibes social app.

## Package
- Application ID: `com.vibes.social`
- Version: `1.1.0` (`versionCode 2`)
- minSdk: 26
- targetSdk / compileSdk: 36
- Java: 17
- Android Gradle Plugin: 9.3.1

## IMPORTANT before public launch
1. Supabase is connected in `app/src/main/assets/config.js` using a browser-safe publishable key.
2. The Vibes social schema + RLS policies have been applied to the connected Supabase project.
3. Keep the Supabase `service_role` key out of the app.
4. Add a real privacy policy, terms, account deletion flow, moderation/admin tools, abuse response, and Play Console Data safety answers.
5. Change `versionCode` for every Play Store update.

## Build in Android Studio
Open this folder in a current Android Studio with Android SDK 36 installed, then:
- Debug APK: Build > Build APK(s)
- Play Store AAB: Build > Generate Signed Bundle / APK > Android App Bundle

A release uploaded to Google Play must be signed. Prefer Play App Signing and keep your upload key private.

## Automated build
`.github/workflows/android.yml` builds a debug APK and an unsigned release AAB on GitHub Actions after a push.


## Audio / Video Calls (v1.2)
Vibes now includes one-to-one WebRTC audio/video calling with Supabase signaling tables (`calls`, `call_ice_candidates`) and Android camera/microphone permission handling. The included Google STUN server is enough for development and many networks. For reliable production calling across carrier-grade NAT/firewalls, configure a TURN service in `app/src/main/assets/config.js` under `turnServers`. Incoming calls currently appear while the app session is active; background/killed-app ringing should be completed with Android push notifications/foreground call service before production launch.

## V6 call upgrades
- 1-to-1 video call: front/back camera switch.
- Universal lighting filters plus background blur and virtual background.
- User can choose a custom virtual-background image.
- Small mesh group video calling (up to 4 participants total) with mute/camera/leave controls.
- Group-call signaling uses Supabase Realtime tables: `group_calls`, `group_call_members`, `group_call_signals`.

Background segmentation uses MediaPipe Selfie Segmentation loaded from jsDelivr. For a Play Store production release, vendor/bundle the dependency locally and add a TURN service for reliable mobile-network calls.


## v7 production-call hardening
Added Android native incoming-call notifications (while the app process is alive), notification permission, Supabase push-token schema, TURN-ready configuration, and production setup notes. Killed-app ringing still requires FCM credentials, and production TURN requires a relay-provider account; these secrets cannot be safely invented or embedded.

## v8 release preparation
FCM client support is now wired in with `VibesFirebaseMessagingService`, native push-token registration to Supabase, and a notification deep-link payload bridge. Firebase BoM 34.18.0 and Google Services Gradle plugin 4.5.0 are configured; the Google Services plugin is applied only when `app/google-services.json` exists. Camera/microphone permissions are now requested when WebRTC needs them instead of at app startup. See `FIREBASE_SETUP.md`, `TURN_SETUP.md`, and `PLAY_STORE_RELEASE.md`.

## v1.5.0 production-call automation
The app now calls the deployed Supabase `send-call-push` function when a 1:1 or group call starts and requests short-lived TURN credentials from the deployed `turn-credentials` function before creating WebRTC peer connections. See `PRODUCTION_CALLS_STATUS.md` and `infra/coturn/`.


## Vibes v10 final release package

This package includes a newly generated Vibes Android upload keystore and local release signing configuration, so release APK/AAB files can be signed without inventing third-party credentials. Preserve `release/vibes-upload-key.jks` and `release/SIGNING_CREDENTIALS.txt` securely for future app updates.

Firebase Cloud Messaging still requires a real Google-issued `app/google-services.json`; no fake Firebase identity is included. TURN server configuration includes a newly generated shared secret, but a public server/IP or DNS must still host coturn before relay calling can work.
