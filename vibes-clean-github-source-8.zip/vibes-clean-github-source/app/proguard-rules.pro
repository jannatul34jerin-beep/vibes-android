# Vibes currently has no custom shrinking rules.
