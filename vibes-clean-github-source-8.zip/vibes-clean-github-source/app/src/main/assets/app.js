const cfg=window.VIBES_CONFIG||{};
const cloudReady=!!(window.supabase&&cfg.supabaseUrl&&cfg.supabaseAnonKey&&!cfg.supabaseUrl.startsWith('YOUR_')&&!cfg.supabaseAnonKey.startsWith('YOUR_'));
const sb=cloudReady?window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseAnonKey):null;
const demoKey='vibes_demo_v3';
const seed={user:null,posts:[
{id:1,user:'Nadia',handle:'@nadia',text:'Vibes-এ সবাইকে স্বাগতম ✨',time:'এখনই',likes:12,liked:false,comments:['দারুণ শুরু!'],image:null},
{id:2,user:'Rahim',handle:'@rahim',text:'আজকের দিনটা সুন্দর হোক 🌿',time:'১০ মিনিট আগে',likes:5,liked:false,comments:[],image:null}
],messages:[{me:false,text:'হাই! Vibes কেমন লাগছে?'},{me:true,text:'ভালো লাগছে 😊'}],blocked:[],reports:[]};
let local=JSON.parse(localStorage.getItem(demoKey)||'null')||seed;
let state={user:local.user,tab:'feed',authTab:'login',chatOpen:false,posts:local.posts||[],messages:local.messages||[],blocked:local.blocked||[],reports:local.reports||[],profile:null,upload:null,loading:false};
const esc=(s='')=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const handleOf=n=>'@'+String(n||'user').toLowerCase().replace(/[^a-z0-9\u0980-\u09ff]+/g,'').slice(0,20);
function persist(){if(!cloudReady){local={user:state.user,posts:state.posts,messages:state.messages,blocked:state.blocked,reports:state.reports};localStorage.setItem(demoKey,JSON.stringify(local));}}
function toast(msg){let t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);setTimeout(()=>t.remove(),2200)}
function app(){document.getElementById('app').innerHTML=state.user?mainUI():authUI();bind();}
function authUI(){return `<div class="auth"><div class="logo">Vibes ✨</div><div class="card"><div class="tabs"><button id="loginTab" class="${state.authTab==='login'?'active':''}">লগইন</button><button id="signupTab" class="${state.authTab==='signup'?'active':''}">নতুন অ্যাকাউন্ট</button></div>${!cloudReady?`<div class="notice warn"><b>Demo mode:</b> এখন এই ডিভাইসেই ডেটা সেভ হবে। Supabase config দিলে একই কোড real account/database ব্যবহার করবে।</div>`:''}${state.authTab==='signup'?`<input id="name" placeholder="আপনার নাম" maxlength="50">`:''}<input id="email" type="email" placeholder="ইমেইল"><input id="password" type="password" placeholder="পাসওয়ার্ড (কমপক্ষে 6 অক্ষর)" minlength="6"><button id="authGo" class="btn" style="width:100%;margin-top:8px">${state.authTab==='login'?'লগইন করুন':'অ্যাকাউন্ট তৈরি করুন'}</button><p class="muted" style="line-height:1.55">অ্যাকাউন্ট তৈরি করলে আপনি Vibes-এর কমিউনিটি নিয়ম মেনে চলতে সম্মত হচ্ছেন।</p></div></div>`}
function mainUI(){return `<div class="app"><header class="top"><div class="brand">Vibes</div><div class="grow"></div><span class="badge">${cloudReady?'Cloud':'Demo'}</span><button class="pill" id="logout">লগআউট</button></header><main class="content">${view()}</main>${nav()}</div>`}
function nav(){const items=[['feed','🏠','হোম'],['search','🔎','খুঁজুন'],['create','➕','পোস্ট'],['chat','💬','চ্যাট'],['profile','👤','প্রোফাইল']];return `<nav class="nav">${items.map(x=>`<button data-tab="${x[0]}" class="${state.tab===x[0]?'active':''}"><span class="ico">${x[1]}</span>${x[2]}</button>`).join('')}</nav>`}
function view(){if(state.loading)return `<div class="empty">লোড হচ্ছে…</div>`;if(state.tab==='create')return createView();if(state.tab==='profile')return profileView();if(state.tab==='chat')return chatView();if(state.tab==='search')return searchView();return feedView();}
function feedView(){return `<div class="composer card"><textarea id="quickPost" placeholder="কী ভাবছেন?"></textarea><div class="composer-tools"><label class="pill">📷 ছবি<input id="quickImage" type="file" accept="image/*" hidden></label><div class="grow"></div><button class="btn" id="quickPostBtn">পোস্ট করুন</button></div><div id="quickPreview"></div></div>${state.posts.length?state.posts.map(postCard).join(''):`<div class="empty">এখনও কোনো পোস্ট নেই। প্রথম পোস্টটি করুন ✨</div>`}`}
function postCard(p){const comments=p.comments||[];return `<article class="card" data-post="${esc(p.id)}"><div class="row"><div class="avatar">${esc((p.user||'U')[0])}</div><div class="grow"><div class="name">${esc(p.user||'Vibes user')}</div><div class="muted">${esc(p.handle||handleOf(p.user))} · ${esc(p.time||'')}</div></div><div class="menu"><button class="icon-btn" data-menu="${esc(p.id)}">⋯</button><div id="menu-${esc(p.id)}" class="menu-panel hidden"><button data-report="${esc(p.id)}">⚑ রিপোর্ট</button><button data-block="${esc(p.user_id||p.user)}">⛔ ব্লক</button></div></div></div><div class="post-text">${esc(p.text||'')}</div>${p.image?`<img class="post-img" src="${esc(p.image)}" alt="Post image">`:''}<div class="actions"><button class="action ${p.liked?'active':''}" data-like="${esc(p.id)}">♥ ${Number(p.likes||0)}</button><button class="action" data-comment="${esc(p.id)}">💬 ${comments.length}</button><button class="action" data-share="${esc(p.id)}">↗ শেয়ার</button></div>${comments.slice(-3).map(c=>`<div class="comment muted">💬 ${esc(typeof c==='string'?c:c.text)}</div>`).join('')}</article>`}
function createView(){return `<div class="title">নতুন পোস্ট</div><div class="card composer"><textarea id="newPost" placeholder="আপনার কথা লিখুন..." maxlength="3000"></textarea><label class="pill">📷 ছবি যোগ করুন<input id="newImage" type="file" accept="image/*" hidden></label><div id="newPreview"></div><div class="media-note">সর্বোচ্চ ${cfg.maxImageMB||5} MB ছবি।</div><button class="btn" id="postBtn" style="margin-top:10px">প্রকাশ করুন</button></div>`}
function searchView(){return `<div class="title">মানুষ ও পোস্ট খুঁজুন</div><div class="card"><input id="searchBox" placeholder="নাম বা লেখা লিখুন"></div><div id="searchResults"><div class="empty">সার্চ শুরু করুন</div></div>`}
function profileView(){const u=state.profile||state.user||{};const name=u.name||u.user_metadata?.name||u.email?.split('@')[0]||'Vibes User';const own=state.posts.filter(p=>p.user_id===u.id||p.user===name).length;return `<div class="card profile-head"><div class="avatar lg">${esc(name[0]||'V')}</div><div class="title" style="margin-bottom:4px">${esc(name)}</div><div class="muted">${esc(u.email||u.handle||handleOf(name))}</div><div class="stats"><div class="stat"><b>${own}</b><div class="muted">পোস্ট</div></div><div class="stat"><b>${u.followers_count||0}</b><div class="muted">ফলোয়ার</div></div><div class="stat"><b>${u.following_count||0}</b><div class="muted">ফলোয়িং</div></div></div><button class="btn light" id="editProfile">প্রোফাইল এডিট</button></div><div class="card"><div class="section-title">নিরাপত্তা ও কমিউনিটি</div><p class="muted">অপমান, হুমকি, স্প্যাম বা অনুপযুক্ত কনটেন্ট দেখলে Report ব্যবহার করুন। Block করলে ওই ব্যবহারকারীর পোস্ট আপনার ফিডে আর দেখানো হবে না।</p><button class="pill" id="showRules">কমিউনিটি নিয়ম</button></div>`}
function chatView(){if(state.chatOpen)return `<div class="row" style="margin-bottom:10px"><button class="pill" id="backChat">←</button><div><b>Nadia</b><div class="muted"><span class="status-dot"></span> অনলাইন</div></div></div><div class="card messages">${state.messages.map(m=>`<div class="bubble ${m.me?'me':''}">${esc(m.text)}</div>`).join('')}</div><div class="chatbar"><input id="msg" placeholder="মেসেজ লিখুন"><button class="btn" id="sendMsg">পাঠান</button></div>`;return `<div class="title">চ্যাট</div><div class="notice">Cloud mode চালু হলে real-time private messaging database policies দিয়ে সুরক্ষিত থাকবে।</div><div class="chat-list"><div class="card row" id="openChat"><div class="avatar">N</div><div><b>Nadia</b><div class="muted">হাই! Vibes কেমন লাগছে?</div></div></div></div>`}
function filePreview(input,target){const f=input.files?.[0];if(!f){state.upload=null;return}if(f.size>(cfg.maxImageMB||5)*1024*1024){input.value='';return toast(`ছবিটি ${cfg.maxImageMB||5} MB-এর বেশি`)}state.upload=f;const url=URL.createObjectURL(f);document.getElementById(target).innerHTML=`<div class="preview"><img src="${url}" alt="preview"></div>`}
async function cloudBootstrap(){if(!cloudReady)return;const {data:{session}}=await sb.auth.getSession();if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await loadCloudPosts();}sb.auth.onAuthStateChange(async(_,session)=>{if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await loadCloudPosts()}else state.user=null;app()});}
async function loadCloudPosts(){if(!cloudReady)return;state.loading=true;app();const {data,error}=await sb.from('posts').select('id,user_id,body,image_url,created_at,profiles(display_name,username),likes(count),comments(id,body)').order('created_at',{ascending:false}).limit(50);state.loading=false;if(error){toast('পোস্ট লোড করা যায়নি');console.error(error);return app()}state.posts=(data||[]).filter(p=>!state.blocked.includes(p.user_id)).map(p=>({id:p.id,user:p.profiles?.display_name||'Vibes user',handle:p.profiles?.username?('@'+p.profiles.username):'@user',text:p.body,image:p.image_url,time:new Date(p.created_at).toLocaleString('bn-BD'),likes:p.likes?.[0]?.count||0,comments:(p.comments||[]).map(c=>c.body),user_id:p.user_id,liked:false}));app();}
async function authAction(){const email=document.getElementById('email').value.trim();const password=document.getElementById('password').value;if(!email||password.length<6)return toast('সঠিক ইমেইল ও কমপক্ষে 6 অক্ষরের পাসওয়ার্ড দিন');if(!cloudReady){const name=(document.getElementById('name')?.value||email.split('@')[0]).trim();state.user={id:'demo-'+Date.now(),name,email};persist();return app()}if(state.authTab==='signup'){const name=document.getElementById('name').value.trim();if(!name)return toast('নাম লিখুন');const {data,error}=await sb.auth.signUp({email,password,options:{data:{name}}});if(error)return toast(error.message);if(data.user&&!data.session)toast('ইমেইল চেক করে অ্যাকাউন্ট নিশ্চিত করুন');else toast('অ্যাকাউন্ট তৈরি হয়েছে')}else{const {error}=await sb.auth.signInWithPassword({email,password});if(error)return toast(error.message)}}
async function uploadImage(file){if(!cloudReady||!file)return null;const ext=(file.name.split('.').pop()||'jpg').toLowerCase();const path=`${state.user.id}/${crypto.randomUUID()}.${ext}`;const {error}=await sb.storage.from('post-media').upload(path,file,{cacheControl:'3600',upsert:false,contentType:file.type});if(error)throw error;return sb.storage.from('post-media').getPublicUrl(path).data.publicUrl;}
async function addPost(txt){txt=txt.trim();if(!txt&&!state.upload)return;if(!cloudReady){let image=null;if(state.upload)image=await fileToDataUrl(state.upload);state.posts.unshift({id:Date.now(),user:state.user.name,handle:handleOf(state.user.name),text:txt,time:'এখনই',likes:0,liked:false,comments:[],image,user_id:state.user.id});state.upload=null;persist();state.tab='feed';return app()}try{let image_url=await uploadImage(state.upload);const {error}=await sb.from('posts').insert({user_id:state.user.id,body:txt,image_url});if(error)throw error;state.upload=null;state.tab='feed';await loadCloudPosts()}catch(e){console.error(e);toast('পোস্ট করা যায়নি')}}
function fileToDataUrl(f){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(f)})}
async function likePost(id){const p=state.posts.find(x=>String(x.id)===String(id));if(!p)return;if(!cloudReady){p.liked=!p.liked;p.likes+=p.liked?1:-1;persist();return app()}if(p.liked){await sb.from('likes').delete().eq('post_id',id).eq('user_id',state.user.id);p.liked=false;p.likes=Math.max(0,p.likes-1)}else{const {error}=await sb.from('likes').insert({post_id:id,user_id:state.user.id});if(!error){p.liked=true;p.likes++}}app()}
async function commentPost(id){const c=prompt('কমেন্ট লিখুন');if(!c?.trim())return;if(!cloudReady){state.posts.find(x=>String(x.id)===String(id)).comments.push(c.trim());persist();return app()}const {error}=await sb.from('comments').insert({post_id:id,user_id:state.user.id,body:c.trim()});if(error)return toast('কমেন্ট করা যায়নি');await loadCloudPosts()}
async function reportPost(id){const reason=prompt('রিপোর্টের কারণ সংক্ষেপে লিখুন');if(!reason?.trim())return;if(!cloudReady){state.reports.push({id,reason:reason.trim(),at:Date.now()});persist();return toast('রিপোর্ট গ্রহণ করা হয়েছে')}const {error}=await sb.from('reports').insert({reporter_id:state.user.id,post_id:id,reason:reason.trim()});toast(error?'রিপোর্ট পাঠানো যায়নি':'রিপোর্ট গ্রহণ করা হয়েছে')}
async function blockUser(userId){if(!confirm('এই ব্যবহারকারীকে ব্লক করবেন?'))return;if(!cloudReady){state.blocked.push(userId);state.posts=state.posts.filter(p=>String(p.user_id||p.user)!==String(userId));persist();return app()}const {error}=await sb.from('blocks').insert({blocker_id:state.user.id,blocked_id:userId});if(error)return toast('ব্লক করা যায়নি');state.blocked.push(userId);await loadCloudPosts()}
function baseBind(){document.getElementById('loginTab')?.addEventListener('click',()=>{state.authTab='login';app()});document.getElementById('signupTab')?.addEventListener('click',()=>{state.authTab='signup';app()});document.getElementById('authGo')?.addEventListener('click',authAction);document.getElementById('logout')?.addEventListener('click',async()=>{if(cloudReady)await sb.auth.signOut();else{state.user=null;persist();app()}});document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{state.tab=b.dataset.tab;state.chatOpen=false;app()});
 document.getElementById('quickImage')?.addEventListener('change',e=>filePreview(e.target,'quickPreview'));document.getElementById('newImage')?.addEventListener('change',e=>filePreview(e.target,'newPreview'));document.getElementById('quickPostBtn')?.addEventListener('click',()=>addPost(document.getElementById('quickPost').value));document.getElementById('postBtn')?.addEventListener('click',()=>addPost(document.getElementById('newPost').value));document.querySelectorAll('[data-like]').forEach(b=>b.onclick=()=>likePost(b.dataset.like));document.querySelectorAll('[data-comment]').forEach(b=>b.onclick=()=>commentPost(b.dataset.comment));document.querySelectorAll('[data-share]').forEach(b=>b.onclick=async()=>{let p=state.posts.find(x=>String(x.id)===String(b.dataset.share));try{if(navigator.share)await navigator.share({title:'Vibes',text:p.text});else{await navigator.clipboard.writeText(p.text);toast('পোস্ট কপি হয়েছে')}}catch{}});document.querySelectorAll('[data-menu]').forEach(b=>b.onclick=()=>document.getElementById('menu-'+b.dataset.menu)?.classList.toggle('hidden'));document.querySelectorAll('[data-report]').forEach(b=>b.onclick=()=>reportPost(b.dataset.report));document.querySelectorAll('[data-block]').forEach(b=>b.onclick=()=>blockUser(b.dataset.block));document.getElementById('searchBox')?.addEventListener('input',e=>{let q=e.target.value.toLowerCase().trim();let rs=state.posts.filter(p=>(p.user+' '+p.text+' '+p.handle).toLowerCase().includes(q));document.getElementById('searchResults').innerHTML=q?(rs.length?rs.map(postCard).join(''):`<div class="empty">কিছু পাওয়া যায়নি</div>`):`<div class="empty">সার্চ শুরু করুন</div>`;bind()});document.getElementById('openChat')?.addEventListener('click',()=>{state.chatOpen=true;app()});document.getElementById('backChat')?.addEventListener('click',()=>{state.chatOpen=false;app()});document.getElementById('sendMsg')?.addEventListener('click',()=>{let i=document.getElementById('msg');if(i.value.trim()){state.messages.push({me:true,text:i.value.trim()});persist();app()}});document.getElementById('editProfile')?.addEventListener('click',async()=>{const name=prompt('নতুন নাম',state.user.name||'');if(!name?.trim())return;if(!cloudReady){state.user.name=name.trim();persist();return app()}const username=handleOf(name).slice(1);const {error}=await sb.from('profiles').upsert({id:state.user.id,display_name:name.trim(),username});if(error)return toast('প্রোফাইল আপডেট করা যায়নি');state.user.name=name.trim();app()});document.getElementById('showRules')?.addEventListener('click',()=>alert('Vibes নিয়ম: সম্মানজনক আচরণ করুন; স্প্যাম, হুমকি, হয়রানি, ঘৃণামূলক বা অবৈধ কনটেন্ট পোস্ট করবেন না; কারও ব্যক্তিগত তথ্য অনুমতি ছাড়া প্রকাশ করবেন না।'))}
(async()=>{if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});await cloudBootstrap();app()})();


// ---- Vibes Calls v1: WebRTC audio/video + Supabase signaling ----
state.people=[];
state.call={incoming:null,active:null,pc:null,localStream:null,rawLocalStream:null,remoteStream:null,muted:false,cameraOff:false,remoteDescriptionSet:false,filter:'natural',filterCleanup:null};
state.turn={servers:[],expiresAt:0,loading:null};
let callsChannel=null, iceChannel=null;

function callIceServers(){
  const stun=(cfg.iceServers&&cfg.iceServers.length)?cfg.iceServers:[{urls:'stun:stun.l.google.com:19302'}];
  return [...stun,...(cfg.turnServers||[]),...(state.turn.servers||[])];
}
async function ensureTurnCredentials(){
  if(!cloudReady||!state.user)return;
  const now=Math.floor(Date.now()/1000);
  if(state.turn.servers.length&&state.turn.expiresAt>now+120)return;
  if(state.turn.loading)return state.turn.loading;
  state.turn.loading=(async()=>{
    try{
      const {data,error}=await sb.functions.invoke('turn-credentials',{body:{}});
      if(error||!data?.iceServers)return;
      state.turn.servers=data.iceServers;state.turn.expiresAt=Number(data.expires_at||0);
    }catch(e){console.warn('TURN unavailable; continuing with STUN',e)}
    finally{state.turn.loading=null}
  })();
  return state.turn.loading;
}
async function sendCallPush(payload){
  if(!cloudReady||!state.user)return;
  try{const {error}=await sb.functions.invoke('send-call-push',{body:payload});if(error)console.warn('Call push unavailable',error)}catch(e){console.warn('Call push failed',e)}
}

async function loadPeople(){
  if(!cloudReady||!state.user)return;
  const {data,error}=await sb.from('profiles').select('id,display_name,username,avatar_url').neq('id',state.user.id).order('created_at',{ascending:false}).limit(50);
  if(!error) state.people=data||[];
}
function callPersonName(id){const p=state.people.find(x=>x.id===id);return p?.display_name||'Vibes user'}

async function setupCallRealtime(){
  if(!cloudReady||!state.user)return;
  if(callsChannel) await sb.removeChannel(callsChannel);
  if(iceChannel) await sb.removeChannel(iceChannel);
  callsChannel=sb.channel('vibes-calls-'+state.user.id)
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'calls',filter:`callee_id=eq.${state.user.id}`},payload=>{
      if(payload.new.status==='ringing'){
        state.call.incoming=payload.new;
        toast(`${payload.new.call_type==='video'?'ভিডিও':'অডিও'} কল আসছে`);
        app();
      }
    })
    .on('postgres_changes',{event:'UPDATE',schema:'public',table:'calls'},async payload=>{
      const c=payload.new;
      if(c.caller_id!==state.user.id&&c.callee_id!==state.user.id)return;
      if(state.call.active?.id===c.id){
        state.call.active=c;
        if(c.answer&&state.call.pc&&!state.call.remoteDescriptionSet&&c.caller_id===state.user.id){
          try{await state.call.pc.setRemoteDescription(new RTCSessionDescription(c.answer));state.call.remoteDescriptionSet=true;await loadExistingIce(c.id)}catch(e){console.error(e)}
        }
        if(['ended','rejected','missed'].includes(c.status)){closeCallMedia();state.call.active=null;state.call.incoming=null;toast(c.status==='rejected'?'কল রিজেক্ট হয়েছে':'কল শেষ হয়েছে');app()}
      } else if(state.call.incoming?.id===c.id && c.status!=='ringing'){
        state.call.incoming=null;app();
      }
    }).subscribe();
  iceChannel=sb.channel('vibes-ice-'+state.user.id)
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'call_ice_candidates'},async payload=>{
      const row=payload.new;
      if(!state.call.active||row.call_id!==state.call.active.id||row.user_id===state.user.id||!state.call.pc)return;
      try{await state.call.pc.addIceCandidate(new RTCIceCandidate(row.candidate))}catch(e){console.error(e)}
    }).subscribe();
}

const CALL_FILTERS={
  natural:'none',
  studio:'brightness(1.08) contrast(1.06) saturate(1.04)',
  soft:'brightness(1.06) contrast(0.96) saturate(1.03)',
  warm:'brightness(1.04) saturate(1.08) sepia(0.10)',
  cool:'brightness(1.03) saturate(1.04) hue-rotate(8deg)'
};
function callFilterLabel(k){return ({natural:'Natural',studio:'Studio Light',soft:'Soft Glow',warm:'Warm',cool:'Cool'})[k]||'Natural'}
async function makeFilteredCallStream(raw,type){
  if(type!=='video') return raw;
  const v=document.createElement('video');v.autoplay=true;v.muted=true;v.playsInline=true;v.srcObject=new MediaStream(raw.getVideoTracks());
  await v.play().catch(()=>{});
  const c=document.createElement('canvas');
  const ctx=c.getContext('2d',{alpha:false});
  let raf=0,stopped=false;
  const draw=()=>{
    if(stopped)return;
    const w=v.videoWidth||720,h=v.videoHeight||1280;
    if(c.width!==w||c.height!==h){c.width=w;c.height=h}
    ctx.filter=CALL_FILTERS[state.call.filter]||'none';
    ctx.drawImage(v,0,0,c.width,c.height);
    raf=requestAnimationFrame(draw);
  };draw();
  if(!c.captureStream) return raw;
  const processed=c.captureStream(24);
  raw.getAudioTracks().forEach(t=>processed.addTrack(t));
  state.call.filterCleanup=()=>{stopped=true;cancelAnimationFrame(raf);try{v.pause();v.srcObject=null}catch{}};
  return processed;
}
async function createPeer(callId,type){
  await ensureTurnCredentials();
  const raw=await navigator.mediaDevices.getUserMedia({audio:true,video:type==='video'});
  state.call.rawLocalStream=raw;
  const stream=await makeFilteredCallStream(raw,type);
  const pc=new RTCPeerConnection({iceServers:callIceServers()});
  const remote=new MediaStream();
  stream.getTracks().forEach(t=>pc.addTrack(t,stream));
  pc.ontrack=e=>{e.streams[0].getTracks().forEach(t=>{if(!remote.getTracks().some(x=>x.id===t.id))remote.addTrack(t)});attachCallMedia()};
  pc.onicecandidate=async e=>{if(e.candidate&&cloudReady&&state.user){await sb.from('call_ice_candidates').insert({call_id:callId,user_id:state.user.id,candidate:e.candidate.toJSON()})}};
  pc.onconnectionstatechange=()=>{if(['failed','closed'].includes(pc.connectionState)&&state.call.active)toast('কল সংযোগ বিচ্ছিন্ন হয়েছে')};
  state.call.pc=pc;state.call.localStream=stream;state.call.remoteStream=remote;state.call.remoteDescriptionSet=false;
  return pc;
}
async function loadExistingIce(callId){
  if(!state.call.pc)return;
  const {data}=await sb.from('call_ice_candidates').select('id,user_id,candidate').eq('call_id',callId).neq('user_id',state.user.id).order('id');
  for(const row of data||[]){try{await state.call.pc.addIceCandidate(new RTCIceCandidate(row.candidate))}catch{}}
}
async function startCall(targetId,type='audio'){
  if(!cloudReady)return toast('Real call-এর জন্য Cloud mode দরকার');
  if(!navigator.mediaDevices?.getUserMedia)return toast('এই ডিভাইসে camera/microphone API পাওয়া যায়নি');
  try{
    const {data:call,error}=await sb.from('calls').insert({caller_id:state.user.id,callee_id:targetId,call_type:type,status:'ringing'}).select().single();
    if(error)throw error;
    state.call.active=call;state.call.incoming=null;app();
    const pc=await createPeer(call.id,type);
    const offer=await pc.createOffer();await pc.setLocalDescription(offer);
    const {error:upErr}=await sb.from('calls').update({offer:pc.localDescription.toJSON()}).eq('id',call.id);
    if(upErr)throw upErr;
    sendCallPush({call_id:call.id});
    await loadExistingIce(call.id);app();
  }catch(e){console.error(e);closeCallMedia();state.call.active=null;toast('কল শুরু করা যায়নি');app()}
}
async function acceptCall(){try{window.VibesNative?.clearIncomingCall()}catch{}
  const c=state.call.incoming;if(!c)return;
  try{
    state.call.active=c;state.call.incoming=null;app();
    const pc=await createPeer(c.id,c.call_type);
    if(!c.offer){const {data}=await sb.from('calls').select('*').eq('id',c.id).single();Object.assign(c,data||{})}
    await pc.setRemoteDescription(new RTCSessionDescription(c.offer));state.call.remoteDescriptionSet=true;
    const answer=await pc.createAnswer();await pc.setLocalDescription(answer);
    await sb.from('calls').update({answer:pc.localDescription.toJSON(),status:'accepted',accepted_at:new Date().toISOString()}).eq('id',c.id);
    await loadExistingIce(c.id);app();
  }catch(e){console.error(e);toast('কল গ্রহণ করা যায়নি');await endCall()}
}
async function rejectCall(){try{window.VibesNative?.clearIncomingCall()}catch{}const c=state.call.incoming;if(!c)return;await sb.from('calls').update({status:'rejected',ended_at:new Date().toISOString()}).eq('id',c.id);state.call.incoming=null;app()}
async function endCall(){try{window.VibesNative?.clearIncomingCall()}catch{}const c=state.call.active;if(c&&cloudReady)await sb.from('calls').update({status:'ended',ended_at:new Date().toISOString()}).eq('id',c.id);closeCallMedia();state.call.active=null;state.call.incoming=null;app()}
function closeCallMedia(){try{state.call.filterCleanup?.()}catch{}try{state.call.localStream?.getTracks().forEach(t=>t.stop())}catch{}try{state.call.rawLocalStream?.getTracks().forEach(t=>t.stop())}catch{}try{state.call.pc?.close()}catch{}state.call.pc=null;state.call.localStream=null;state.call.rawLocalStream=null;state.call.remoteStream=null;state.call.remoteDescriptionSet=false;state.call.muted=false;state.call.cameraOff=false;state.call.filter='natural';state.call.filterCleanup=null}
function toggleMute(){const tracks=state.call.localStream?.getAudioTracks()||[];state.call.muted=!state.call.muted;tracks.forEach(t=>t.enabled=!state.call.muted);app()}
function toggleCamera(){const tracks=state.call.rawLocalStream?.getVideoTracks()||state.call.localStream?.getVideoTracks()||[];state.call.cameraOff=!state.call.cameraOff;tracks.forEach(t=>t.enabled=!state.call.cameraOff);app()}
function setCallFilter(mode){if(!CALL_FILTERS[mode])return;state.call.filter=mode;app()}
function attachCallMedia(){const lv=document.getElementById('localVideo'),rv=document.getElementById('remoteVideo');if(lv&&state.call.localStream&&lv.srcObject!==state.call.localStream){lv.srcObject=state.call.localStream;lv.muted=true;lv.play().catch(()=>{})}if(rv&&state.call.remoteStream&&rv.srcObject!==state.call.remoteStream){rv.srcObject=state.call.remoteStream;rv.play().catch(()=>{})}}
function activeCallUI(){
  const c=state.call.active;if(!c)return '';
  const other=c.caller_id===state.user.id?c.callee_id:c.caller_id;const name=callPersonName(other);const video=c.call_type==='video';
  return `<div class="call-screen"><div class="call-title">${esc(name)}</div><div class="muted">${video?'ভিডিও কল':'অডিও কল'} · ${c.status==='ringing'?'কল হচ্ছে…':c.status==='accepted'?'সংযুক্ত':'সংযোগ হচ্ছে…'}</div>${video?`<div class="video-stage"><video id="remoteVideo" autoplay playsinline></video><video id="localVideo" autoplay muted playsinline></video></div><div class="call-filters">${Object.keys(CALL_FILTERS).map(k=>`<button class="filter-chip ${state.call.filter===k?'active':''}" data-call-filter="${k}">${callFilterLabel(k)}</button>`).join('')}</div>`:`<div class="call-avatar">${esc(name[0]||'V')}</div><audio id="remoteVideo" autoplay></audio>`}<div class="call-actions"><button class="call-round" id="muteCall">${state.call.muted?'🔇':'🎤'}</button>${video?`<button class="call-round" id="cameraCall">${state.call.cameraOff?'📷✕':'📹'}</button>`:''}<button class="call-round danger" id="endCall">📞</button></div></div>`
}
function incomingCallUI(){const c=state.call.incoming;if(!c)return '';const name=callPersonName(c.caller_id);return `<div class="incoming-call"><div class="call-avatar small">${esc(name[0]||'V')}</div><div class="grow"><b>${esc(name)}</b><div class="muted">${c.call_type==='video'?'ভিডিও':'অডিও'} কল আসছে…</div></div><button class="call-round accept" id="acceptCall">✓</button><button class="call-round danger" id="rejectCall">✕</button></div>`}
function chatView(){
  if(state.call.active)return activeCallUI();
  const incoming=incomingCallUI();
  if(state.chatOpen)return `${incoming}<div class="row" style="margin-bottom:10px"><button class="pill" id="backChat">←</button><div class="grow"><b>Nadia</b><div class="muted"><span class="status-dot"></span> চ্যাট</div></div></div><div class="card messages">${state.messages.map(m=>`<div class="bubble ${m.me?'me':''}">${esc(m.text)}</div>`).join('')}</div><div class="chatbar"><input id="msg" placeholder="মেসেজ লিখুন"><button class="btn" id="sendMsg">পাঠান</button></div>`;
  const people=state.people.length?state.people.map(p=>`<div class="card row person-row"><div class="avatar">${esc((p.display_name||'V')[0])}</div><div class="grow"><b>${esc(p.display_name||'Vibes user')}</b><div class="muted">${esc(p.username?'@'+p.username:'Vibes')}</div></div><button class="call-mini" data-audio-call="${p.id}" title="Audio call">📞</button><button class="call-mini" data-video-call="${p.id}" title="Video call">📹</button></div>`).join(''):`<div class="empty">আরও ব্যবহারকারী যোগ হলে এখানে Audio/Video call করা যাবে।</div>`;
  return `${incoming}<div class="title">চ্যাট ও কল</div><div class="notice">Vibes-to-Vibes encrypted WebRTC media connection ব্যবহার করে Audio/Video call করা হবে।</div><div class="chat-list">${people}</div>`
}

async function cloudBootstrap(){
  if(!cloudReady)return;
  const {data:{session}}=await sb.auth.getSession();
  if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople()]);await setupCallRealtime()}
  sb.auth.onAuthStateChange(async(_,session)=>{if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople()]);await setupCallRealtime()}else{closeCallMedia();state.user=null}app()});
}
function app(){document.getElementById('app').innerHTML=state.user?mainUI():authUI();bind();setTimeout(attachCallMedia,0)}
function bind(){
  baseBind();
  document.querySelectorAll('[data-audio-call]').forEach(b=>b.onclick=()=>startCall(b.dataset.audioCall,'audio'));
  document.querySelectorAll('[data-video-call]').forEach(b=>b.onclick=()=>startCall(b.dataset.videoCall,'video'));
  document.getElementById('acceptCall')?.addEventListener('click',acceptCall);
  document.getElementById('rejectCall')?.addEventListener('click',rejectCall);
  document.getElementById('endCall')?.addEventListener('click',endCall);
  document.getElementById('muteCall')?.addEventListener('click',toggleMute);
  document.getElementById('cameraCall')?.addEventListener('click',toggleCamera);
  document.querySelectorAll('[data-call-filter]').forEach(b=>b.onclick=()=>setCallFilter(b.dataset.callFilter));
}

// ---- Vibes Calls v2: background effects, camera switch, small group calls ----
state.call.facingMode=state.call.facingMode||'user';
state.call.bgEffect=state.call.bgEffect||'none';
state.call.virtualBg=state.call.virtualBg||null;
state.group={incoming:null,active:null,rawLocalStream:null,localStream:null,peers:{},remotes:{},muted:false,cameraOff:false,facingMode:'user',selected:[],channel:null};
let groupRealtimeChannel=null;

function drawVirtualBackground(ctx,w,h,img){
  if(img&&img.complete){ctx.drawImage(img,0,0,w,h);return}
  const g=ctx.createLinearGradient(0,0,w,h);g.addColorStop(0,'#32125f');g.addColorStop(.5,'#5d28d8');g.addColorStop(1,'#00a9d8');ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
}

async function makeFilteredCallStream(raw,type){
  if(type!=='video') return raw;
  const v=document.createElement('video');v.autoplay=true;v.muted=true;v.playsInline=true;v.srcObject=new MediaStream(raw.getVideoTracks());
  await v.play().catch(()=>{});
  const c=document.createElement('canvas');const ctx=c.getContext('2d',{alpha:false});
  let raf=0,stopped=false,busy=false,latest=null,bgImg=null;
  if(state.call.virtualBg){bgImg=new Image();bgImg.src=state.call.virtualBg}
  let segmenter=null;
  if(window.SelfieSegmentation){
    try{
      segmenter=new SelfieSegmentation({locateFile:f=>`https://cdn.jsdelivr.net/npm/@mediapipe/selfie_segmentation/${f}`});
      segmenter.setOptions({modelSelection:1});segmenter.onResults(r=>{latest=r});
    }catch(e){console.warn('Segmentation unavailable',e)}
  }
  const draw=()=>{
    if(stopped)return;
    const w=v.videoWidth||720,h=v.videoHeight||1280;if(c.width!==w||c.height!==h){c.width=w;c.height=h}
    ctx.save();ctx.clearRect(0,0,w,h);
    const effect=state.call.bgEffect;
    if(effect!=='none'&&latest?.segmentationMask){
      ctx.drawImage(latest.segmentationMask,0,0,w,h);
      ctx.globalCompositeOperation='source-in';ctx.filter=CALL_FILTERS[state.call.filter]||'none';ctx.drawImage(v,0,0,w,h);
      ctx.globalCompositeOperation='destination-over';
      if(effect==='blur'){ctx.filter='blur(18px)';ctx.drawImage(v,-18,-18,w+36,h+36)}
      else {ctx.filter='none';drawVirtualBackground(ctx,w,h,bgImg)}
      ctx.globalCompositeOperation='source-over';
    }else{
      ctx.filter=CALL_FILTERS[state.call.filter]||'none';ctx.drawImage(v,0,0,w,h);
    }
    ctx.restore();
    if(effect!=='none'&&segmenter&&!busy){busy=true;segmenter.send({image:v}).catch(()=>{}).finally(()=>busy=false)}
    raf=requestAnimationFrame(draw);
  };draw();
  if(!c.captureStream)return raw;
  const processed=c.captureStream(24);raw.getAudioTracks().forEach(t=>processed.addTrack(t));
  state.call.filterCleanup=()=>{stopped=true;cancelAnimationFrame(raf);try{segmenter?.close?.()}catch{}try{v.pause();v.srcObject=null}catch{}};
  return processed;
}

async function createPeer(callId,type){
  await ensureTurnCredentials();
  const raw=await navigator.mediaDevices.getUserMedia({audio:true,video:type==='video'?{facingMode:{ideal:state.call.facingMode}}:false});
  state.call.rawLocalStream=raw;const stream=await makeFilteredCallStream(raw,type);
  const pc=new RTCPeerConnection({iceServers:callIceServers()});const remote=new MediaStream();
  stream.getTracks().forEach(t=>pc.addTrack(t,stream));
  pc.ontrack=e=>{e.streams[0].getTracks().forEach(t=>{if(!remote.getTracks().some(x=>x.id===t.id))remote.addTrack(t)});attachCallMedia()};
  pc.onicecandidate=async e=>{if(e.candidate&&cloudReady&&state.user)await sb.from('call_ice_candidates').insert({call_id:callId,user_id:state.user.id,candidate:e.candidate.toJSON()})};
  pc.onconnectionstatechange=()=>{if(['failed','closed'].includes(pc.connectionState)&&state.call.active)toast('কল সংযোগ বিচ্ছিন্ন হয়েছে')};
  state.call.pc=pc;state.call.localStream=stream;state.call.remoteStream=remote;state.call.remoteDescriptionSet=false;return pc;
}

async function rebuildProcessedVideo(){
  if(!state.call.active||state.call.active.call_type!=='video'||!state.call.rawLocalStream)return;
  try{
    state.call.filterCleanup?.();const stream=await makeFilteredCallStream(state.call.rawLocalStream,'video');
    const newTrack=stream.getVideoTracks()[0];const sender=state.call.pc?.getSenders().find(s=>s.track?.kind==='video');if(sender&&newTrack)await sender.replaceTrack(newTrack);
    const oldProcessed=state.call.localStream;state.call.localStream=stream;oldProcessed?.getVideoTracks().forEach(t=>{if(t.id!==newTrack?.id)t.stop()});app();
  }catch(e){console.error(e);toast('ভিডিও effect বদলানো যায়নি')}
}
function setCallFilter(mode){if(!CALL_FILTERS[mode])return;state.call.filter=mode;rebuildProcessedVideo()}
function setCallBackground(mode){if(!['none','blur','virtual'].includes(mode))return;state.call.bgEffect=mode;rebuildProcessedVideo()}
async function pickVirtualBackground(file){if(!file)return;if(!file.type.startsWith('image/'))return toast('ছবি নির্বাচন করুন');const r=new FileReader();r.onload=()=>{state.call.virtualBg=r.result;state.call.bgEffect='virtual';rebuildProcessedVideo()};r.readAsDataURL(file)}
async function switchCamera(){
  if(!state.call.active||state.call.active.call_type!=='video')return;
  try{
    const next=state.call.facingMode==='user'?'environment':'user';const media=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:next}},audio:false});const newTrack=media.getVideoTracks()[0];
    const old=state.call.rawLocalStream.getVideoTracks();old.forEach(t=>{state.call.rawLocalStream.removeTrack(t);t.stop()});state.call.rawLocalStream.addTrack(newTrack);state.call.facingMode=next;await rebuildProcessedVideo();toast(next==='user'?'ফ্রন্ট ক্যামেরা':'ব্যাক ক্যামেরা');
  }catch(e){console.error(e);toast('ক্যামেরা বদলানো যায়নি')}
}

function activeCallUI(){
  const c=state.call.active;if(!c)return '';const other=c.caller_id===state.user.id?c.callee_id:c.caller_id;const name=callPersonName(other),video=c.call_type==='video';
  const filters=Object.keys(CALL_FILTERS).map(k=>`<button class="filter-chip ${state.call.filter===k?'active':''}" data-call-filter="${k}">${callFilterLabel(k)}</button>`).join('');
  const bg=`<div class="call-filters"><button class="filter-chip ${state.call.bgEffect==='none'?'active':''}" data-call-bg="none">No BG</button><button class="filter-chip ${state.call.bgEffect==='blur'?'active':''}" data-call-bg="blur">Blur</button><button class="filter-chip ${state.call.bgEffect==='virtual'?'active':''}" data-call-bg="virtual">Virtual</button><label class="filter-chip">নিজের ছবি<input id="virtualBgFile" type="file" accept="image/*" hidden></label></div>`;
  return `<div class="call-screen"><div class="call-title">${esc(name)}</div><div class="muted">${video?'ভিডিও কল':'অডিও কল'} · ${c.status==='ringing'?'কল হচ্ছে…':c.status==='accepted'?'সংযুক্ত':'সংযোগ হচ্ছে…'}</div>${video?`<div class="video-stage"><video id="remoteVideo" autoplay playsinline></video><video id="localVideo" autoplay muted playsinline></video></div><div class="call-filters">${filters}</div>${bg}`:`<div class="call-avatar">${esc(name[0]||'V')}</div><audio id="remoteVideo" autoplay></audio>`}<div class="call-actions"><button class="call-round" id="muteCall">${state.call.muted?'🔇':'🎤'}</button>${video?`<button class="call-round" id="cameraCall">${state.call.cameraOff?'📷✕':'📹'}</button><button class="call-round" id="switchCamera" title="Switch camera">🔄</button>`:''}<button class="call-round danger" id="endCall">📞</button></div></div>`;
}

async function setupGroupRealtime(){
  if(!cloudReady||!state.user)return;if(groupRealtimeChannel)await sb.removeChannel(groupRealtimeChannel);
  groupRealtimeChannel=sb.channel('vibes-group-'+state.user.id)
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'group_call_members',filter:`user_id=eq.${state.user.id}`},async p=>{if(p.new.status==='invited'){const {data}=await sb.from('group_calls').select('*').eq('id',p.new.room_id).single();if(data&&data.creator_id!==state.user.id){state.group.incoming=data;toast('Group video call আসছে');try{window.VibesNative?.showIncomingCall(callPersonName(data.creator_id),'video',data.id)}catch{}app()}}})
    .on('postgres_changes',{event:'UPDATE',schema:'public',table:'group_call_members'},async p=>{if(state.group.active&&p.new.room_id===state.group.active.id&&p.new.status==='joined'&&p.new.user_id!==state.user.id){if(state.user.id<p.new.user_id)await ensureGroupPeer(p.new.user_id,true);app()}})
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'group_call_signals',filter:`to_user=eq.${state.user.id}`},p=>handleGroupSignal(p.new))
    .on('postgres_changes',{event:'UPDATE',schema:'public',table:'group_calls'},p=>{if(state.group.active?.id===p.new.id&&p.new.status==='ended'){leaveGroupCall(false);toast('Group call শেষ হয়েছে')}}).subscribe();
}
async function groupLocalMedia(type='video'){
  const raw=await navigator.mediaDevices.getUserMedia({audio:true,video:type==='video'?{facingMode:{ideal:state.group.facingMode}}:false});state.group.rawLocalStream=raw;state.group.localStream=raw;return raw;
}
async function sendGroupSignal(roomId,to,kind,payload){await sb.from('group_call_signals').insert({room_id:roomId,from_user:state.user.id,to_user:to,kind,payload})}
async function ensureGroupPeer(peerId,initiate=false){
  if(state.group.peers[peerId])return state.group.peers[peerId];const pc=new RTCPeerConnection({iceServers:callIceServers()});state.group.peers[peerId]=pc;const remote=new MediaStream();state.group.remotes[peerId]=remote;
  state.group.localStream?.getTracks().forEach(t=>pc.addTrack(t,state.group.localStream));pc.ontrack=e=>{e.streams[0].getTracks().forEach(t=>{if(!remote.getTracks().some(x=>x.id===t.id))remote.addTrack(t)});attachGroupMedia()};
  pc.onicecandidate=e=>{if(e.candidate)sendGroupSignal(state.group.active.id,peerId,'ice',e.candidate.toJSON())};
  if(initiate){const offer=await pc.createOffer();await pc.setLocalDescription(offer);await sendGroupSignal(state.group.active.id,peerId,'offer',pc.localDescription.toJSON())}return pc;
}
async function handleGroupSignal(row){
  if(!state.group.active||row.room_id!==state.group.active.id)return;const peer=await ensureGroupPeer(row.from_user,false);
  try{if(row.kind==='offer'){await peer.setRemoteDescription(new RTCSessionDescription(row.payload));const a=await peer.createAnswer();await peer.setLocalDescription(a);await sendGroupSignal(row.room_id,row.from_user,'answer',peer.localDescription.toJSON())}else if(row.kind==='answer'){if(!peer.currentRemoteDescription)await peer.setRemoteDescription(new RTCSessionDescription(row.payload))}else if(row.kind==='ice'){await peer.addIceCandidate(new RTCIceCandidate(row.payload))}}catch(e){console.error('group signal',e)}
}
async function startGroupCall(ids){
  ids=[...new Set(ids)].filter(Boolean).slice(0,3);if(!ids.length)return toast('কমপক্ষে ১ জন নির্বাচন করুন');
  try{const {data:room,error}=await sb.from('group_calls').insert({creator_id:state.user.id,call_type:'video',status:'ringing'}).select().single();if(error)throw error;
    const members=[{room_id:room.id,user_id:state.user.id,status:'joined',joined_at:new Date().toISOString()},...ids.map(id=>({room_id:room.id,user_id:id,status:'invited'}))];const {error:me}=await sb.from('group_call_members').insert(members);if(me)throw me;
    sendCallPush({room_id:room.id});
    state.group.active=room;state.group.incoming=null;await ensureTurnCredentials();await groupLocalMedia('video');app();
  }catch(e){console.error(e);toast('Group call শুরু করা যায়নি')}
}
async function acceptGroupCall(){try{window.VibesNative?.clearIncomingCall()}catch{}const room=state.group.incoming;if(!room)return;state.group.active=room;state.group.incoming=null;await groupLocalMedia(room.call_type);await sb.from('group_call_members').update({status:'joined',joined_at:new Date().toISOString()}).eq('room_id',room.id).eq('user_id',state.user.id);await sb.from('group_calls').update({status:'active'}).eq('id',room.id).eq('creator_id',room.creator_id);const {data}=await sb.from('group_call_members').select('user_id,status').eq('room_id',room.id).eq('status','joined');for(const m of data||[]){if(m.user_id!==state.user.id&&state.user.id<m.user_id)await ensureGroupPeer(m.user_id,true)}app()}
async function rejectGroupCall(){try{window.VibesNative?.clearIncomingCall()}catch{}const r=state.group.incoming;if(!r)return;await sb.from('group_call_members').update({status:'rejected'}).eq('room_id',r.id).eq('user_id',state.user.id);state.group.incoming=null;app()}
async function leaveGroupCall(mark=true){try{window.VibesNative?.clearIncomingCall()}catch{}const r=state.group.active;if(mark&&r){await sb.from('group_call_members').update({status:'left'}).eq('room_id',r.id).eq('user_id',state.user.id);if(r.creator_id===state.user.id)await sb.from('group_calls').update({status:'ended',ended_at:new Date().toISOString()}).eq('id',r.id)}Object.values(state.group.peers).forEach(pc=>{try{pc.close()}catch{}});state.group.localStream?.getTracks().forEach(t=>t.stop());state.group.rawLocalStream?.getTracks().forEach(t=>t.stop());state.group.active=null;state.group.peers={};state.group.remotes={};state.group.localStream=null;state.group.rawLocalStream=null;app()}
function toggleGroupMute(){state.group.muted=!state.group.muted;state.group.localStream?.getAudioTracks().forEach(t=>t.enabled=!state.group.muted);app()}
function toggleGroupCamera(){state.group.cameraOff=!state.group.cameraOff;state.group.localStream?.getVideoTracks().forEach(t=>t.enabled=!state.group.cameraOff);app()}
function attachGroupMedia(){const lv=document.getElementById('groupLocal');if(lv&&state.group.localStream&&lv.srcObject!==state.group.localStream){lv.srcObject=state.group.localStream;lv.muted=true;lv.play().catch(()=>{})}Object.entries(state.group.remotes).forEach(([id,s])=>{const el=document.getElementById('group-'+id);if(el&&el.srcObject!==s){el.srcObject=s;el.play().catch(()=>{})}})}
function groupCallUI(){const r=state.group.active;if(!r)return '';const rem=Object.keys(state.group.remotes);return `<div class="call-screen group-call"><div class="call-title">Group Video Call</div><div class="muted">সর্বোচ্চ ৪ জন</div><div class="group-grid"><div class="group-tile"><video id="groupLocal" autoplay muted playsinline></video><span>আপনি</span></div>${rem.map(id=>`<div class="group-tile"><video id="group-${id}" autoplay playsinline></video><span>${esc(callPersonName(id))}</span></div>`).join('')}</div><div class="call-actions"><button class="call-round" id="groupMute">${state.group.muted?'🔇':'🎤'}</button><button class="call-round" id="groupCamera">${state.group.cameraOff?'📷✕':'📹'}</button><button class="call-round danger" id="groupLeave">📞</button></div></div>`}
function incomingGroupUI(){const r=state.group.incoming;if(!r)return '';return `<div class="incoming-call"><div class="call-avatar small">G</div><div class="grow"><b>Group Video Call</b><div class="muted">${esc(callPersonName(r.creator_id))} আপনাকে ডাকছে</div></div><button class="call-round accept" id="acceptGroup">✓</button><button class="call-round danger" id="rejectGroup">✕</button></div>`}
function groupPickerUI(){const people=state.people.slice(0,20);return `<div class="card"><div class="section-title">Group Video Call</div><div class="muted" style="margin-bottom:8px">৩ জন পর্যন্ত বেছে নিন — আপনিসহ মোট ৪ জন।</div><div class="group-picker">${people.map(p=>`<label><input type="checkbox" data-group-pick="${p.id}"> ${esc(p.display_name||'Vibes user')}</label>`).join('')}</div><button class="btn" id="startGroup" style="margin-top:10px">Group Call শুরু</button></div>`}

function chatView(){
  if(state.group.active)return groupCallUI();if(state.call.active)return activeCallUI();const incoming=incomingCallUI()+incomingGroupUI();
  if(state.chatOpen)return `${incoming}<div class="row" style="margin-bottom:10px"><button class="pill" id="backChat">←</button><div class="grow"><b>Nadia</b><div class="muted"><span class="status-dot"></span> চ্যাট</div></div></div><div class="card messages">${state.messages.map(m=>`<div class="bubble ${m.me?'me':''}">${esc(m.text)}</div>`).join('')}</div><div class="chatbar"><input id="msg" placeholder="মেসেজ লিখুন"><button class="btn" id="sendMsg">পাঠান</button></div>`;
  const people=state.people.length?state.people.map(p=>`<div class="card row person-row"><div class="avatar">${esc((p.display_name||'V')[0])}</div><div class="grow"><b>${esc(p.display_name||'Vibes user')}</b><div class="muted">${esc(p.username?'@'+p.username:'Vibes')}</div></div><button class="call-mini" data-audio-call="${p.id}">📞</button><button class="call-mini" data-video-call="${p.id}">📹</button></div>`).join(''):`<div class="empty">আরও ব্যবহারকারী যোগ হলে এখানে call করা যাবে।</div>`;
  return `${incoming}<div class="title">চ্যাট ও কল</div>${groupPickerUI()}<div class="notice">1-to-1 এবং ছোট Group Video Call WebRTC ব্যবহার করে। Background Blur/Virtual Background আপনার ডিভাইসেই process হয়।</div><div class="chat-list">${people}</div>`;
}

async function cloudBootstrap(){if(!cloudReady)return;const {data:{session}}=await sb.auth.getSession();if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople()]);await Promise.all([setupCallRealtime(),setupGroupRealtime()]);await registerNativePushToken();const pending=readPendingNativeCall();if(pending)console.info('Vibes opened from call notification',pending)}sb.auth.onAuthStateChange(async(_,session)=>{if(session?.user){state.user={...session.user,name:session.user.user_metadata?.name||session.user.email?.split('@')[0]};await Promise.all([loadCloudPosts(),loadPeople()]);await Promise.all([setupCallRealtime(),setupGroupRealtime()]);await registerNativePushToken()}else{closeCallMedia();await leaveGroupCall(false);state.user=null}app()})}
function app(){document.getElementById('app').innerHTML=state.user?mainUI():authUI();bind();setTimeout(()=>{attachCallMedia();attachGroupMedia()},0)}
function bind(){
  baseBind();document.querySelectorAll('[data-audio-call]').forEach(b=>b.onclick=()=>startCall(b.dataset.audioCall,'audio'));document.querySelectorAll('[data-video-call]').forEach(b=>b.onclick=()=>startCall(b.dataset.videoCall,'video'));
  document.getElementById('acceptCall')?.addEventListener('click',acceptCall);document.getElementById('rejectCall')?.addEventListener('click',rejectCall);document.getElementById('endCall')?.addEventListener('click',endCall);document.getElementById('muteCall')?.addEventListener('click',toggleMute);document.getElementById('cameraCall')?.addEventListener('click',toggleCamera);document.getElementById('switchCamera')?.addEventListener('click',switchCamera);
  document.querySelectorAll('[data-call-filter]').forEach(b=>b.onclick=()=>setCallFilter(b.dataset.callFilter));document.querySelectorAll('[data-call-bg]').forEach(b=>b.onclick=()=>setCallBackground(b.dataset.callBg));document.getElementById('virtualBgFile')?.addEventListener('change',e=>pickVirtualBackground(e.target.files?.[0]));
  document.getElementById('startGroup')?.addEventListener('click',()=>startGroupCall([...document.querySelectorAll('[data-group-pick]:checked')].map(x=>x.dataset.groupPick)));document.getElementById('acceptGroup')?.addEventListener('click',acceptGroupCall);document.getElementById('rejectGroup')?.addEventListener('click',rejectGroupCall);document.getElementById('groupLeave')?.addEventListener('click',()=>leaveGroupCall(true));document.getElementById('groupMute')?.addEventListener('click',toggleGroupMute);document.getElementById('groupCamera')?.addEventListener('click',toggleGroupCamera);
}


// ---- Vibes native push registration ----
async function registerNativePushToken(){
  if(!cloudReady||!state.user?.id||!window.VibesNative?.getPushToken)return;
  try{
    const token=String(window.VibesNative.getPushToken()||'').trim();
    if(!token)return;
    const {error}=await sb.from('push_tokens').upsert({user_id:state.user.id,token,platform:'android',device_label:'Vibes Android',updated_at:new Date().toISOString()},{onConflict:'token'});
    if(error)console.warn('push token registration',error);
  }catch(e){console.warn('native push token',e)}
}
function readPendingNativeCall(){
  if(!window.VibesNative?.getPendingCallJson)return null;
  try{const x=JSON.parse(window.VibesNative.getPendingCallJson()||'{}');return x&&x.type?x:null}catch{return null}
}

