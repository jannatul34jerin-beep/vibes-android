// Vibes public browser config.
// Publishable keys are safe for client apps; never put a service_role key here.
window.VIBES_CONFIG = {
  supabaseUrl: "https://darafsrmyyslbvhpgfoo.supabase.co",
  supabaseAnonKey: "sb_publishable_4pvZx-roR0qRz564_Kic1A_UIsVSpg9",
  appName: "Vibes",
  maxImageMB: 5,
  demoMode: false,
  // STUN works for many networks. Add a production TURN service for best reliability.
  iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
  // Production: add credentials from your TURN provider here, e.g.
  // { urls:["turn:turn.example.com:3478","turns:turn.example.com:5349"], username:"...", credential:"..." }
  // Do not publish long-lived admin/API secrets. Use short-lived TURN credentials where possible.
  turnServers: []
};
