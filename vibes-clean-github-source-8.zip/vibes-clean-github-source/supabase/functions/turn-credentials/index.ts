// Deployed in the connected Supabase project as `turn-credentials`.
// Requires TURN_HOST and TURN_SHARED_SECRET as Supabase Edge Function secrets.
// It returns short-lived TURN credentials only to authenticated users.
