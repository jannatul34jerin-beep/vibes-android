# Vibes v1.7.0 Release Status

## Included in this package
- Gradle release signing support from local `keystore.properties` or CI environment variables
- A coturn deployment template that expects secrets at deployment time
- Photo and video post selection, preview, upload, and feed playback
- Stories, Reels, notifications, saved posts, and seven non-destructive filters
- Resumable large-file uploads without an app-level MB cap
- Lazy media loading and off-screen video pausing for smoother phones
- Target SDK 36 and version 1.7.0 (versionCode 8)
- Release APK/AAB build workflow

## External identities that cannot be fabricated
- Firebase `google-services.json` (issued by Google for a real Firebase project)
- A public TURN server IP/DNS, TLS certificate, and private shared secret
- A private Android upload key and signing credentials

The debug app can be built without Firebase or signing credentials. A signed Play Store release requires the private upload key. FCM killed-app notifications remain inactive until the genuine Firebase file is supplied. STUN calling remains available; reliable relay calling requires coturn to be deployed publicly.
