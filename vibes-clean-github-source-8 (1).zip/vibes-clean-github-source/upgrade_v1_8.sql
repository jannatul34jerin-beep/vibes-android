-- Vibes 1.8 social feature upgrade. Run once in Supabase SQL Editor.

alter table public.posts add column if not exists filter_name text not null default 'natural'
check (filter_name in ('natural','bright','warm','cool','vivid','mono','soft'));

create table if not exists public.saved_posts (
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, post_id)
);

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  media_url text not null,
  media_type text not null check (media_type like 'image/%' or media_type like 'video/%'),
  filter_name text not null default 'natural' check (filter_name in ('natural','bright','warm','cool','vivid','mono','soft')),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours')
);

alter table public.stories add column if not exists filter_name text not null default 'natural'
check (filter_name in ('natural','bright','warm','cool','vivid','mono','soft'));

alter table public.saved_posts enable row level security;
alter table public.stories enable row level security;

create policy "saved posts owner read" on public.saved_posts for select to authenticated
using ((select auth.uid()) = user_id);
create policy "saved posts owner insert" on public.saved_posts for insert to authenticated
with check ((select auth.uid()) = user_id);
create policy "saved posts owner delete" on public.saved_posts for delete to authenticated
using ((select auth.uid()) = user_id);

create policy "active stories readable" on public.stories for select to authenticated
using (expires_at > now());
create policy "story owner insert" on public.stories for insert to authenticated
with check ((select auth.uid()) = user_id);
create policy "story owner delete" on public.stories for delete to authenticated
using ((select auth.uid()) = user_id);

grant select, insert, delete on public.saved_posts to authenticated;
grant select, insert, delete on public.stories to authenticated;
revoke all on public.saved_posts, public.stories from anon;

update storage.buckets
set file_size_limit = null,
    allowed_mime_types = array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime']
where id = 'post-media';
