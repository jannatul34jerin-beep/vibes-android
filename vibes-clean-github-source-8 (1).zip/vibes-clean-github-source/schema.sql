-- Vibes / Supabase schema
-- Run in Supabase SQL Editor on a NEW project.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Vibes User' check (char_length(display_name) between 1 and 50),
  username text unique,
  bio text default '' check (char_length(bio) <= 240),
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null default '' check (char_length(body) <= 3000),
  image_url text,
  filter_name text not null default 'natural' check (filter_name in ('natural','bright','warm','cool','vivid','mono','soft')),
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(post_id,user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);

create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(follower_id,following_id),
  check (follower_id <> following_id)
);

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(blocker_id,blocked_id),
  check (blocker_id <> blocked_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid references public.posts(id) on delete cascade,
  reason text not null check (char_length(reason) between 1 and 500),
  status text not null default 'open' check(status in ('open','reviewed','resolved')),
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now()
);
create table if not exists public.conversation_members (
  conversation_id uuid references public.conversations(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key(conversation_id,user_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check(char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);

-- Create profile automatically after signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,display_name,username)
  values(new.id,coalesce(new.raw_user_meta_data->>'name',split_part(new.email,'@',1)),
    lower(regexp_replace(coalesce(new.raw_user_meta_data->>'name',split_part(new.email,'@',1)),'[^a-zA-Z0-9]+','','g')) || substr(new.id::text,1,6))
  on conflict(id) do nothing;
  return new;
end;$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;
alter table public.blocks enable row level security;
alter table public.reports enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

-- Read public social content when signed in
create policy "profiles readable" on public.profiles for select to authenticated using (true);
create policy "profile owner insert" on public.profiles for insert to authenticated with check (auth.uid()=id);
create policy "profile owner update" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);
create policy "posts readable" on public.posts for select to authenticated using (true);
create policy "posts own insert" on public.posts for insert to authenticated with check (auth.uid()=user_id);
create policy "posts own update" on public.posts for update to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "posts own delete" on public.posts for delete to authenticated using (auth.uid()=user_id);
create policy "likes readable" on public.likes for select to authenticated using (true);
create policy "likes own insert" on public.likes for insert to authenticated with check (auth.uid()=user_id);
create policy "likes own delete" on public.likes for delete to authenticated using (auth.uid()=user_id);
create policy "comments readable" on public.comments for select to authenticated using (true);
create policy "comments own insert" on public.comments for insert to authenticated with check (auth.uid()=user_id);
create policy "comments own delete" on public.comments for delete to authenticated using (auth.uid()=user_id);
create policy "follows readable" on public.follows for select to authenticated using (true);
create policy "follows own insert" on public.follows for insert to authenticated with check (auth.uid()=follower_id);
create policy "follows own delete" on public.follows for delete to authenticated using (auth.uid()=follower_id);
create policy "blocks own read" on public.blocks for select to authenticated using (auth.uid()=blocker_id);
create policy "blocks own insert" on public.blocks for insert to authenticated with check (auth.uid()=blocker_id);
create policy "blocks own delete" on public.blocks for delete to authenticated using (auth.uid()=blocker_id);
create policy "reports own insert" on public.reports for insert to authenticated with check (auth.uid()=reporter_id);
create policy "reports own read" on public.reports for select to authenticated using (auth.uid()=reporter_id);

-- Private chat: only conversation members can see/access
create policy "conversation member read" on public.conversations for select to authenticated using (
  exists(select 1 from public.conversation_members cm where cm.conversation_id=id and cm.user_id=auth.uid())
);
create policy "member rows read" on public.conversation_members for select to authenticated using (
  exists(select 1 from public.conversation_members me where me.conversation_id=conversation_id and me.user_id=auth.uid())
);
create policy "message member read" on public.messages for select to authenticated using (
  exists(select 1 from public.conversation_members cm where cm.conversation_id=conversation_id and cm.user_id=auth.uid())
);
create policy "message member insert" on public.messages for insert to authenticated with check (
  auth.uid()=sender_id and exists(select 1 from public.conversation_members cm where cm.conversation_id=conversation_id and cm.user_id=auth.uid())
);

-- Least-privilege grants for browser clients
grant select,insert,update,delete on public.profiles,public.posts,public.likes,public.comments,public.follows,public.blocks to authenticated;
grant select,insert on public.reports to authenticated;
grant select on public.conversations,public.conversation_members to authenticated;
grant select,insert on public.messages to authenticated;
revoke all on public.profiles,public.posts,public.likes,public.comments,public.follows,public.blocks,public.reports,public.conversations,public.conversation_members,public.messages from anon;

-- Public post-media bucket. Post deletion can be paired with a server-side cleanup later.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('post-media','post-media',true,null,array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime'])
on conflict(id) do update set public=true,file_size_limit=null,allowed_mime_types=array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime'];

create policy "post media authenticated upload" on storage.objects for insert to authenticated with check (
  bucket_id='post-media' and (storage.foldername(name))[1]=auth.uid()::text
);
create policy "post media public read" on storage.objects for select using (bucket_id='post-media');
create policy "post media owner delete" on storage.objects for delete to authenticated using (
  bucket_id='post-media' and (storage.foldername(name))[1]=auth.uid()::text
);


-- Added in Vibes 1.1: in-app notifications
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete cascade,
  type text not null check(type in ('like','comment','follow','message','system')),
  post_id uuid references public.posts(id) on delete cascade,
  body text default '',
  read_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.notifications enable row level security;
create policy "notification owner read" on public.notifications for select to authenticated using(auth.uid()=user_id);
create policy "notification owner update" on public.notifications for update to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
grant select,update on public.notifications to authenticated;
revoke all on public.notifications from anon;
